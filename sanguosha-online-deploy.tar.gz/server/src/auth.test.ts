import bcrypt from "bcryptjs";
import session from "express-session";
import request from "supertest";
import { beforeEach, describe, expect, it } from "vitest";
import { createApplication } from "./app.js";
import type { AppConfig } from "./config.js";
import { HttpError } from "./errors.js";
import { RoomService } from "./rooms.js";
import { SecurityEvents } from "./security-events.js";
import type {
  CreateUserInput,
  PublicUser,
  UserStore,
  UserWithPassword,
  SessionUser,
} from "./users.js";

const ADMIN_ID = "11111111-1111-4111-8111-111111111111";
const PLAYER_ID = "22222222-2222-4222-8222-222222222222";

class MemoryUserStore implements UserStore {
  private readonly records = new Map<string, UserWithPassword>();
  private counter = 3;

  constructor() {
    this.put(ADMIN_ID, "admin", "管理员", "admin-password", "admin");
    this.put(PLAYER_ID, "player", "玩家", "player-password", "player");
  }

  async findById(id: string): Promise<PublicUser | undefined> {
    const value = this.records.get(id);
    return value ? this.public(value) : undefined;
  }

  async findSessionUser(id: string): Promise<SessionUser | undefined> {
    const value = this.records.get(id);
    return value ? { user: this.public(value), sessionVersion: value.sessionVersion } : undefined;
  }

  async findByUsernameWithPassword(username: string): Promise<UserWithPassword | undefined> {
    return [...this.records.values()].find(
      (candidate) => candidate.username.toLowerCase() === username.toLowerCase(),
    );
  }

  async list(): Promise<PublicUser[]> {
    return [...this.records.values()].map((value) => this.public(value));
  }

  async create(input: CreateUserInput): Promise<PublicUser> {
    if ([...this.records.values()].some((value) => value.username.toLowerCase() === input.username.toLowerCase())) {
      throw new HttpError(409, "USERNAME_EXISTS", "用户名已存在");
    }
    const digit = String(this.counter++).padStart(12, "0");
    const id = `33333333-3333-4333-8333-${digit}`;
    this.put(id, input.username, input.displayName, input.password, input.role ?? "player");
    return this.public(this.records.get(id)!);
  }

  async setDisabled(id: string, disabled: boolean): Promise<PublicUser | undefined> {
    const value = this.records.get(id);
    if (!value) return undefined;
    value.disabled = disabled;
    value.sessionVersion += 1;
    value.updatedAt = new Date().toISOString();
    return this.public(value);
  }

  async resetPassword(id: string, password: string): Promise<PublicUser | undefined> {
    const value = this.records.get(id);
    if (!value) return undefined;
    value.passwordHash = bcrypt.hashSync(password, 4);
    value.sessionVersion += 1;
    value.updatedAt = new Date().toISOString();
    return this.public(value);
  }

  async recordAudit(): Promise<void> {}

  private put(
    id: string,
    username: string,
    displayName: string,
    password: string,
    role: "admin" | "player",
  ): void {
    const now = new Date().toISOString();
    this.records.set(id, {
      id,
      username,
      displayName,
      passwordHash: bcrypt.hashSync(password, 4),
      sessionVersion: 0,
      role,
      disabled: false,
      createdAt: now,
      updatedAt: now,
    });
  }

  private public(value: UserWithPassword): PublicUser {
    const { passwordHash: _passwordHash, sessionVersion: _sessionVersion, ...publicUser } = value;
    return { ...publicUser };
  }
}

const config: AppConfig = {
  nodeEnv: "test",
  port: 3_000,
  databaseUrl: "postgresql://unused",
  sessionSecret: "test-session-secret-at-least-32-characters",
  initialAdmin: { username: "admin", password: "admin-password", displayName: "管理员" },
  trustProxy: 0,
  secureCookies: false,
};

describe("account allocation and authorization", () => {
  let users: MemoryUserStore;
  let app: ReturnType<typeof createApplication>;

  beforeEach(() => {
    users = new MemoryUserStore();
    app = createApplication({
      config,
      pool: { query: async () => ({ rows: [{ "?column?": 1 }] }) } as never,
      sessionMiddleware: session({ secret: config.sessionSecret, resave: false, saveUninitialized: false }),
      users,
      rooms: new RoomService(),
      securityEvents: new SecurityEvents(),
    });
  });

  it("does not expose registration and rejects anonymous admin requests", async () => {
    await request(app).post("/api/auth/register").send({}).expect(404);
    const response = await request(app).get("/api/admin/users").expect(401);
    expect(response.body.error.code).toBe("UNAUTHENTICATED");
  });

  it("allows only admins to allocate, disable and reset player accounts", async () => {
    const playerAgent = request.agent(app);
    await playerAgent.post("/api/auth/login")
      .send({ username: "player", password: "player-password" })
      .expect(200);
    await playerAgent.get("/api/admin/users").expect(403);

    const adminAgent = request.agent(app);
    await adminAgent.post("/api/auth/login")
      .send({ username: "admin", password: "admin-password" })
      .expect(200);

    const created = await adminAgent.post("/api/admin/users")
      .send({ username: "new_player", displayName: "新玩家", password: "initial-password" })
      .expect(201);
    expect(created.body.user).toMatchObject({ username: "new_player", role: "player", disabled: false });
    expect(created.body.user).not.toHaveProperty("passwordHash");

    await adminAgent.post(`/api/admin/users/${PLAYER_ID}/reset-password`)
      .send({ password: "replacement-password" })
      .expect(200);
    await request(app).post("/api/auth/login")
      .send({ username: "player", password: "player-password" })
      .expect(401);
    await playerAgent.get("/api/auth/me").expect(401);
    await playerAgent.post("/api/auth/login")
      .send({ username: "player", password: "replacement-password" })
      .expect(200);

    await adminAgent.patch(`/api/admin/users/${PLAYER_ID}/status`)
      .send({ disabled: true })
      .expect(200);
    const disabledResponse = await playerAgent.get("/api/auth/me").expect(403);
    expect(disabledResponse.body.error.code).toBe("ACCOUNT_DISABLED");
  });
});
