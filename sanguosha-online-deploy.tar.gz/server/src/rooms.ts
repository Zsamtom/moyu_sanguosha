import { EventEmitter } from "node:events";
import { randomBytes, randomUUID } from "node:crypto";
import {
  applyAction,
  createGame,
  forfeitPlayer,
  getGameView,
  type GameAction,
  type GameSession,
  type GameView,
} from "@sanguosha/shared";
import { HttpError } from "./errors.js";
import type { PublicUser } from "./users.js";

export type RoomStatus = "waiting" | "playing" | "finished";

export interface RoomPlayerView {
  id: string;
  username: string;
  displayName: string;
  ready: boolean;
  connected: boolean;
  seat: number;
  isBot?: boolean;
}

export interface RoomSummary {
  id: string;
  name: string;
  ownerId: string;
  ownerName: string;
  status: RoomStatus;
  playerCount: number;
  maxPlayers: number;
  createdAt: string;
}

export interface RoomView extends RoomSummary {
  players: RoomPlayerView[];
}

interface RoomPlayer extends RoomPlayerView {}

interface Room {
  id: string;
  name: string;
  ownerId: string;
  status: RoomStatus;
  maxPlayers: number;
  createdAt: string;
  players: RoomPlayer[];
  game?: GameSession;
}

export interface RoomServiceSnapshot {
  readonly version: 1;
  readonly rooms: Array<{
    id: string;
    name: string;
    ownerId: string;
    status: RoomStatus;
    maxPlayers: number;
    createdAt: string;
    players: RoomPlayerView[];
    game?: GameSession;
  }>;
}

export interface CreateRoomInput {
  name: string;
  maxPlayers?: number;
}

export class RoomService {
  private readonly rooms = new Map<string, Room>();
  private readonly roomByUser = new Map<string, string>();
  private readonly connectedUsers = new Set<string>();
  private readonly disconnectTimers = new Map<string, NodeJS.Timeout>();
  private readonly events = new EventEmitter();

  constructor(private readonly disconnectGraceMs = 90_000) {}

  onChanged(listener: () => void): () => void {
    this.events.on("changed", listener);
    return () => this.events.off("changed", listener);
  }

  exportSnapshot(): RoomServiceSnapshot {
    return {
      version: 1,
      rooms: [...this.rooms.values()].map((room) => structuredClone(room)),
    };
  }

  restoreSnapshot(snapshot: RoomServiceSnapshot): void {
    if (snapshot.version !== 1) throw new Error(`Unsupported room snapshot version: ${snapshot.version}`);
    for (const timer of this.disconnectTimers.values()) clearTimeout(timer);
    this.disconnectTimers.clear();
    this.connectedUsers.clear();
    this.rooms.clear();
    this.roomByUser.clear();

    for (const saved of snapshot.rooms) {
      if (saved.players.every((player) => player.isBot)) continue;
      if (this.rooms.has(saved.id)) throw new Error(`Duplicate room in snapshot: ${saved.id}`);
      if (!saved.players.some((player) => player.id === saved.ownerId)) {
        throw new Error(`Room ${saved.id} owner is not a member`);
      }
      if (saved.status === "playing" && !saved.game) {
        throw new Error(`Playing room ${saved.id} has no game state`);
      }
      const room: Room = structuredClone(saved);
      room.players.forEach((player, seat) => {
        player.isBot ??= false;
        if (!player.isBot && this.roomByUser.has(player.id)) {
          throw new Error(`User ${player.id} appears in multiple restored rooms`);
        }
        player.seat = seat;
        player.connected = player.isBot;
        if (!player.isBot) this.roomByUser.set(player.id, room.id);
      });
      this.rooms.set(room.id, room);
      if (room.status === "playing") {
        for (const player of room.players) if (!player.isBot) this.scheduleDisconnectResolution(player.id);
        this.runBots(room);
      }
    }
  }

  list(): RoomSummary[] {
    return [...this.rooms.values()]
      .map((room) => this.toSummary(room))
      .sort((left, right) => right.createdAt.localeCompare(left.createdAt));
  }

  get(roomId: string): RoomView | undefined {
    const room = this.rooms.get(roomId);
    return room ? this.toView(room) : undefined;
  }

  getForUser(userId: string): RoomView | undefined {
    const roomId = this.roomByUser.get(userId);
    return roomId ? this.get(roomId) : undefined;
  }

  create(owner: PublicUser, input: CreateRoomInput): RoomView {
    this.assertNotInRoom(owner.id);
    const id = randomUUID();
    const room: Room = {
      id,
      name: input.name.trim(),
      ownerId: owner.id,
      status: "waiting",
      maxPlayers: input.maxPlayers ?? 8,
      createdAt: new Date().toISOString(),
      players: [this.toPlayer(owner, 0)],
    };
    this.rooms.set(id, room);
    this.roomByUser.set(owner.id, id);
    this.changed();
    return this.toView(room);
  }

  join(roomId: string, user: PublicUser): RoomView {
    const currentRoomId = this.roomByUser.get(user.id);
    if (currentRoomId === roomId) return this.requireRoomView(roomId);
    this.assertNotInRoom(user.id);
    const room = this.requireRoom(roomId);
    if (room.status !== "waiting") {
      throw new HttpError(409, "ROOM_ALREADY_STARTED", "游戏已经开始");
    }
    if (room.players.length >= room.maxPlayers) {
      throw new HttpError(409, "ROOM_FULL", "房间已满");
    }

    room.players.push(this.toPlayer(user, room.players.length));
    room.players.forEach((player) => { player.ready = Boolean(player.isBot); });
    this.roomByUser.set(user.id, room.id);
    this.changed();
    return this.toView(room);
  }

  addBot(roomId: string, ownerId: string): RoomView {
    const room = this.requireMember(roomId, ownerId);
    if (room.ownerId !== ownerId) throw new HttpError(403, "NOT_ROOM_OWNER", "只有房主可以添加机器人");
    if (room.status !== "waiting") throw new HttpError(409, "ROOM_ALREADY_STARTED", "游戏已经开始");
    if (room.players.length >= room.maxPlayers) throw new HttpError(409, "ROOM_FULL", "房间已满");
    const id = randomUUID();
    const botNumber = room.players.filter((player) => player.isBot).length + 1;
    room.players.push({
      id,
      username: `bot_${id.slice(0, 8)}`,
      displayName: `机器人 ${botNumber}`,
      ready: true,
      connected: true,
      seat: room.players.length,
      isBot: true,
    });
    this.changed();
    return this.toView(room);
  }

  removeBot(roomId: string, ownerId: string, botId: string): RoomView {
    const room = this.requireMember(roomId, ownerId);
    if (room.ownerId !== ownerId) throw new HttpError(403, "NOT_ROOM_OWNER", "只有房主可以移除机器人");
    if (room.status !== "waiting") throw new HttpError(409, "ROOM_ALREADY_STARTED", "游戏已经开始");
    const index = room.players.findIndex((player) => player.id === botId && player.isBot);
    if (index < 0) throw new HttpError(404, "BOT_NOT_FOUND", "机器人不存在");
    room.players.splice(index, 1);
    room.players.forEach((player, seat) => { player.seat = seat; });
    this.changed();
    return this.toView(room);
  }

  leave(roomId: string, userId: string): void {
    const room = this.requireMember(roomId, userId);
    this.clearDisconnectTimer(userId);
    if (room.status === "playing") {
      if (!room.game) {
        throw new HttpError(409, "GAME_NOT_IN_PROGRESS", "游戏状态异常");
      }
      const gamePlayer = room.game.players.find((player) => player.id === userId);
      if (!gamePlayer) {
        throw new HttpError(409, "GAME_PLAYER_NOT_FOUND", "玩家不在当前游戏中");
      }
      // A dead player can safely leave without changing the still-running
      // identity match. Only a living departure is a forfeiture.
      if (gamePlayer.alive) {
        room.game = forfeitPlayer(room.game, userId);
        room.status = "finished";
      }
    }

    const index = room.players.findIndex((player) => player.id === userId);
    room.players.splice(index, 1);
    this.roomByUser.delete(userId);
    const remainingHumans = room.players.filter((player) => !player.isBot);
    if (remainingHumans.length === 0) {
      this.rooms.delete(room.id);
    } else {
      room.players.forEach((player, seat) => {
        player.seat = seat;
        player.ready = Boolean(player.isBot);
      });
      if (room.ownerId === userId) room.ownerId = remainingHumans[0]!.id;
    }
    this.changed();
  }

  setReady(roomId: string, userId: string, ready: boolean): RoomView {
    const room = this.requireMember(roomId, userId);
    if (room.status !== "waiting") {
      throw new HttpError(409, "ROOM_ALREADY_STARTED", "游戏已经开始");
    }
    const player = room.players.find((candidate) => candidate.id === userId)!;
    player.ready = ready;
    this.changed();
    return this.toView(room);
  }

  start(roomId: string, userId: string): RoomView {
    const room = this.requireMember(roomId, userId);
    if (room.ownerId !== userId) {
      throw new HttpError(403, "NOT_ROOM_OWNER", "只有房主可以开始游戏");
    }
    if (room.status !== "waiting") {
      throw new HttpError(409, "ROOM_ALREADY_STARTED", "游戏已经开始");
    }
    if (room.players.length < 2) {
      throw new HttpError(409, "NOT_ENOUGH_PLAYERS", "至少需要 2 名玩家");
    }
    if (room.players.some((player) => !player.connected)) {
      throw new HttpError(409, "PLAYERS_OFFLINE", "有玩家离线，无法开始游戏");
    }
    if (room.players.some((player) => !player.ready)) {
      throw new HttpError(409, "PLAYERS_NOT_READY", "所有玩家准备后才能开始");
    }

    room.game = createGame({
      playerIds: room.players.map((player) => player.id),
      seed: randomBytes(32).toString("hex"),
    });
    room.status = "playing";
    this.runBots(room);
    this.changed();
    return this.toView(room);
  }

  applyAction(roomId: string, userId: string, action: GameAction): GameView {
    const room = this.requireMember(roomId, userId);
    if (room.status !== "playing" || !room.game) {
      throw new HttpError(409, "GAME_NOT_IN_PROGRESS", "游戏尚未开始或已经结束");
    }
    if (action.playerId !== userId) {
      throw new HttpError(403, "PLAYER_MISMATCH", "不能替其他玩家执行操作");
    }

    room.game = applyAction(room.game, action);
    this.runBots(room);
    if (room.game.status === "finished") room.status = "finished";
    this.changed();
    return getGameView(room.game, userId);
  }

  getGameView(roomId: string, userId: string): GameView | undefined {
    const room = this.requireMember(roomId, userId);
    return room.game ? getGameView(room.game, userId) : undefined;
  }

  setConnected(userId: string, connected: boolean): void {
    if (connected) {
      this.connectedUsers.add(userId);
      this.clearDisconnectTimer(userId);
    } else {
      this.connectedUsers.delete(userId);
    }
    const roomId = this.roomByUser.get(userId);
    if (!roomId) return;
    const room = this.rooms.get(roomId);
    const player = room?.players.find((candidate) => candidate.id === userId);
    if (!player || player.connected === connected) return;
    player.connected = connected;
    this.changed();
    if (!connected && room?.status === "playing") {
      this.scheduleDisconnectResolution(userId);
    }
  }

  members(roomId: string): string[] {
    return this.rooms.get(roomId)?.players.map((player) => player.id) ?? [];
  }

  allRoomIds(): string[] {
    return [...this.rooms.keys()];
  }

  private toSummary(room: Room): RoomSummary {
    return {
      id: room.id,
      name: room.name,
      ownerId: room.ownerId,
      ownerName: room.players.find((player) => player.id === room.ownerId)?.displayName ?? "",
      status: room.status,
      playerCount: room.players.length,
      maxPlayers: room.maxPlayers,
      createdAt: room.createdAt,
    };
  }

  private toView(room: Room): RoomView {
    return {
      ...this.toSummary(room),
      players: room.players.map((player) => ({ ...player })),
    };
  }

  private toPlayer(user: PublicUser, seat: number): RoomPlayer {
    return {
      id: user.id,
      username: user.username,
      displayName: user.displayName,
      ready: false,
      connected: this.connectedUsers.has(user.id),
      seat,
      isBot: false,
    };
  }

  private runBots(room: Room): void {
    if (room.status !== "playing" || !room.game) return;
    for (let step = 0; step < 200 && room.game.status === "playing"; step += 1) {
      const bot = room.players.find((player) => player.isBot && player.id === room.game!.pendingResponse?.targetId)
        ?? room.players.find((player) => player.isBot && player.id === room.game!.currentPlayerId && room.game!.turn.phase !== "respond");
      if (!bot) break;
      const view = getGameView(room.game, bot.id);
      const prompt = view.prompt;
      let action: GameAction;
      if (prompt.type === "play") {
        const preferred = prompt.cards.find((hint) => hint.kind === "peach")
          ?? prompt.cards.find((hint) => hint.kind === "ex_nihilo")
          ?? prompt.cards.find((hint) => hint.kind.includes("horse"))
          ?? prompt.cards[0];
        action = preferred
          ? { type: "play_card", playerId: bot.id, cardId: preferred.cardId, targetId: preferred.targetIds[0] }
          : { type: "end_play", playerId: bot.id };
      } else if (prompt.type === "respond" || prompt.type === "dying") {
        action = { type: "respond", playerId: bot.id, cardId: prompt.allowedCardIds[0] ?? null };
      } else if (prompt.type === "discard") {
        action = { type: "discard", playerId: bot.id, cardIds: prompt.cardIds.slice(0, prompt.count) };
      } else break;
      room.game = applyAction(room.game, action);
    }
    if (room.game.status === "finished") room.status = "finished";
  }

  private requireRoom(roomId: string): Room {
    const room = this.rooms.get(roomId);
    if (!room) throw new HttpError(404, "ROOM_NOT_FOUND", "房间不存在");
    return room;
  }

  private requireRoomView(roomId: string): RoomView {
    return this.toView(this.requireRoom(roomId));
  }

  private requireMember(roomId: string, userId: string): Room {
    const room = this.requireRoom(roomId);
    if (!room.players.some((player) => player.id === userId)) {
      throw new HttpError(403, "NOT_ROOM_MEMBER", "你不在该房间中");
    }
    return room;
  }

  private assertNotInRoom(userId: string): void {
    if (this.roomByUser.has(userId)) {
      throw new HttpError(409, "ALREADY_IN_ROOM", "请先离开当前房间");
    }
  }

  private clearDisconnectTimer(userId: string): void {
    const timer = this.disconnectTimers.get(userId);
    if (!timer) return;
    clearTimeout(timer);
    this.disconnectTimers.delete(userId);
  }

  private scheduleDisconnectResolution(userId: string): void {
    this.clearDisconnectTimer(userId);
    const timer = setTimeout(() => {
      this.disconnectTimers.delete(userId);
      const activeRoomId = this.roomByUser.get(userId);
      const activeRoom = activeRoomId ? this.rooms.get(activeRoomId) : undefined;
      const activePlayer = activeRoom?.players.find((candidate) => candidate.id === userId);
      if (activeRoom && activePlayer && !activePlayer.connected) {
        try {
          this.leave(activeRoom.id, userId);
        } catch (error) {
          // A timer must never turn a recoverable room-state race into an
          // uncaught exception that terminates the whole Node.js process.
          console.error("Failed to resolve disconnected room member", error);
        }
      }
    }, this.disconnectGraceMs);
    timer.unref();
    this.disconnectTimers.set(userId, timer);
  }

  private changed(): void {
    this.events.emit("changed");
  }
}
