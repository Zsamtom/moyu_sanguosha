import { z } from "zod";

export const roomIdSchema = z.string().uuid();

export const createRoomSchema = z.object({
  name: z.string().trim().min(1).max(40),
  maxPlayers: z.number().int().min(2).max(10).optional(),
});

export const readySchema = z.object({ ready: z.boolean() });

const playerId = z.string().uuid();
const cardId = z.string().min(1).max(100);

export const gameActionSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("play_card"),
    playerId,
    cardId,
    targetId: playerId.optional(),
  }),
  z.object({
    type: z.literal("respond"),
    playerId,
    cardId: cardId.nullish(),
  }),
  z.object({
    type: z.literal("end_play"),
    playerId,
  }),
  z.object({
    type: z.literal("discard"),
    playerId,
    cardIds: z.array(cardId).max(20),
  }),
]);
