import { describe, expect, it, vi } from "vitest";
import type { GameSession } from "@sanguosha/shared";
import { HttpError } from "./errors.js";
import { RoomService } from "./rooms.js";
import type { PublicUser } from "./users.js";

function user(id: string, username: string): PublicUser {
  const now = new Date().toISOString();
  return {
    id,
    username,
    displayName: username,
    role: "player",
    disabled: false,
    createdAt: now,
    updatedAt: now,
  };
}

const owner = user("11111111-1111-4111-8111-111111111111", "owner");
const guest = user("22222222-2222-4222-8222-222222222222", "guest");
const third = user("33333333-3333-4333-8333-333333333333", "third");

describe("RoomService", () => {
  it("lets one human add a ready bot and start a game that auto-plays bot prompts", () => {
    const rooms = new RoomService();
    const created = rooms.create(owner, { name: "单人机器人局", maxPlayers: 2 });
    rooms.setConnected(owner.id, true);
    const withBot = rooms.addBot(created.id, owner.id);
    const bot = withBot.players.find((player) => player.isBot);
    if (!bot) throw new Error("Bot missing");
    expect(bot).toMatchObject({ ready: true, connected: true, isBot: true });
    rooms.setReady(created.id, owner.id, true);

    const started = rooms.start(created.id, owner.id);

    expect(started.status).toBe("playing");
    const ownerView = rooms.getGameView(created.id, owner.id)!;
    expect(ownerView.players.find((player) => player.id === owner.id)?.hand).not.toBeNull();
    expect(ownerView.players.find((player) => player.id === bot.id)?.hand).toBeNull();
    expect(ownerView.prompt.type === "play" ? ownerView.prompt.playerId : ownerView.prompt.type).not.toBe(bot.id);
  });

  it("allows only the owner to remove a waiting-room bot", () => {
    const rooms = new RoomService();
    const room = rooms.create(owner, { name: "机器人管理", maxPlayers: 3 });
    const withBot = rooms.addBot(room.id, owner.id);
    const bot = withBot.players.find((player) => player.isBot)!;
    expect(() => rooms.removeBot(room.id, guest.id, bot.id)).toThrowError(HttpError);
    expect(rooms.removeBot(room.id, owner.id, bot.id).players).toHaveLength(1);
  });

  it("deletes a room when its last human leaves instead of transferring ownership to a bot", () => {
    const rooms = new RoomService();
    const room = rooms.create(owner, { name: "机器人清理", maxPlayers: 2 });
    rooms.addBot(room.id, owner.id);
    rooms.leave(room.id, owner.id);
    expect(rooms.get(room.id)).toBeUndefined();
    expect(rooms.list()).toEqual([]);
  });

  it("enforces membership/readiness/ownership and creates a private game view", () => {
    const rooms = new RoomService();
    const room = rooms.create(owner, { name: "测试房", maxPlayers: 2 });
    rooms.join(room.id, guest);
    rooms.setConnected(owner.id, true);
    rooms.setConnected(guest.id, true);
    rooms.setReady(room.id, owner.id, true);
    rooms.setReady(room.id, guest.id, true);

    expect(() => rooms.start(room.id, guest.id)).toThrowError(HttpError);
    const started = rooms.start(room.id, owner.id);
    expect(started.status).toBe("playing");

    const ownerView = rooms.getGameView(room.id, owner.id)!;
    const guestView = rooms.getGameView(room.id, guest.id)!;
    expect(ownerView.players.find((player) => player.id === owner.id)?.hand).not.toBeNull();
    expect(ownerView.players.find((player) => player.id === guest.id)?.hand).toBeNull();
    expect(guestView.players.find((player) => player.id === guest.id)?.hand).not.toBeNull();
    rooms.leave(room.id, guest.id);
    expect(rooms.get(room.id)).toMatchObject({ status: "finished", playerCount: 1 });
    expect(rooms.getGameView(room.id, owner.id)).toMatchObject({
      status: "finished",
      prompt: { type: "finished" },
    });
  });

  it("rejects actions that impersonate another account", () => {
    const rooms = new RoomService();
    const room = rooms.create(owner, { name: "防作弊" });
    rooms.join(room.id, guest);
    rooms.setConnected(owner.id, true);
    rooms.setConnected(guest.id, true);
    rooms.setReady(room.id, owner.id, true);
    rooms.setReady(room.id, guest.id, true);
    rooms.start(room.id, owner.id);

    expect(() => rooms.applyAction(room.id, owner.id, {
      type: "end_play",
      playerId: guest.id,
    })).toThrowError(/不能替其他玩家/);
  });

  it("gives disconnected players a reconnect grace period, then forfeits", () => {
    vi.useFakeTimers();
    try {
      const rooms = new RoomService(1_000);
      const room = rooms.create(owner, { name: "断线托管", maxPlayers: 2 });
      rooms.join(room.id, guest);
      rooms.setConnected(owner.id, true);
      rooms.setConnected(guest.id, true);
      rooms.setReady(room.id, owner.id, true);
      rooms.setReady(room.id, guest.id, true);
      rooms.start(room.id, owner.id);

      rooms.setConnected(guest.id, false);
      vi.advanceTimersByTime(900);
      rooms.setConnected(guest.id, true);
      vi.advanceTimersByTime(200);
      expect(rooms.get(room.id)?.status).toBe("playing");

      rooms.setConnected(guest.id, false);
      vi.advanceTimersByTime(1_000);
      expect(rooms.get(room.id)).toMatchObject({ status: "finished", playerCount: 1 });
    } finally {
      vi.useRealTimers();
    }
  });

  it("removes a disconnected dead member without crashing or ending the match", () => {
    vi.useFakeTimers();
    try {
      const rooms = new RoomService(1_000);
      const room = rooms.create(owner, { name: "阵亡离席", maxPlayers: 3 });
      rooms.join(room.id, guest);
      rooms.join(room.id, third);
      for (const player of [owner, guest, third]) {
        rooms.setConnected(player.id, true);
        rooms.setReady(room.id, player.id, true);
      }
      rooms.start(room.id, owner.id);

      const internalRooms = (rooms as unknown as {
        rooms: Map<string, { game?: GameSession }>;
      }).rooms;
      const game = internalRooms.get(room.id)?.game;
      const deadPlayer = game?.players.find((player) => player.id === guest.id);
      if (!deadPlayer) throw new Error("test game player missing");
      deadPlayer.alive = false;
      deadPlayer.hp = 0;

      rooms.setConnected(guest.id, false);
      expect(() => vi.advanceTimersByTime(1_000)).not.toThrow();
      expect(rooms.get(room.id)).toMatchObject({ status: "playing", playerCount: 2 });
    } finally {
      vi.useRealTimers();
    }
  });

  it("round-trips room and private game state through a restart snapshot", () => {
    const rooms = new RoomService();
    const room = rooms.create(owner, { name: "持久化对局", maxPlayers: 2 });
    rooms.join(room.id, guest);
    rooms.setConnected(owner.id, true);
    rooms.setConnected(guest.id, true);
    rooms.setReady(room.id, owner.id, true);
    rooms.setReady(room.id, guest.id, true);
    rooms.start(room.id, owner.id);

    const serialized = JSON.stringify(rooms.exportSnapshot());
    const restored = new RoomService();
    restored.restoreSnapshot(JSON.parse(serialized));

    expect(restored.get(room.id)).toMatchObject({
      status: "playing",
      playerCount: 2,
      players: [
        { id: owner.id, connected: false },
        { id: guest.id, connected: false },
      ],
    });
    const ownerView = restored.getGameView(room.id, owner.id)!;
    expect(ownerView.players.find((player) => player.id === owner.id)?.hand).not.toBeNull();
    expect(ownerView.players.find((player) => player.id === guest.id)?.hand).toBeNull();
  });
});
