import type { Pool } from "pg";
import { createGame } from "@sanguosha/shared";
import { describe, expect, it, vi } from "vitest";
import {
  loadRoomSnapshot,
  RoomSnapshotWriter,
} from "./room-persistence.js";
import type { RoomServiceSnapshot } from "./rooms.js";

function poolWithQuery(query: Pool["query"]): Pool {
  return { query } as unknown as Pool;
}

describe("room snapshot persistence", () => {
  it("accepts a serializable dying prompt so rescue can continue after restart", async () => {
    const ownerId = "11111111-1111-4111-8111-111111111111";
    const guestId = "22222222-2222-4222-8222-222222222222";
    const game = createGame({ playerIds: [ownerId, guestId], seed: "7".padStart(64, "0") });
    const victim = game.players.find((player) => player.id !== game.currentPlayerId);
    if (!victim) throw new Error("Missing victim");
    victim.hp = 0;
    game.turn.phase = "respond";
    game.pendingResponse = {
      type: "dying",
      victimId: victim.id,
      damageSourceId: game.currentPlayerId,
      targetId: victim.id,
      remainingResponderIds: [game.currentPlayerId],
      resume: { type: "finish_effect" },
    };
    const snapshot: RoomServiceSnapshot = {
      version: 1,
      rooms: [{
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        name: "濒死恢复",
        ownerId,
        status: "playing",
        maxPlayers: 2,
        createdAt: new Date().toISOString(),
        players: [
          { id: ownerId, username: "owner", displayName: "owner", ready: true, connected: false, seat: 0 },
          { id: guestId, username: "guest", displayName: "guest", ready: true, connected: false, seat: 1 },
        ],
        game,
      }],
    };
    const pool = poolWithQuery(vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"]);

    const result = await loadRoomSnapshot(pool);

    expect(result).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "dying", victimId: victim.id } } }] },
    });
  });

  it("rejects an incomplete game before RoomService restoration", async () => {
    const pool = poolWithQuery(vi.fn().mockResolvedValue({
      rows: [{
        snapshot: {
          version: 1,
          rooms: [{
            id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            name: "损坏对局",
            ownerId: "11111111-1111-4111-8111-111111111111",
            status: "playing",
            maxPlayers: 2,
            createdAt: new Date().toISOString(),
            players: [{
              id: "11111111-1111-4111-8111-111111111111",
              username: "owner",
              displayName: "owner",
              ready: true,
              connected: false,
              seat: 0,
            }],
            game: { version: 1 },
          }],
        },
      }],
    }) as Pool["query"]);

    const result = await loadRoomSnapshot(pool);

    expect(result.kind).toBe("invalid");
    if (result.kind === "invalid") expect(result.reason).toContain("Required");
  });

  it("coalesces queued mutations to the newest snapshot", async () => {
    let releaseFirstWrite: (() => void) | undefined;
    const firstWrite = new Promise<void>((resolve) => { releaseFirstWrite = resolve; });
    const query = vi.fn()
      .mockImplementationOnce(async () => {
        await firstWrite;
        return { rows: [] };
      })
      .mockResolvedValue({ rows: [] });
    const writer = new RoomSnapshotWriter(poolWithQuery(query as Pool["query"]), vi.fn());
    const first = { version: 1, rooms: [], marker: "first" } as unknown as RoomServiceSnapshot;
    const middle = { version: 1, rooms: [], marker: "middle" } as unknown as RoomServiceSnapshot;
    const newest = { version: 1, rooms: [], marker: "newest" } as unknown as RoomServiceSnapshot;

    writer.enqueue(first);
    await vi.waitFor(() => expect(query).toHaveBeenCalledTimes(1));
    writer.enqueue(middle);
    writer.enqueue(newest);
    releaseFirstWrite?.();
    await writer.flush();

    expect(query).toHaveBeenCalledTimes(2);
    expect(query.mock.calls[1]?.[1]).toEqual([JSON.stringify(newest)]);
  });
});
