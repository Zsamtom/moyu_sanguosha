import type { Pool } from "pg";
import { z } from "zod";
import type { RoomServiceSnapshot } from "./rooms.js";

const playerIdSchema = z.string().uuid();
const cardKindSchema = z.enum([
  "slash",
  "fire_slash",
  "thunder_slash",
  "dodge",
  "peach",
  "wine",
  "ex_nihilo",
  "duel",
  "barbarian_invasion",
  "arrow_barrage",
  "peach_garden",
  "chi_tu", "da_wan", "zi_xing", "di_lu", "hua_liu", "jue_ying", "zhua_huang_fei_dian",
  "zhu_ge_lian_nu", "gu_ding_dao",
  "ren_wang_dun", "teng_jia", "bai_yin_shi_zi",
]);
const cardSchema = z.object({
  id: z.string().min(1).max(80),
  kind: cardKindSchema,
  // These fields were added without changing the v1 snapshot version. Keep
  // them optional so rooms created by the previous production build migrate.
  name: z.string().min(1).max(20).optional(),
  category: z.enum(["basic", "trick", "equipment"]).optional(),
  suit: z.enum(["spade", "heart", "club", "diamond"]).optional(),
  rank: z.number().int().min(1).max(13).optional(),
});
const gamePlayerSchema = z.object({
  id: playerIdSchema,
  seat: z.number().int().min(0).max(9),
  role: z.enum(["lord", "loyalist", "rebel", "renegade"]),
  hp: z.number().int().min(0).max(10),
  maxHp: z.number().int().min(1).max(10),
  alive: z.boolean(),
  hand: z.array(cardSchema).max(200),
  equipment: z.object({
    weapon: cardSchema.optional(),
    armor: cardSchema.optional(),
    offensive_horse: cardSchema.optional(),
    defensive_horse: cardSchema.optional(),
  }).default({}),
});
const turnSchema = z.object({
  number: z.number().int().positive(),
  playerId: playerIdSchema,
  phase: z.enum(["play", "respond", "discard"]),
  slashUsed: z.boolean(),
  wineUsed: z.boolean().optional(),
  slashDamageBonus: z.number().int().min(0).max(1).optional(),
  requiredDiscardCount: z.number().int().min(0).max(200),
});
const massAttackResponseSchema = z.object({
  type: z.literal("mass_attack"),
  attackerId: playerIdSchema,
  targetId: playerIdSchema,
  cardId: z.string().min(1).max(80),
  cardKind: z.enum(["barbarian_invasion", "arrow_barrage"]),
  responseKind: z.enum(["slash", "dodge"]),
  remainingTargetIds: z.array(playerIdSchema).max(9),
});
const pendingResponseSchema = z.discriminatedUnion("type", [
  z.object({
    type: z.literal("slash"),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    cardId: z.string().min(1).max(80),
    slashKind: z.enum(["slash", "fire_slash", "thunder_slash"]).optional(),
    damage: z.number().int().positive().max(10).optional(),
    nature: z.enum(["normal", "fire", "thunder"]).optional(),
  }),
  z.object({
    type: z.literal("duel"),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    cardId: z.string().min(1).max(80),
    initiatorId: playerIdSchema,
    originalTargetId: playerIdSchema,
  }),
  massAttackResponseSchema,
  z.object({
    type: z.literal("dying"),
    victimId: playerIdSchema,
    damageSourceId: playerIdSchema,
    targetId: playerIdSchema,
    remainingResponderIds: z.array(playerIdSchema).max(9),
    resume: z.union([
      z.object({ type: z.literal("finish_effect") }),
      z.object({ type: z.literal("mass_attack"), pending: massAttackResponseSchema }),
    ]),
  }),
]);
const gameSessionSchema = z.object({
  version: z.literal(1),
  status: z.enum(["playing", "finished"]),
  players: z.array(gamePlayerSchema).min(2).max(10),
  deck: z.array(cardSchema).max(200),
  discardPile: z.array(cardSchema).max(200),
  resolvingCards: z.array(cardSchema).max(200).optional(),
  currentPlayerId: playerIdSchema,
  turn: turnSchema,
  pendingResponse: pendingResponseSchema.nullable(),
  winner: z.object({
    side: z.enum(["lord", "rebel", "renegade"]),
    playerIds: z.array(playerIdSchema).min(1).max(10),
  }).nullable(),
  logs: z.array(z.object({
    id: z.number().int().positive(),
    type: z.enum(["system", "turn", "card", "damage", "death", "victory"]),
    message: z.string().min(1).max(500),
  })).max(500),
  rng: z.object({
    key: z.string().regex(/^[0-9a-f]{64}$/i),
    counter: z.number().int().min(0).max(0xffff_ffff),
  }),
  nextLogId: z.number().int().positive(),
}).superRefine((game, context) => {
  const playerIds = game.players.map((player) => player.id);
  const knownPlayers = new Set(playerIds);
  const issue = (message: string) => context.addIssue({ code: z.ZodIssueCode.custom, message });
  if (knownPlayers.size !== playerIds.length) issue("Game contains duplicate players");
  if (!knownPlayers.has(game.currentPlayerId)) issue("Current player is not in the game");
  if (game.turn.playerId !== game.currentPlayerId) issue("Turn player does not match current player");
  if (game.players.some((player, index) => player.seat !== index)) issue("Game seats are not contiguous");
  if (game.players.some((player) => player.hp > player.maxHp)) issue("Player hp exceeds maxHp");
  const dyingVictimId = game.pendingResponse?.type === "dying" ? game.pendingResponse.victimId : undefined;
  if (game.players.some((player) =>
    (!player.alive && player.hp !== 0) ||
    (player.alive && player.hp <= 0 && player.id !== dyingVictimId)
  )) issue("Player alive flag disagrees with hp");
  const allCards = [
    ...game.deck,
    ...game.discardPile,
    ...(game.resolvingCards ?? []),
    ...game.players.flatMap((player) => player.hand),
    ...game.players.flatMap((player) => Object.values(player.equipment)),
  ];
  if (new Set(allCards.map((card) => card.id)).size !== allCards.length) issue("Card appears in multiple zones");
  if (game.pendingResponse) {
    const relatedIds = game.pendingResponse.type === "dying"
      ? [
          game.pendingResponse.victimId,
          game.pendingResponse.damageSourceId,
          game.pendingResponse.targetId,
          ...game.pendingResponse.remainingResponderIds,
        ]
      : [
          game.pendingResponse.attackerId,
          game.pendingResponse.targetId,
          ...(game.pendingResponse.type === "duel"
            ? [game.pendingResponse.initiatorId, game.pendingResponse.originalTargetId]
            : []),
          ...(game.pendingResponse.type === "mass_attack" ? game.pendingResponse.remainingTargetIds : []),
        ];
    if (relatedIds.some((id) => !knownPlayers.has(id))) issue("Pending response references an unknown player");
    if (game.turn.phase !== "respond") issue("Pending response exists outside respond phase");
  } else if (game.turn.phase === "respond") {
    issue("Respond phase has no pending response");
  }
  if (game.winner?.playerIds.some((id) => !knownPlayers.has(id))) issue("Winner references an unknown player");
  if ((game.status === "finished") !== (game.winner !== null)) issue("Game status and winner disagree");
});

const playerSchema = z.object({
  id: playerIdSchema,
  username: z.string().min(1).max(32),
  displayName: z.string().min(1).max(40),
  ready: z.boolean(),
  connected: z.boolean(),
  seat: z.number().int().min(0).max(9),
  isBot: z.boolean().default(false),
});

const roomSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1).max(40),
  ownerId: playerIdSchema,
  status: z.enum(["waiting", "playing", "finished"]),
  maxPlayers: z.number().int().min(2).max(10),
  createdAt: z.string().datetime(),
  players: z.array(playerSchema).min(1).max(10),
  game: gameSessionSchema.optional(),
}).superRefine((room, context) => {
  const issue = (message: string) => context.addIssue({ code: z.ZodIssueCode.custom, message });
  const playerIds = room.players.map((player) => player.id);
  if (new Set(playerIds).size !== playerIds.length) issue("Room contains duplicate players");
  if (room.players.some((player, index) => player.seat !== index)) issue("Room seats are not contiguous");
  if (!playerIds.includes(room.ownerId)) issue("Room owner is not a member");
  if (room.players.length > room.maxPlayers) issue("Room exceeds maxPlayers");
  if (room.status === "waiting" && room.game) issue("Waiting room unexpectedly contains a game");
  if (room.status !== "waiting" && !room.game) issue("Started room has no game state");
  if (room.game) {
    const gamePlayerIds = room.game.players.map((player) => player.id);
    if (gamePlayerIds.length !== playerIds.length || gamePlayerIds.some((id, index) => id !== playerIds[index])) {
      issue("Room members and game players disagree");
    }
    if (room.status !== room.game.status) issue("Room status and game status disagree");
  }
});

const roomSnapshotSchema = z.object({
  version: z.literal(1),
  rooms: z.array(roomSchema).max(1_000),
}).superRefine((snapshot, context) => {
  const roomIds = snapshot.rooms.map((room) => room.id);
  const userIds = snapshot.rooms.flatMap((room) => room.players.map((player) => player.id));
  if (new Set(roomIds).size !== roomIds.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "Snapshot contains duplicate rooms" });
  }
  if (new Set(userIds).size !== userIds.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "User appears in multiple rooms" });
  }
});

export type RoomSnapshotLoadResult =
  | { readonly kind: "empty" }
  | { readonly kind: "valid"; readonly snapshot: RoomServiceSnapshot }
  | { readonly kind: "invalid"; readonly reason: string };

export async function loadRoomSnapshot(pool: Pool): Promise<RoomSnapshotLoadResult> {
  const result = await pool.query<{ snapshot: unknown }>(
    "SELECT snapshot FROM room_state WHERE id = 1",
  );
  const value = result.rows[0]?.snapshot;
  if (value === undefined) return { kind: "empty" };
  const parsed = roomSnapshotSchema.safeParse(value);
  if (!parsed.success) {
    return { kind: "invalid", reason: parsed.error.issues.map((issue) => issue.message).join("; ").slice(0, 2_000) };
  }
  return { kind: "valid", snapshot: parsed.data as unknown as RoomServiceSnapshot };
}

export async function quarantineInvalidRoomSnapshot(pool: Pool, reason: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO room_state_quarantine (snapshot, reason)
       SELECT snapshot, $1 FROM room_state WHERE id = 1`,
      [reason],
    );
    await client.query("DELETE FROM room_state WHERE id = 1");
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function saveRoomSnapshot(pool: Pool, snapshot: RoomServiceSnapshot): Promise<void> {
  await pool.query(
    `INSERT INTO room_state (id, snapshot, updated_at)
     VALUES (1, $1::jsonb, NOW())
     ON CONFLICT (id) DO UPDATE SET snapshot = EXCLUDED.snapshot, updated_at = NOW()`,
    [JSON.stringify(snapshot)],
  );
}

/**
 * Keeps at most one unsaved snapshot. A burst of game actions therefore
 * coalesces to the newest state instead of building an unbounded Promise queue.
 * A transient database failure leaves the snapshot dirty and retries it.
 */
export class RoomSnapshotWriter {
  private pending: RoomServiceSnapshot | undefined;
  private running: Promise<void> | undefined;
  private retryTimer: NodeJS.Timeout | undefined;
  private stopped = false;

  constructor(
    private readonly pool: Pool,
    private readonly onError: (error: unknown) => void,
    private readonly retryMs = 1_000,
  ) {}

  enqueue(snapshot: RoomServiceSnapshot): void {
    this.pending = snapshot;
    if (!this.stopped) this.start();
  }

  private start(): void {
    if (this.running || !this.pending || this.stopped) return;
    const operation = this.drain();
    this.running = operation;
    void operation
      .catch(this.onError)
      .finally(() => {
        if (this.running === operation) this.running = undefined;
        if (this.pending && !this.stopped && !this.retryTimer) {
          this.retryTimer = setTimeout(() => {
            this.retryTimer = undefined;
            this.start();
          }, this.retryMs);
          this.retryTimer.unref();
        }
      });
  }

  private async drain(): Promise<void> {
    while (this.pending) {
      const snapshot = this.pending;
      this.pending = undefined;
      try {
        await saveRoomSnapshot(this.pool, snapshot);
      } catch (error) {
        // Keep the newer state if another mutation arrived during the write.
        this.pending ??= snapshot;
        throw error;
      }
    }
  }

  async flush(snapshot?: RoomServiceSnapshot): Promise<void> {
    if (snapshot) this.pending = snapshot;
    this.stopped = true;
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = undefined;
    if (this.running) {
      try {
        await this.running;
      } catch {
        // Retry the retained dirty snapshot once synchronously below.
      }
    }
    await this.drain();
  }
}
