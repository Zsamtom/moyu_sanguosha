# Ubuntu 部署

目标机器需要 Docker、Docker Compose、Nginx 和 Certbot。

1. 将项目同步到 `/opt/sanguosha-online`。
2. 在该目录创建 `.env`，至少设置：
   - `POSTGRES_PASSWORD`
   - `SESSION_SECRET`
   - `INITIAL_ADMIN_USERNAME`
   - `INITIAL_ADMIN_PASSWORD`
   - `APP_ORIGIN=https://moyu.pdcat.cn`

   `POSTGRES_PASSWORD` 会进入 PostgreSQL 连接 URL，请使用 URL-safe 随机字符（字母、数字、`_`、`-`），或先进行 URL 编码。
3. 执行 `docker compose up -d --build`。
4. 将 `nginx-moyu.conf` 放入 `/etc/nginx/sites-available/moyu.pdcat.cn` 并启用。
5. 通过 `nginx -t` 后重载 Nginx。
6. 域名解析生效后执行：

   ```bash
   certbot --nginx -d moyu.pdcat.cn --redirect
   ```

应用容器不会直接暴露到公网，只绑定宿主机 `127.0.0.1:3100`。Socket.IO 路径必须保留 Upgrade 请求头。
