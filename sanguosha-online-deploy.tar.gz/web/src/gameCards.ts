export const standardCardKinds = [
  'slash',
  'fire_slash',
  'thunder_slash',
  'dodge',
  'peach',
  'wine',
  'ex_nihilo',
  'duel',
  'barbarian_invasion',
  'arrow_barrage',
  'peach_garden',
  'chi_tu', 'da_wan', 'zi_xing', 'di_lu', 'hua_liu', 'jue_ying', 'zhua_huang_fei_dian',
  'zhu_ge_lian_nu', 'gu_ding_dao',
  'ren_wang_dun', 'teng_jia', 'bai_yin_shi_zi',
] as const;

export type StandardCardKind = (typeof standardCardKinds)[number];
export type CardCategory = 'basic' | 'trick' | 'equipment';
export type CardTargetMode = 'none' | 'self' | 'single-other';

export interface CardPresentation {
  readonly name: string;
  readonly category: CardCategory;
  readonly description: string;
  readonly targetMode: CardTargetMode;
}

export const cardCatalog: Record<StandardCardKind, CardPresentation> = {
  slash: {
    name: '杀',
    category: 'basic',
    description: '出牌阶段，对一名其他角色使用。目标需打出「闪」，否则受到 1 点伤害。',
    targetMode: 'single-other',
  },
  fire_slash: {
    name: '火杀',
    category: 'basic',
    description: '火属性的「杀」。目标需打出「闪」，否则受到 1 点火焰伤害。',
    targetMode: 'single-other',
  },
  thunder_slash: {
    name: '雷杀',
    category: 'basic',
    description: '雷属性的「杀」。目标需打出「闪」，否则受到 1 点雷电伤害。',
    targetMode: 'single-other',
  },
  dodge: {
    name: '闪',
    category: 'basic',
    description: '响应「杀」或「万箭齐发」时打出，抵消此次伤害。',
    targetMode: 'none',
  },
  peach: {
    name: '桃',
    category: 'basic',
    description: '出牌阶段使用，回复 1 点体力。体力已满时不能使用。',
    targetMode: 'self',
  },
  wine: {
    name: '酒',
    category: 'basic',
    description: '出牌阶段使用，本回合下一张「杀」造成的伤害 +1。',
    targetMode: 'none',
  },
  ex_nihilo: {
    name: '无中生有',
    category: 'trick',
    description: '出牌阶段使用，你摸两张牌。',
    targetMode: 'none',
  },
  duel: {
    name: '决斗',
    category: 'trick',
    description: '选择一名其他角色，由其开始与你轮流打出「杀」；首先不出「杀」的一方受到 1 点伤害。',
    targetMode: 'single-other',
  },
  barbarian_invasion: {
    name: '南蛮入侵',
    category: 'trick',
    description: '所有其他角色依次需打出一张「杀」，否则受到 1 点伤害。',
    targetMode: 'none',
  },
  arrow_barrage: {
    name: '万箭齐发',
    category: 'trick',
    description: '所有其他角色依次需打出一张「闪」，否则受到 1 点伤害。',
    targetMode: 'none',
  },
  peach_garden: {
    name: '桃园结义',
    category: 'trick',
    description: '所有已受伤角色各回复 1 点体力。',
    targetMode: 'none',
  },
  chi_tu: { name: '赤兔', category: 'equipment', description: '进攻坐骑：你计算与其他角色的距离 -1。', targetMode: 'self' },
  da_wan: { name: '大宛', category: 'equipment', description: '进攻坐骑：你计算与其他角色的距离 -1。', targetMode: 'self' },
  zi_xing: { name: '紫骍', category: 'equipment', description: '进攻坐骑：你计算与其他角色的距离 -1。', targetMode: 'self' },
  di_lu: { name: '的卢', category: 'equipment', description: '防御坐骑：其他角色计算与你的距离 +1。', targetMode: 'self' },
  hua_liu: { name: '骅骝', category: 'equipment', description: '防御坐骑：其他角色计算与你的距离 +1。', targetMode: 'self' },
  jue_ying: { name: '绝影', category: 'equipment', description: '防御坐骑：其他角色计算与你的距离 +1。', targetMode: 'self' },
  zhua_huang_fei_dian: { name: '爪黄飞电', category: 'equipment', description: '防御坐骑：其他角色计算与你的距离 +1。', targetMode: 'self' },
  zhu_ge_lian_nu: { name: '诸葛连弩', category: 'equipment', description: '武器，范围 1：出牌阶段使用「杀」无次数限制。', targetMode: 'self' },
  gu_ding_dao: { name: '古锭刀', category: 'equipment', description: '武器，范围 2：使用「杀」命中没有手牌的目标时伤害 +1。', targetMode: 'self' },
  ren_wang_dun: { name: '仁王盾', category: 'equipment', description: '防具：黑色的「杀」对你无效。', targetMode: 'self' },
  teng_jia: { name: '藤甲', category: 'equipment', description: '防具：南蛮、万箭和普通杀对你无效；受到火焰伤害时伤害 +1。', targetMode: 'self' },
  bai_yin_shi_zi: { name: '白银狮子', category: 'equipment', description: '防具：受到超过 1 点的伤害时改为 1；失去此装备时回复 1 点体力。', targetMode: 'self' },
};

export function isStandardCardKind(value: unknown): value is StandardCardKind {
  return typeof value === 'string' && (standardCardKinds as readonly string[]).includes(value);
}

export function cardPresentation(kind: string): CardPresentation | undefined {
  return isStandardCardKind(kind) ? cardCatalog[kind] : undefined;
}

export function formatCardRank(rank: number | string | undefined): string {
  const numeric = typeof rank === 'number' ? rank : Number(rank);
  if (!Number.isInteger(numeric) || numeric < 1 || numeric > 13) return '·';
  if (numeric === 1) return 'A';
  if (numeric === 11) return 'J';
  if (numeric === 12) return 'Q';
  if (numeric === 13) return 'K';
  return String(numeric);
}
