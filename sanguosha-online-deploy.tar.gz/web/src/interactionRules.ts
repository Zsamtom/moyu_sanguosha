import { cardPresentation, isStandardCardKind } from './gameCards';
import type { ActionPrompt, GameCard, RoomDetail } from './types';

export function getRoomStartBlockReason(room: RoomDetail, connected: boolean): string | undefined {
  if (!connected) return '实时连接恢复后才能开局';
  if (room.members.length < 2) return '至少需要两名玩家';
  if (!room.members.every((member) => member.online)) return '有玩家离线，全部玩家在线后才能开局';
  if (!room.members.every((member) => member.ready)) return '所有玩家准备后才能开局';
  return undefined;
}

export const surrenderCopy = {
  label: '投降并离开',
  title: '确定投降并离开？',
  description: '此操作会判定你放弃本局，并结束你的个人参与，无法撤销。',
} as const;

export function cardRequiresTarget(card: GameCard): boolean {
  if (card.targetMode) return card.targetMode === 'single-other';
  if (!card.kind || !isStandardCardKind(card.kind)) return Boolean(card.allowedTargetIds?.length);
  return cardPresentation(card.kind)?.targetMode === 'single-other';
}

export function canSubmitCardPlay(card: GameCard | undefined, selectedTargetIds: readonly string[]): boolean {
  if (!card || card.playable === false) return false;
  if (!cardRequiresTarget(card)) return true;
  if (selectedTargetIds.length !== 1) return false;
  return !card.allowedTargetIds || card.allowedTargetIds.includes(selectedTargetIds[0]!);
}

export function cardPlayButtonLabel(card: GameCard | undefined): string {
  if (!card) return '使用此牌';
  return cardRequiresTarget(card) ? `对目标使用「${card.name}」` : `使用「${card.name}」`;
}

export function responseCardName(prompt: ActionPrompt | null | undefined): string {
  if (prompt?.kind === 'respond-peach') return '桃 / 酒';
  return prompt?.responseKind === 'slash' || prompt?.kind === 'respond-slash' ? '杀' : '闪';
}

export function isCardResponsePrompt(prompt: ActionPrompt | null | undefined): boolean {
  return prompt?.kind === 'respond-slash' || prompt?.kind === 'respond-dodge' || prompt?.kind === 'respond-peach';
}

export function isCardAllowedByPrompt(card: GameCard, prompt: ActionPrompt | null | undefined): boolean {
  if (!prompt) return card.playable !== false;
  if (prompt.allowedCardIds && !prompt.allowedCardIds.includes(card.id)) return false;
  if (prompt.kind === 'respond-slash') {
    return card.kind === 'slash' || card.kind === 'fire_slash' || card.kind === 'thunder_slash';
  }
  if (prompt.kind === 'respond-dodge') return card.kind === 'dodge';
  if (prompt.kind === 'respond-peach') return card.kind === 'peach' || card.kind === 'wine';
  return true;
}
