import { describe, expect, it } from 'vitest';
import {
  canSubmitCardPlay,
  cardPlayButtonLabel,
  cardRequiresTarget,
  getRoomStartBlockReason,
  isCardAllowedByPrompt,
  isCardResponsePrompt,
  responseCardName,
  surrenderCopy,
} from './interactionRules';
import type { ActionPrompt, GameCard, RoomDetail } from './types';

function roomWith(overrides: Partial<RoomDetail> = {}): RoomDetail {
  return {
    id: 'room-1',
    name: '测试房间',
    status: 'waiting',
    hostId: 'user-1',
    hostName: '房主',
    playerCount: 2,
    maxPlayers: 5,
    members: [
      { userId: 'user-1', username: 'owner', displayName: '房主', seat: 0, ready: true, online: true, isHost: true },
      { userId: 'user-2', username: 'player', displayName: '玩家', seat: 1, ready: true, online: true, isHost: false },
    ],
    ...overrides,
  };
}

describe('room start rules', () => {
  it('allows starting only when connected and every player is online and ready', () => {
    expect(getRoomStartBlockReason(roomWith(), true)).toBeUndefined();
    expect(getRoomStartBlockReason(roomWith(), false)).toContain('连接');
  });

  it('blocks starting while any seated player is offline', () => {
    const room = roomWith();
    room.members[1] = { ...room.members[1]!, online: false };
    expect(getRoomStartBlockReason(room, true)).toContain('离线');
  });

  it('blocks starting while any seated player is not ready', () => {
    const room = roomWith();
    room.members[1] = { ...room.members[1]!, ready: false };
    expect(getRoomStartBlockReason(room, true)).toContain('准备');
  });
});

describe('active-game exit copy', () => {
  it('makes surrender consequences explicit before invoking the exit flow', () => {
    expect(surrenderCopy.label).toBe('投降并离开');
    expect(surrenderCopy.title).toContain('确定');
    expect(surrenderCopy.description).toMatch(/放弃本局.*结束你的个人参与/);
  });
});

function gameCard(overrides: Partial<GameCard>): GameCard {
  return {
    id: 'card-1',
    name: '无中生有',
    kind: 'ex_nihilo',
    suit: 'heart',
    rank: '7',
    category: 'trick',
    playable: true,
    ...overrides,
  };
}

describe('standard-card interaction rules', () => {
  it.each(['slash', 'fire_slash', 'thunder_slash', 'duel'] as const)(
    'requires exactly one legal target for %s',
    (kind) => {
      const card = gameCard({ kind, name: kind, targetMode: 'single-other', allowedTargetIds: ['user-2'] });
      expect(cardRequiresTarget(card)).toBe(true);
      expect(canSubmitCardPlay(card, [])).toBe(false);
      expect(canSubmitCardPlay(card, ['user-3'])).toBe(false);
      expect(canSubmitCardPlay(card, ['user-2'])).toBe(true);
    },
  );

  it.each(['wine', 'ex_nihilo', 'barbarian_invasion', 'arrow_barrage', 'peach_garden'] as const)(
    'can submit %s without selecting a target',
    (kind) => {
      const card = gameCard({ kind, name: kind, targetMode: 'none' });
      expect(cardRequiresTarget(card)).toBe(false);
      expect(canSubmitCardPlay(card, [])).toBe(true);
    },
  );

  it('uses Peach on self without requiring a player-panel selection', () => {
    const peach = gameCard({ kind: 'peach', name: '桃', targetMode: 'self', allowedTargetIds: ['user-1'] });
    expect(cardRequiresTarget(peach)).toBe(false);
    expect(canSubmitCardPlay(peach, [])).toBe(true);
  });

  it('uses card-specific play copy and generic slash/dodge response copy', () => {
    expect(cardPlayButtonLabel(gameCard({ name: '决斗', kind: 'duel', targetMode: 'single-other' }))).toBe('对目标使用「决斗」');
    expect(cardPlayButtonLabel(gameCard({ name: '无中生有', kind: 'ex_nihilo', targetMode: 'none' }))).toBe('使用「无中生有」');

    const slashPrompt = { id: 'p1', kind: 'respond-slash', message: '请出杀', responseKind: 'slash' } as const;
    const dodgePrompt = { id: 'p2', kind: 'respond-dodge', message: '请出闪', responseKind: 'dodge' } as const;
    expect(isCardResponsePrompt(slashPrompt)).toBe(true);
    expect(responseCardName(slashPrompt)).toBe('杀');
    expect(responseCardName(dodgePrompt)).toBe('闪');
  });

  it('accepts every slash nature for a slash response and rejects unrelated cards', () => {
    const prompt: ActionPrompt = {
      id: 'duel-response',
      kind: 'respond-slash',
      message: '请出杀',
      responseKind: 'slash',
      allowedCardIds: ['slash', 'fire', 'thunder'],
    };

    expect(isCardAllowedByPrompt(gameCard({ id: 'slash', kind: 'slash' }), prompt)).toBe(true);
    expect(isCardAllowedByPrompt(gameCard({ id: 'fire', kind: 'fire_slash' }), prompt)).toBe(true);
    expect(isCardAllowedByPrompt(gameCard({ id: 'thunder', kind: 'thunder_slash' }), prompt)).toBe(true);
    expect(isCardAllowedByPrompt(gameCard({ id: 'dodge', kind: 'dodge' }), prompt)).toBe(false);
  });

  it('allows Peach or Wine only when listed by a dying rescue prompt', () => {
    const prompt: ActionPrompt = {
      id: 'dying-response',
      kind: 'respond-peach',
      message: '濒死救援',
      allowedCardIds: ['peach', 'wine'],
    };

    expect(isCardAllowedByPrompt(gameCard({ id: 'peach', kind: 'peach' }), prompt)).toBe(true);
    expect(isCardAllowedByPrompt(gameCard({ id: 'wine', kind: 'wine' }), prompt)).toBe(true);
    expect(isCardAllowedByPrompt(gameCard({ id: 'slash', kind: 'slash' }), prompt)).toBe(false);
    expect(responseCardName(prompt)).toBe('桃 / 酒');
  });
});
