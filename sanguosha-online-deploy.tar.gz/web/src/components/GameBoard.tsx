import { Alert, Button, Divider, Empty, Popconfirm, Tag, Tooltip } from 'antd';
import { useEffect, useMemo, useRef, useState } from 'react';
import {
  canSubmitCardPlay,
  cardPlayButtonLabel,
  cardRequiresTarget,
  isCardAllowedByPrompt,
  isCardResponsePrompt,
  responseCardName,
  surrenderCopy,
} from '../interactionRules';
import type { GameAction, GameCard, GameLogEntry, GamePlayerView, GameView } from '../types';

interface GameBoardProps {
  game: GameView;
  connected: boolean;
  onAction: (action: GameAction) => Promise<void>;
  onExit: () => Promise<void>;
}

const phaseNames: Record<string, string> = {
  prepare: '准备阶段',
  judge: '判定阶段',
  draw: '摸牌阶段',
  play: '出牌阶段',
  respond: '响应阶段',
  discard: '弃牌阶段',
  end: '结束阶段',
  waiting: '等待响应',
};

const suitSymbols: Record<GameCard['suit'], string> = {
  spade: '♠',
  heart: '♥',
  club: '♣',
  diamond: '♦',
  none: '·',
};

function isRedSuit(suit: GameCard['suit']) {
  return suit === 'heart' || suit === 'diamond';
}

function categoryName(card: GameCard): string {
  if (card.category === 'basic') return '基本牌';
  if (card.category === 'equipment') return '装备牌';
  if (card.category === 'trick') return '锦囊牌';
  return '卡牌';
}

function cardStamp(card: GameCard): string {
  if (card.kind === 'fire_slash') return '火';
  if (card.kind === 'thunder_slash') return '雷';
  if (card.category === 'trick') return '谋';
  return '令';
}

function GameCardTile({
  card,
  selected,
  disabled,
  onClick,
}: {
  card: GameCard;
  selected: boolean;
  disabled: boolean;
  onClick: () => void;
}) {
  const red = isRedSuit(card.suit);
  return (
    <button
      type="button"
      className={`game-card${selected ? ' game-card--selected' : ''}${disabled ? ' game-card--disabled' : ''}`}
      onClick={onClick}
      disabled={disabled}
      aria-pressed={selected}
      aria-label={`${card.name}，${categoryName(card)}，${card.rank}${suitSymbols[card.suit]}。${card.description ?? ''}`}
      data-card-kind={card.kind}
    >
      <span className={red ? 'game-card__corner game-card__corner--red' : 'game-card__corner'}>
        <b>{card.rank}</b>{suitSymbols[card.suit]}
      </span>
      <strong>{card.name}</strong>
      <small>{categoryName(card)}</small>
      <span className="game-card__stamp">{cardStamp(card)}</span>
    </button>
  );
}

function PlayerPanel({
  player,
  selectable,
  selected,
  onSelect,
}: {
  player: GamePlayerView;
  selectable: boolean;
  selected: boolean;
  onSelect: () => void;
}) {
  return (
    <button
      type="button"
      className={`battle-player${player.isSelf ? ' battle-player--self' : ''}${player.isCurrent ? ' battle-player--current' : ''}${!player.alive ? ' battle-player--dead' : ''}${selectable ? ' battle-player--selectable' : ''}${selected ? ' battle-player--selected' : ''}`}
      onClick={onSelect}
      disabled={!selectable}
      aria-pressed={selected}
    >
      <div className="battle-player__topline">
        <span>席 {player.seat + 1}</span>
        <span className={player.online ? 'online-dot' : 'online-dot online-dot--off'}>{player.online ? '在线' : '离线'}</span>
      </div>
      <div className="battle-player__name">
        <span className="general-mark">{(player.general ?? player.displayName).slice(0, 1)}</span>
        <span>
          <strong>{player.general ?? '未知武将'}</strong>
          <small>{player.displayName}</small>
        </span>
        {player.identity && <Tag color={player.identity === '主公' ? 'gold' : 'default'}>{player.identity}</Tag>}
      </div>
      <div className="health-row" aria-label={`体力 ${player.hp} / ${player.maxHp}`}>
        {Array.from({ length: player.maxHp }, (_, index) => (
          <span key={index} className={index < player.hp ? 'health-point health-point--full' : 'health-point'}>命</span>
        ))}
      </div>
      <div className="battle-player__meta">
        <span>手牌 <b>{player.handCount}</b></span>
        <span>{player.faction ?? '未知势力'}</span>
      </div>
      {player.equipment && player.equipment.length > 0 && (
        <div className="equipment-row">
          {player.equipment.map((item) => <span key={`${item.slot}-${item.name}`}>{item.name}</span>)}
        </div>
      )}
      {player.isCurrent && <span className="turn-ribbon">当前回合</span>}
      {!player.alive && <span className="dead-stamp">阵亡</span>}
    </button>
  );
}

function BattleLog({ logs }: { logs: GameLogEntry[] }) {
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  }, [logs]);

  return (
    <aside className="battle-log paper-card" aria-label="实时战报">
      <div className="battle-log__heading">
        <div><span className="live-pulse" />实时战报</div>
        <small>{logs.length} 条</small>
      </div>
      <div className="battle-log__entries" aria-live="polite">
        {logs.length === 0 ? (
          <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="战报将在这里出现" />
        ) : logs.map((log) => (
          <div key={log.id} className={`log-entry log-entry--${log.tone ?? 'normal'}`}>
            <time>{log.at ? new Date(log.at).toLocaleTimeString('zh-CN', { hour12: false, hour: '2-digit', minute: '2-digit' }) : '·'}</time>
            <p>{log.text}</p>
          </div>
        ))}
        <div ref={endRef} />
      </div>
    </aside>
  );
}

export function GameBoard({ game, connected, onAction, onExit }: GameBoardProps) {
  const [selectedCardIds, setSelectedCardIds] = useState<string[]>([]);
  const [selectedTargetIds, setSelectedTargetIds] = useState<string[]>([]);
  const [sending, setSending] = useState(false);
  const [exiting, setExiting] = useState(false);

  useEffect(() => {
    setSelectedCardIds([]);
    setSelectedTargetIds([]);
  }, [game.prompt?.id, game.phase, game.turnPlayerId]);

  const self = game.players.find((player) => player.isSelf || player.id === game.selfPlayerId);
  const currentPlayer = game.players.find((player) => player.id === game.turnPlayerId || player.isCurrent);
  const selectedCard = game.hand.find((card) => card.id === selectedCardIds[0]);
  const isDiscardPrompt = game.prompt?.kind === 'discard';
  const isResponsePrompt = isCardResponsePrompt(game.prompt);
  const canUseCards = connected && (game.canAct || Boolean(game.prompt));
  const requiresTarget = selectedCard ? cardRequiresTarget(selectedCard) : false;

  const selectableTargetIds = useMemo(() => {
    if (game.prompt?.allowedTargetIds) return new Set(game.prompt.allowedTargetIds);
    if (selectedCard && cardRequiresTarget(selectedCard)) {
      if (selectedCard?.allowedTargetIds) return new Set(selectedCard.allowedTargetIds);
      return new Set(game.players.filter((player) => player.alive && !player.isSelf).map((player) => player.id));
    }
    return new Set<string>();
  }, [game.players, game.prompt?.allowedTargetIds, selectedCard]);

  const toggleCard = (card: GameCard) => {
    if (isDiscardPrompt) {
      setSelectedCardIds((current) => {
        if (current.includes(card.id)) return current.filter((id) => id !== card.id);
        const max = game.prompt?.max ?? Number.POSITIVE_INFINITY;
        return current.length < max ? [...current, card.id] : current;
      });
      return;
    }
    setSelectedCardIds((current) => current[0] === card.id ? [] : [card.id]);
    setSelectedTargetIds([]);
  };

  const cardDisabled = (card: GameCard) => {
    if (!canUseCards) return true;
    if (!isCardAllowedByPrompt(card, game.prompt)) return true;
    return false;
  };

  const send = async (action: GameAction) => {
    setSending(true);
    try {
      await onAction(action);
      setSelectedCardIds([]);
      setSelectedTargetIds([]);
    } finally {
      setSending(false);
    }
  };

  const exitGame = async () => {
    setExiting(true);
    try {
      await onExit();
    } catch {
      // App owns the user-facing error toast; keep the player in the game on failure.
    } finally {
      setExiting(false);
    }
  };

  const playCard = async () => {
    if (!selectedCard) return;
    const targetId = cardRequiresTarget(selectedCard) ? selectedTargetIds[0] : undefined;
    await send({ type: 'play_card', playerId: game.selfPlayerId, cardId: selectedCard.id, targetId });
  };

  const respond = async () => {
    if (!selectedCard) return;
    await send({ type: 'respond', playerId: game.selfPlayerId, cardId: selectedCard.id });
  };

  const confirmDiscard = async () => {
    await send({ type: 'discard', playerId: game.selfPlayerId, cardIds: selectedCardIds });
  };

  const toggleTarget = (player: GamePlayerView) => {
    if (!selectableTargetIds.has(player.id)) return;
    setSelectedTargetIds((current) => current.includes(player.id) ? [] : [player.id]);
  };

  const discardMin = game.prompt?.min ?? 0;
  const discardMax = game.prompt?.max ?? discardMin;
  const discardValid = selectedCardIds.length >= discardMin && selectedCardIds.length <= discardMax;
  const playValid = canSubmitCardPlay(selectedCard, selectedTargetIds);

  return (
    <main className="game-page">
      <section className="game-statusbar">
        <div>
          <span className="game-statusbar__round">第 {game.round} 轮</span>
          <strong>{phaseNames[game.phase] ?? game.phase}</strong>
          <span>{currentPlayer ? `${currentPlayer.displayName} 的回合` : '等待服务器推进'}</span>
        </div>
        <div>
          <Tag color={connected ? 'green' : 'orange'}>{connected ? '实时同步' : '重连中'}</Tag>
          {self?.identity && <Tag color="gold">你的身份：{self.identity}</Tag>}
          {game.status === 'playing' && (
            <Popconfirm
              title={surrenderCopy.title}
              description={surrenderCopy.description}
              okText="确认投降"
              cancelText="继续对局"
              okButtonProps={{ danger: true }}
              onConfirm={() => void exitGame()}
            >
              <Button className="game-surrender-button" danger size="small" loading={exiting}>
                {surrenderCopy.label}
              </Button>
            </Popconfirm>
          )}
        </div>
      </section>

      {!connected && <Alert banner type="warning" message="连接中断：当前操作已锁定，状态会在重连后自动同步。" />}

      <div className="game-layout">
        <section className="battlefield">
          {game.prompt && (
            <div className="action-prompt" role="status">
              <span className="action-prompt__mark">令</span>
              <div><strong>{isDiscardPrompt ? '请完成弃牌' : '需要你的响应'}</strong><p>{game.prompt.message}</p></div>
              {isDiscardPrompt && <Tag color="volcano">已选 {selectedCardIds.length} / {discardMin === discardMax ? discardMin : `${discardMin}-${discardMax}`}</Tag>}
            </div>
          )}

          <div className="players-grid">
            {game.players.map((player) => (
              <PlayerPanel
                key={player.id}
                player={player}
                selectable={connected && selectableTargetIds.has(player.id)}
                selected={selectedTargetIds.includes(player.id)}
                onSelect={() => toggleTarget(player)}
              />
            ))}
          </div>

          <section className="hand-zone paper-card" aria-label="你的手牌">
            <div className="hand-zone__heading">
              <div>
                <span className="section-kicker">你的手牌</span>
                <h2>{game.hand.length} 张</h2>
              </div>
              <p>{requiresTarget ? '请选择一名高亮目标，再确认出牌。' : isDiscardPrompt ? `请选择 ${discardMin === discardMax ? discardMin : `${discardMin}—${discardMax}`} 张牌弃置。` : '点击卡牌查看牌面说明和可用操作。'}</p>
            </div>
            <div className="hand-cards">
              {game.hand.length === 0 ? (
                <Empty image={Empty.PRESENTED_IMAGE_SIMPLE} description="当前没有手牌" />
              ) : game.hand.map((card) => (
                <Tooltip key={card.id} title={card.description} placement="top">
                  <span>
                    <GameCardTile
                      card={card}
                      selected={selectedCardIds.includes(card.id)}
                      disabled={cardDisabled(card)}
                      onClick={() => toggleCard(card)}
                    />
                  </span>
                </Tooltip>
              ))}
            </div>
            {selectedCard && !isDiscardPrompt && (
              <div className="card-inspector" role="status" aria-label={`${selectedCard.name}卡牌说明`}>
                <span className={isRedSuit(selectedCard.suit) ? 'card-inspector__face card-inspector__face--red' : 'card-inspector__face'}>
                  {selectedCard.rank}{suitSymbols[selectedCard.suit]}
                </span>
                <div>
                  <div className="card-inspector__title">
                    <strong>{selectedCard.name}</strong>
                    <Tag color={selectedCard.category === 'trick' ? 'purple' : 'default'}>{categoryName(selectedCard)}</Tag>
                  </div>
                  <p>{selectedCard.description ?? '暂无卡牌说明。'}</p>
                </div>
              </div>
            )}
            <Divider />
            <div className="game-actions">
              {isResponsePrompt ? (
                <>
                  <Button
                    type="primary"
                    size="large"
                    disabled={!selectedCard || !connected}
                    loading={sending}
                    onClick={() => void respond()}
                  >
                    打出「{responseCardName(game.prompt)}」
                  </Button>
                  <Button
                    size="large"
                    disabled={!connected}
                    loading={sending}
                    onClick={() => void send({ type: 'respond', playerId: game.selfPlayerId, cardId: null })}
                  >
                    跳过响应
                  </Button>
                </>
              ) : isDiscardPrompt ? (
                <Button
                  type="primary"
                  size="large"
                  disabled={!discardValid || !connected}
                  loading={sending}
                  onClick={() => void confirmDiscard()}
                >
                  确认弃牌（{selectedCardIds.length}）
                </Button>
              ) : (
                <>
                  <Button
                    className="primary-ink-button"
                    type="primary"
                    size="large"
                    disabled={!playValid || !game.canAct || !connected}
                    loading={sending}
                    onClick={() => void playCard()}
                  >
                    {cardPlayButtonLabel(selectedCard)}
                  </Button>
                  <Button
                    size="large"
                    disabled={!game.canAct || !connected}
                    loading={sending}
                    onClick={() => void send({ type: 'end_play', playerId: game.selfPlayerId })}
                  >
                    结束出牌
                  </Button>
                </>
              )}
              {!selectedCard && !isDiscardPrompt && <span className="action-hint">先选择一张可用手牌</span>}
            </div>
          </section>
        </section>

        <BattleLog logs={game.logs ?? []} />
      </div>

      {game.status === 'finished' && (
        <div className="game-result" role="dialog" aria-modal="true" aria-label="对局结束">
          <div className="paper-card game-result__card">
            <span className="game-result__seal">终</span>
            <span className="section-kicker">对局结束</span>
            <h2>{game.winner ? `${game.winner} 获胜` : '胜负已定'}</h2>
            <p>完整过程已保留在右侧战报中。</p>
            <Button className="primary-ink-button" type="primary" size="large" loading={exiting} onClick={() => void exitGame()}>
              返回房间大厅
            </Button>
          </div>
        </div>
      )}
    </main>
  );
}
