import { describe, expect, it } from 'vitest';
import { normalizeGameView, normalizeRoomDetail } from './types';

describe('server payload adapters', () => {
  it('normalizes the server room view and identifies the owner', () => {
    const room = normalizeRoomDetail({
      id: 'room-1',
      name: '桃园结义',
      ownerId: 'user-1',
      ownerName: '玄德',
      status: 'waiting',
      playerCount: 2,
      maxPlayers: 5,
      players: [
        { id: 'user-1', username: 'liubei', displayName: '玄德', ready: true, connected: true, seat: 0 },
        { id: 'user-2', username: 'guanyu', displayName: '云长', ready: false, connected: false, seat: 1 },
      ],
    });

    expect(room.hostId).toBe('user-1');
    expect(room.hostName).toBe('玄德');
    expect(room.members[0]).toMatchObject({ userId: 'user-1', isHost: true, online: true });
    expect(room.members[1]).toMatchObject({ userId: 'user-2', isHost: false, online: false });
  });

  it('turns a private engine view into playable UI state', () => {
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 4, maxHp: 4, handCount: 2, equipment: [
          { id: 'horse-1', kind: 'chi_tu', name: '赤兔', suit: 'heart', rank: 5, category: 'equipment' },
        ], hand: [
          { id: 'card-1', kind: 'slash' },
          { id: 'card-2', kind: 'peach' },
        ], role: 'lord' },
        { id: 'user-2', seat: 1, alive: true, hp: 3, maxHp: 4, handCount: 1, hand: null, role: null },
      ],
      currentPlayerId: 'user-1',
      turn: { number: 2, playerId: 'user-1', phase: 'play', slashUsed: false, requiredDiscardCount: 0 },
      pendingResponse: null,
      winner: null,
      logs: [{ id: 1, type: 'turn', message: 'user-1 的回合开始' }],
      prompt: {
        type: 'play',
        playerId: 'user-1',
        cards: [
          { cardId: 'card-1', kind: 'slash', targetIds: ['user-2'] },
          { cardId: 'card-2', kind: 'peach', targetIds: [] },
        ],
      },
    }, { userId: 'user-1', roomId: 'room-1' });

    expect(game).toMatchObject({ roomId: 'room-1', round: 2, canAct: true, selfPlayerId: 'user-1' });
    expect(game.hand[0]).toMatchObject({ id: 'card-1', name: '杀', playable: true, allowedTargetIds: ['user-2'] });
    expect(game.hand[1]).toMatchObject({ id: 'card-2', name: '桃', playable: true, targetMode: 'self' });
    expect(game.players[0]).toMatchObject({ isSelf: true, identity: '主公' });
    expect(game.players[0]?.equipment).toEqual([{ slot: '进攻坐骑', name: '赤兔' }]);
    expect(game.logs[0]?.text).toBe('玩家 1 的回合开始');
  });

  it('normalizes a dodge response prompt', () => {
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 4, maxHp: 4, handCount: 0, hand: null, role: 'lord' },
        { id: 'user-2', seat: 1, alive: true, hp: 3, maxHp: 4, handCount: 1, hand: [{ id: 'dodge-1', kind: 'dodge' }], role: 'rebel' },
      ],
      currentPlayerId: 'user-1',
      turn: { number: 1, playerId: 'user-1', phase: 'respond', slashUsed: true, requiredDiscardCount: 0 },
      pendingResponse: { type: 'slash', attackerId: 'user-1', targetId: 'user-2', cardId: 'slash-1' },
      winner: null,
      logs: [],
      prompt: { type: 'respond', playerId: 'user-2', attackerId: 'user-1', dodgeCardIds: ['dodge-1'], canPass: true },
    }, { userId: 'user-2' });

    expect(game.prompt).toMatchObject({ kind: 'respond-dodge', allowedCardIds: ['dodge-1'], optional: true });
    expect(game.hand[0]).toMatchObject({ name: '闪', playable: true });
  });

  it('maps standard card metadata, suit, rank, category and target mode', () => {
    const cards = [
      { id: 'fire-1', kind: 'fire_slash', name: '火杀', suit: 'heart', rank: 4, category: 'basic' },
      { id: 'thunder-1', kind: 'thunder_slash', name: '雷杀', suit: 'spade', rank: 12, category: 'basic' },
      { id: 'wine-1', kind: 'wine', name: '酒', suit: 'diamond', rank: 9, category: 'basic' },
      { id: 'ex-1', kind: 'ex_nihilo', name: '无中生有', suit: 'heart', rank: 7, category: 'trick' },
      { id: 'duel-1', kind: 'duel', name: '决斗', suit: 'spade', rank: 1, category: 'trick' },
      { id: 'nanman-1', kind: 'barbarian_invasion', name: '南蛮入侵', suit: 'club', rank: 7, category: 'trick' },
      { id: 'wanjian-1', kind: 'arrow_barrage', name: '万箭齐发', suit: 'heart', rank: 1, category: 'trick' },
      { id: 'taoyuan-1', kind: 'peach_garden', name: '桃园结义', suit: 'heart', rank: 1, category: 'trick' },
    ];
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 3, maxHp: 4, handCount: cards.length, hand: cards, role: 'lord' },
        { id: 'user-2', seat: 1, alive: true, hp: 4, maxHp: 4, handCount: 0, hand: null, role: null },
      ],
      currentPlayerId: 'user-1',
      turn: { number: 3, playerId: 'user-1', phase: 'play', slashUsed: false, requiredDiscardCount: 0 },
      pendingResponse: null,
      winner: null,
      logs: [],
      prompt: {
        type: 'play',
        playerId: 'user-1',
        cards: [
          { cardId: 'fire-1', kind: 'fire_slash', targetIds: ['user-2'], targetMode: 'single-other' },
          { cardId: 'duel-1', kind: 'duel', targetIds: ['user-2'], targetMode: 'single-other' },
          { cardId: 'ex-1', kind: 'ex_nihilo', targetIds: [], targetMode: 'none' },
          { cardId: 'nanman-1', kind: 'barbarian_invasion', targetIds: [], targetMode: 'none' },
        ],
      },
    }, { userId: 'user-1', roomId: 'room-1' });

    expect(game.hand.map((card) => [card.name, card.suit, card.rank, card.category])).toEqual([
      ['火杀', 'heart', '4', 'basic'],
      ['雷杀', 'spade', 'Q', 'basic'],
      ['酒', 'diamond', '9', 'basic'],
      ['无中生有', 'heart', '7', 'trick'],
      ['决斗', 'spade', 'A', 'trick'],
      ['南蛮入侵', 'club', '7', 'trick'],
      ['万箭齐发', 'heart', 'A', 'trick'],
      ['桃园结义', 'heart', 'A', 'trick'],
    ]);
    expect(game.hand.find((card) => card.kind === 'fire_slash')).toMatchObject({
      playable: true,
      targetMode: 'single-other',
      allowedTargetIds: ['user-2'],
    });
    expect(game.hand.find((card) => card.kind === 'thunder_slash')).toMatchObject({ playable: false });
    expect(game.hand.find((card) => card.kind === 'nanman-1')).toBeUndefined();
    expect(game.hand.find((card) => card.kind === 'barbarian_invasion')?.description).toContain('打出一张「杀」');
  });

  it('normalizes a generic request to play slash and allows passing', () => {
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 4, maxHp: 4, handCount: 0, hand: null, role: 'lord' },
        { id: 'user-2', seat: 1, alive: true, hp: 3, maxHp: 4, handCount: 2, hand: [
          { id: 'slash-1', kind: 'slash', name: '杀', suit: 'spade', rank: 7, category: 'basic' },
          { id: 'dodge-1', kind: 'dodge', name: '闪', suit: 'heart', rank: 2, category: 'basic' },
        ], role: 'rebel' },
      ],
      currentPlayerId: 'user-1',
      turn: { number: 4, playerId: 'user-1', phase: 'respond', slashUsed: false, requiredDiscardCount: 0 },
      pendingResponse: { type: 'duel', sourceId: 'user-1', targetId: 'user-2', cardId: 'duel-1' },
      winner: null,
      logs: [],
      prompt: {
        type: 'respond',
        playerId: 'user-2',
        responseKind: 'slash',
        allowedCardIds: ['slash-1'],
        canPass: true,
        context: 'duel',
      },
    }, { userId: 'user-2' });

    expect(game.prompt).toMatchObject({
      kind: 'respond-slash',
      responseKind: 'slash',
      allowedCardIds: ['slash-1'],
      optional: true,
    });
    expect(game.prompt?.message).toContain('「决斗」');
    expect(game.hand.find((card) => card.id === 'slash-1')).toMatchObject({ playable: true });
    expect(game.hand.find((card) => card.id === 'dodge-1')).toMatchObject({ playable: false });
  });

  it('accepts the legacy slashCardIds response field', () => {
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 4, maxHp: 4, handCount: 0, hand: null, role: 'lord' },
        { id: 'user-2', seat: 1, alive: true, hp: 3, maxHp: 4, handCount: 1, hand: [
          { id: 'slash-1', kind: 'slash', name: '杀', suit: 'spade', rank: 7, category: 'basic' },
        ], role: 'rebel' },
      ],
      currentPlayerId: 'user-1',
      turn: { number: 4, playerId: 'user-1', phase: 'respond', slashUsed: false, requiredDiscardCount: 0 },
      pendingResponse: { type: 'duel', sourceId: 'user-1', targetId: 'user-2', cardId: 'duel-1' },
      winner: null,
      logs: [],
      prompt: {
        type: 'respond',
        playerId: 'user-2',
        responseKind: 'slash',
        slashCardIds: ['slash-1'],
        canPass: true,
        context: 'duel',
      },
    }, { userId: 'user-2' });

    expect(game.prompt).toMatchObject({
      kind: 'respond-slash',
      allowedCardIds: ['slash-1'],
    });
    expect(game.hand[0]).toMatchObject({ id: 'slash-1', playable: true });
  });

  it('normalizes a dying rescue prompt with Peach and self-rescue Wine', () => {
    const game = normalizeGameView({
      version: 1,
      status: 'playing',
      players: [
        { id: 'user-1', seat: 0, alive: true, hp: 0, maxHp: 4, handCount: 2, hand: [
          { id: 'peach-1', kind: 'peach', name: '桃', suit: 'heart', rank: 3, category: 'basic' },
          { id: 'wine-1', kind: 'wine', name: '酒', suit: 'spade', rank: 9, category: 'basic' },
        ], role: 'rebel' },
        { id: 'user-2', seat: 1, alive: true, hp: 4, maxHp: 5, handCount: 0, hand: null, role: 'lord' },
      ],
      currentPlayerId: 'user-2',
      turn: { number: 5, playerId: 'user-2', phase: 'respond', slashUsed: true, requiredDiscardCount: 0 },
      pendingResponse: { type: 'dying', victimId: 'user-1', damageSourceId: 'user-2', targetId: 'user-1' },
      winner: null,
      logs: [],
      prompt: {
        type: 'dying',
        playerId: 'user-1',
        victimId: 'user-1',
        allowedCardIds: ['peach-1', 'wine-1'],
        peachCardIds: ['peach-1'],
        wineCardIds: ['wine-1'],
        canPass: true,
      },
    }, { userId: 'user-1' });

    expect(game.prompt).toMatchObject({
      kind: 'respond-peach',
      allowedCardIds: ['peach-1', 'wine-1'],
      optional: true,
    });
    expect(game.prompt?.message).toContain('桃');
    expect(game.prompt?.message).toContain('酒');
    expect(game.hand).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: 'peach-1', playable: true }),
      expect.objectContaining({ id: 'wine-1', playable: true }),
    ]));
  });
});
