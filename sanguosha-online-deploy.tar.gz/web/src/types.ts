import {
  cardPresentation,
  formatCardRank,
  type CardCategory,
  type CardTargetMode,
  type StandardCardKind,
} from './gameCards';

export type UserRole = 'admin' | 'player';

export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  role: UserRole;
  disabled: boolean;
  createdAt?: string;
}

export type RoomStatus = 'waiting' | 'playing' | 'finished';

export interface RoomSummary {
  id: string;
  name: string;
  status: RoomStatus;
  hostId: string;
  hostName: string;
  playerCount: number;
  maxPlayers: number;
  createdAt?: string;
}

export interface RoomMember {
  userId: string;
  username: string;
  displayName: string;
  seat: number;
  ready: boolean;
  online: boolean;
  isHost: boolean;
  isBot?: boolean;
}

export interface RoomDetail extends RoomSummary {
  members: RoomMember[];
}

export type CardSuit = 'spade' | 'heart' | 'club' | 'diamond' | 'none';

export interface GameCard {
  id: string;
  name: string;
  kind?: StandardCardKind | string;
  suit: CardSuit;
  rank: string;
  description?: string;
  category?: CardCategory | string;
  targetMode?: CardTargetMode;
  playable?: boolean;
  allowedTargetIds?: string[];
}

export interface EquipmentView {
  slot: string;
  name: string;
}

export interface GamePlayerView {
  id: string;
  userId?: string;
  displayName: string;
  seat: number;
  general?: string;
  faction?: string;
  identity?: string;
  hp: number;
  maxHp: number;
  handCount: number;
  alive: boolean;
  online: boolean;
  isSelf: boolean;
  isCurrent: boolean;
  equipment?: EquipmentView[];
}

export interface GameLogEntry {
  id: string;
  at?: string;
  text: string;
  tone?: 'normal' | 'important' | 'damage' | 'heal';
}

export type PromptKind =
  | 'respond-slash'
  | 'respond-dodge'
  | 'respond-peach'
  | 'discard'
  | 'choose-card'
  | 'choose-target'
  | 'confirm'
  | string;

export interface ActionPrompt {
  id: string;
  kind: PromptKind;
  message: string;
  min?: number;
  max?: number;
  optional?: boolean;
  responseKind?: 'slash' | 'dodge';
  allowedCardIds?: string[];
  allowedTargetIds?: string[];
}

export interface GameView {
  roomId: string;
  status: 'playing' | 'finished';
  round: number;
  phase: string;
  turnPlayerId?: string;
  selfPlayerId: string;
  canAct: boolean;
  players: GamePlayerView[];
  hand: GameCard[];
  logs: GameLogEntry[];
  prompt?: ActionPrompt | null;
  availableActions?: string[];
  winner?: string;
}

export type GameAction =
  | { type: 'play_card'; playerId: string; cardId: string; targetId?: string }
  | { type: 'respond'; playerId: string; cardId?: string | null }
  | { type: 'discard'; playerId: string; cardIds: string[] }
  | { type: 'end_play'; playerId: string };

export interface ApiErrorBody {
  code?: string;
  message?: string;
}

export interface SocketAck<T = unknown> {
  ok: boolean;
  data?: T;
  error?: ApiErrorBody;
}

export interface ServerState {
  rooms?: RoomSummary[];
  room?: RoomDetail | null;
  game?: GameView | null;
}

type EngineCardKind = StandardCardKind;

interface EngineCard {
  id: string;
  kind: EngineCardKind;
  name?: string;
  suit?: Exclude<CardSuit, 'none'>;
  rank?: number | string;
  category?: CardCategory;
}

interface EnginePlayer {
  id: string;
  seat: number;
  alive: boolean;
  hp: number;
  maxHp: number;
  handCount: number;
  hand: EngineCard[] | null;
  equipment?: EngineCard[];
  role: 'lord' | 'loyalist' | 'rebel' | 'renegade' | null;
}

interface EnginePlayableCardHint {
  cardId: string;
  kind: EngineCardKind;
  targetIds: string[];
  targetMode?: CardTargetMode;
}

type EngineResponseContext = 'slash' | 'duel' | 'barbarian_invasion' | 'arrow_barrage';

type EnginePrompt =
  | { type: 'play'; playerId: string; cards: EnginePlayableCardHint[] }
  | {
      type: 'respond';
      playerId: string;
      attackerId?: string;
      targetId?: string;
      responseKind?: 'slash' | 'dodge';
      allowedCardIds?: string[];
      dodgeCardIds?: string[];
      slashCardIds?: string[];
      canPass: true;
      context?: EngineResponseContext;
    }
  | {
      type: 'dying';
      playerId: string;
      victimId: string;
      allowedCardIds: string[];
      peachCardIds: string[];
      wineCardIds: string[];
      canPass: true;
    }
  | { type: 'discard'; playerId: string; count: number; cardIds: string[] }
  | { type: 'waiting' }
  | { type: 'finished'; winner: { side: 'lord' | 'rebel' | 'renegade'; playerIds: string[] } };

interface EngineGameView {
  version: 1;
  status: 'playing' | 'finished';
  players: EnginePlayer[];
  currentPlayerId: string;
  turn: { number: number; playerId: string; phase: 'play' | 'respond' | 'discard' };
  winner: { side: 'lord' | 'rebel' | 'renegade'; playerIds: string[] } | null;
  logs: { id: number; type: 'system' | 'turn' | 'card' | 'damage' | 'death' | 'victory'; message: string }[];
  prompt: EnginePrompt;
}

const roleNames = { lord: '主公', loyalist: '忠臣', rebel: '反贼', renegade: '内奸' } as const;
const winnerNames = { lord: '主公与忠臣', rebel: '反贼', renegade: '内奸' } as const;

function isEngineGameView(value: unknown): value is EngineGameView {
  return Boolean(value && typeof value === 'object' && (value as { version?: unknown }).version === 1 && 'turn' in value);
}

function responsePromptMessage(prompt: Extract<EnginePrompt, { type: 'respond' }>): string {
  const responseName = prompt.responseKind === 'slash' ? '杀' : '闪';
  const sourceNames: Record<EngineResponseContext, string> = {
    slash: '杀',
    duel: '决斗',
    barbarian_invasion: '南蛮入侵',
    arrow_barrage: '万箭齐发',
  };
  const sourceName = prompt.context ? sourceNames[prompt.context] : undefined;
  if (sourceName) return `「${sourceName}」正在结算，请打出一张「${responseName}」或选择跳过。`;
  return `需要你打出一张「${responseName}」，也可以选择跳过。`;
}

export function normalizeGameView(
  payload: unknown,
  options: { roomId?: string; room?: RoomDetail | null; userId: string },
): GameView {
  const container = payload as { roomId?: string; view?: unknown; game?: unknown };
  const raw = container?.view ?? container?.game ?? payload;
  if (!isEngineGameView(raw)) return raw as GameView;

  const roomId = container?.roomId ?? options.roomId ?? options.room?.id ?? '';
  const prompt = raw.prompt;
  const selfId = prompt && 'playerId' in prompt && prompt.playerId === options.userId
    ? prompt.playerId
    : raw.players.some((player) => player.id === options.userId)
      ? options.userId
      : raw.players.find((player) => player.hand !== null)?.id ?? options.userId;
  const memberFor = (player: EnginePlayer) =>
    options.room?.members.find((member) => member.userId === player.id || member.seat === player.seat);
  const playableCards = prompt.type === 'play' ? new Map(prompt.cards.map((card) => [card.cardId, card])) : new Map();
  const responseCardIds = prompt.type === 'dying'
    ? prompt.allowedCardIds
    : prompt.type === 'respond'
      ? prompt.allowedCardIds
        ?? (prompt.responseKind === 'slash' ? prompt.slashCardIds : prompt.dodgeCardIds)
        ?? []
      : [];
  const selfRaw = raw.players.find((player) => player.id === selfId || player.hand !== null);
  const displayNameById = new Map(raw.players.map((player) => {
    const member = memberFor(player);
    return [player.id, member?.displayName ?? `玩家 ${player.seat + 1}`] as const;
  }));
  const readableLog = (message: string) => {
    let result = message;
    for (const [playerId, displayName] of displayNameById) {
      result = result.replaceAll(playerId, displayName);
    }
    return result;
  };

  const mapCard = (card: EngineCard): GameCard => {
    const hint = playableCards.get(card.id);
    const presentation = cardPresentation(card.kind);
    return {
      id: card.id,
      kind: card.kind,
      name: card.name ?? presentation?.name ?? card.kind,
      suit: card.suit ?? 'none',
      rank: formatCardRank(card.rank),
      category: card.category ?? presentation?.category ?? 'basic',
      description: presentation?.description,
      targetMode: hint?.targetMode ?? presentation?.targetMode,
      playable:
        prompt.type === 'play'
          ? playableCards.has(card.id)
          : prompt.type === 'respond' || prompt.type === 'dying'
            ? responseCardIds.includes(card.id)
            : prompt.type === 'discard'
              ? prompt.cardIds.includes(card.id)
              : false,
      allowedTargetIds: hint?.targetIds,
    };
  };

  let normalizedPrompt: ActionPrompt | null = null;
  if (prompt.type === 'respond' && prompt.playerId === selfId) {
    const responseKind = prompt.responseKind ?? 'dodge';
    const contextId = prompt.context ?? prompt.attackerId ?? 'card';
    normalizedPrompt = {
      id: `respond-${raw.turn.number}-${contextId}-${prompt.playerId}`,
      kind: responseKind === 'slash' ? 'respond-slash' : 'respond-dodge',
      message: responsePromptMessage(prompt),
      optional: true,
      min: 0,
      max: 1,
      responseKind,
      allowedCardIds: responseCardIds,
    };
  } else if (prompt.type === 'dying' && prompt.playerId === selfId) {
    const victimName = displayNameById.get(prompt.victimId) ?? '濒死角色';
    normalizedPrompt = {
      id: `dying-${raw.turn.number}-${prompt.victimId}-${prompt.playerId}`,
      kind: 'respond-peach',
      message: prompt.playerId === prompt.victimId
        ? '你正处于濒死状态，请使用「桃」或「酒」自救，也可以放弃。'
        : `${victimName} 正处于濒死状态，请使用一张「桃」救援，也可以放弃。`,
      optional: true,
      min: 0,
      max: 1,
      allowedCardIds: responseCardIds,
    };
  } else if (prompt.type === 'discard' && prompt.playerId === selfId) {
    normalizedPrompt = {
      id: `discard-${raw.turn.number}-${prompt.playerId}`,
      kind: 'discard',
      message: `请弃置 ${prompt.count} 张手牌。`,
      min: prompt.count,
      max: prompt.count,
      allowedCardIds: prompt.cardIds,
    };
  }

  return {
    roomId,
    status: raw.status,
    round: raw.turn.number,
    phase: raw.turn.phase,
    turnPlayerId: raw.currentPlayerId,
    selfPlayerId: selfId,
    canAct: prompt.type === 'play' && prompt.playerId === selfId,
    players: raw.players.map((player) => {
      const member = memberFor(player);
      return {
        id: player.id,
        userId: player.id,
        displayName: member?.displayName ?? `玩家 ${player.seat + 1}`,
        seat: player.seat,
        identity: player.role ? roleNames[player.role] : undefined,
        hp: player.hp,
        maxHp: player.maxHp,
        handCount: player.handCount,
        alive: player.alive,
        online: member?.online ?? true,
        isSelf: player.id === selfId,
        isCurrent: player.id === raw.currentPlayerId,
        equipment: (player.equipment ?? []).map((card) => ({
          slot: ['zhu_ge_lian_nu', 'gu_ding_dao'].includes(card.kind)
            ? '武器'
            : ['ren_wang_dun', 'teng_jia', 'bai_yin_shi_zi'].includes(card.kind)
              ? '防具'
              : ['chi_tu', 'da_wan', 'zi_xing'].includes(card.kind) ? '进攻坐骑' : '防御坐骑',
          name: card.name ?? cardPresentation(card.kind)?.name ?? card.kind,
        })),
      };
    }),
    hand: (selfRaw?.hand ?? []).map(mapCard),
    logs: raw.logs.map((log) => ({
      id: String(log.id),
      text: readableLog(log.message),
      tone: log.type === 'damage' || log.type === 'death' ? 'damage' : log.type === 'victory' ? 'important' : 'normal',
    })),
    prompt: normalizedPrompt,
    winner: raw.winner ? winnerNames[raw.winner.side] : undefined,
  };
}

export function normalizeRoomSummary(room: Partial<RoomSummary> & Record<string, unknown>): RoomSummary {
  const members = Array.isArray(room.members) ? room.members : [];
  const host = members.find((member) => Boolean((member as Record<string, unknown>).isHost)) as
    | Record<string, unknown>
    | undefined;
  return {
    id: String(room.id ?? ''),
    name: String(room.name ?? '未命名房间'),
    status: (room.status as RoomStatus | undefined) ?? 'waiting',
    hostId: String(room.hostId ?? room.ownerId ?? host?.userId ?? ''),
    hostName: String(room.hostName ?? room.ownerName ?? host?.displayName ?? ''),
    playerCount: Number(room.playerCount ?? members.length ?? 0),
    maxPlayers: Number(room.maxPlayers ?? 8),
    createdAt: typeof room.createdAt === 'string' ? room.createdAt : undefined,
  };
}

export function normalizeRoomDetail(room: Partial<RoomDetail> & Record<string, unknown>): RoomDetail {
  const summary = normalizeRoomSummary(room);
  const rawMembers = Array.isArray(room.members)
    ? room.members
    : Array.isArray(room.players)
      ? room.players
      : [];
  const members = rawMembers.map((raw, index) => {
    const member = raw as Record<string, unknown>;
    return {
      userId: String(member.userId ?? member.id ?? ''),
      username: String(member.username ?? ''),
      displayName: String(member.displayName ?? member.name ?? member.username ?? `玩家${index + 1}`),
      seat: Number(member.seat ?? index),
      ready: Boolean(member.ready),
      online: (member.online ?? member.connected) !== false,
      isHost: Boolean(member.isHost ?? String(member.userId ?? member.id ?? '') === summary.hostId),
      isBot: Boolean(member.isBot),
    };
  });
  return { ...summary, members, playerCount: members.length };
}
