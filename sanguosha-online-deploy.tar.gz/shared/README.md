# @sanguosha/shared

无 IO、可序列化的文字版三国杀规则核心。每个房间保存一份独立的
`GameSession`；浏览器只能接收 `getGameView` 生成的脱敏视图。

## 服务端接口

```ts
import {
  applyAction,
  createGame,
  forfeitPlayer,
  getGameView,
  type GameAction,
  type GameSession,
} from "@sanguosha/shared";

let session: GameSession = createGame({
  playerIds: ["user-1", "user-2"],
  seed: "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f",
});

const action: GameAction = {
  type: "end_play",
  playerId: session.currentPlayerId,
};
session = applyAction(session, action);

// A member leaving a running room forfeits and ends that game.
session = forfeitPlayer(session, "user-2");

const privateView = getGameView(session, "user-1");
const spectatorView = getGameView(session, null);
```

`applyAction` 不修改传入的会话，会返回一份新会话；非法操作抛出带有
`code` 的 `GameRuleError`。`GameSession` 包含所有手牌和身份，只能保存在
可信服务端。所有会话字段均可通过 JSON 序列化。

## 动作

```ts
type GameAction =
  | { type: "play_card"; playerId: string; cardId: string; targetId?: string }
  | { type: "respond"; playerId: string; cardId?: string | null }
  | { type: "end_play"; playerId: string }
  | { type: "discard"; playerId: string; cardIds: string[] };
```

- `play_card`：普通/火/雷杀和决斗必须给出一名其他存活玩家；桃与酒可省略
  `targetId` 或传自己；无中生有同样自动以自己为目标；南蛮入侵、
  万箭齐发和桃园结义不传目标。
- `respond`：按 Prompt 的 `responseKind` 给出杀族或闪的牌 ID；使用
  `null`/省略牌 ID 表示放弃响应并承受效果。
- `end_play`：结束出牌；手牌超过当前体力时进入弃牌阶段。
- `discard`：必须一次提交视图提示的准确弃牌数量。

前端应以 `GameView.prompt` 为准展示当前合法操作。Prompt 分为
`play`、`respond`、`discard`、`waiting` 和 `finished`。出牌提示中的
`targetMode` 为 `none`、`self` 或 `single-other`；响应提示通过
`context`、`responseKind` 和 `allowedCardIds` 完整描述当前合法响应。

## 当前规则批次

- 支持 2–10 人身份分配，每局随机一名主公并从主公开始。
- 每人四张起始手牌；主公五点体力，其他身份四点体力；回合开始摸两张。
- 标准牌含花色、点数、类别和中文名称。当前 111 张牌按原 Java
  `CardsHeap` 的本批次花色点数生成：普通/火/雷杀、闪、桃、酒、
  无中生有、决斗、南蛮入侵、万箭齐发和桃园结义。
- 每个出牌阶段限一张杀；三种杀均由闪响应。酒每阶段限一张，使本回合
  下一张杀伤害 +1；未使用的酒加值随回合结束清零。
- 无中生有摸两张；决斗双方轮流出杀直到一方放弃；南蛮入侵与万箭齐发
  从使用者下家开始按座次逐人请求杀或闪；桃园结义令所有受伤存活玩家
  各回复一点体力。
- 手牌上限等于当前体力，牌堆用尽后会洗入弃牌堆。
- 杀按存活座次环计算默认距离 1；阵亡角色不再占据距离。
- 体力降到 0 以下后按座次逐人请求桃，濒死者本人可以使用桃或酒；救援结束后恢复原卡牌结算。
- 实现阵亡、击杀反贼摸三张、主公误杀忠臣弃全部手牌及身份胜负。
- 当前仍不含武将技能、装备距离修正、无懈可击及判定区流程。

生产服务端必须为每个新房间传入 32 字节安全随机数的十六进制 `seed`。
引擎使用纯 TypeScript ChaCha20 流洗身份、初始牌堆及重洗的弃牌堆；密钥与
计数器只存在服务端 `GameSession` 中，不会进入 `GameView`。
