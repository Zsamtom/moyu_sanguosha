export type PlayerId = string;
export type CardId = string;

export type Role = "lord" | "loyalist" | "rebel" | "renegade";

export type CardSuit = "spade" | "heart" | "club" | "diamond";
export type CardRank = 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12 | 13;
export type CardCategory = "basic" | "trick" | "equipment";
export type EquipmentSlot = "weapon" | "armor" | "offensive_horse" | "defensive_horse";
export type SlashCardKind = "slash" | "fire_slash" | "thunder_slash";
export type CardKind =
  | SlashCardKind
  | "dodge"
  | "peach"
  | "wine"
  | "ex_nihilo"
  | "duel"
  | "barbarian_invasion"
  | "arrow_barrage"
  | "peach_garden"
  | "chi_tu" | "da_wan" | "zi_xing"
  | "di_lu" | "hua_liu" | "jue_ying" | "zhua_huang_fei_dian"
  | "zhu_ge_lian_nu" | "gu_ding_dao"
  | "ren_wang_dun" | "teng_jia" | "bai_yin_shi_zi";
export type CardName =
  | "杀"
  | "火杀"
  | "雷杀"
  | "闪"
  | "桃"
  | "酒"
  | "无中生有"
  | "决斗"
  | "南蛮入侵"
  | "万箭齐发"
  | "桃园结义"
  | "赤兔" | "大宛" | "紫骍" | "的卢" | "骅骝" | "绝影" | "爪黄飞电"
  | "诸葛连弩" | "古锭刀" | "仁王盾" | "藤甲" | "白银狮子";

export type DamageNature = "normal" | "fire" | "thunder";
export type GameStatus = "playing" | "finished";
export type TurnPhase = "play" | "respond" | "discard";

export interface Card {
  readonly id: CardId;
  readonly kind: CardKind;
  readonly name: CardName;
  readonly category: CardCategory;
  readonly suit: CardSuit;
  readonly rank: CardRank;
}

export interface GamePlayer {
  readonly id: PlayerId;
  readonly seat: number;
  role: Role;
  hp: number;
  maxHp: number;
  alive: boolean;
  hand: Card[];
  equipment: Partial<Record<EquipmentSlot, Card>>;
}

export interface TurnState {
  number: number;
  playerId: PlayerId;
  phase: TurnPhase;
  slashUsed: boolean;
  /** 酒在每个出牌阶段限用一次。 */
  wineUsed: boolean;
  /** 本回合下一张杀的伤害加值；使用杀时消耗，回合结束时清零。 */
  slashDamageBonus: number;
  requiredDiscardCount: number;
}

export interface PendingSlashResponse {
  readonly type: "slash";
  readonly attackerId: PlayerId;
  readonly targetId: PlayerId;
  readonly cardId: CardId;
  readonly slashKind: SlashCardKind;
  readonly damage: number;
  readonly nature: DamageNature;
}

export interface PendingDuelResponse {
  readonly type: "duel";
  /** The opponent whose last challenge/Slash the current target must answer. */
  readonly attackerId: PlayerId;
  /** The player who must now play a Slash or pass. */
  readonly targetId: PlayerId;
  readonly cardId: CardId;
  readonly initiatorId: PlayerId;
  readonly originalTargetId: PlayerId;
}

export interface PendingMassAttackResponse {
  readonly type: "mass_attack";
  readonly attackerId: PlayerId;
  /** The player currently resolving the mass attack. */
  readonly targetId: PlayerId;
  readonly cardId: CardId;
  readonly cardKind: "barbarian_invasion" | "arrow_barrage";
  readonly responseKind: "slash" | "dodge";
  /** Remaining living targets in circular seat order after targetId. */
  readonly remainingTargetIds: PlayerId[];
}

export type DyingResume =
  | { readonly type: "finish_effect" }
  | { readonly type: "mass_attack"; readonly pending: PendingMassAttackResponse };

export interface PendingDyingResponse {
  readonly type: "dying";
  readonly victimId: PlayerId;
  readonly damageSourceId: PlayerId;
  /** Player currently allowed to provide one rescue card. */
  readonly targetId: PlayerId;
  readonly remainingResponderIds: PlayerId[];
  readonly resume: DyingResume;
}

export type PendingResponse =
  | PendingSlashResponse
  | PendingDuelResponse
  | PendingMassAttackResponse
  | PendingDyingResponse;

export type WinnerSide = "lord" | "rebel" | "renegade";

export interface GameWinner {
  readonly side: WinnerSide;
  readonly playerIds: PlayerId[];
}

export type PublicLogType =
  | "system"
  | "turn"
  | "card"
  | "damage"
  | "death"
  | "victory";

export interface PublicLog {
  readonly id: number;
  readonly type: PublicLogType;
  readonly message: string;
}

/**
 * Complete authoritative state for exactly one room. It contains private data
 * and must never be sent to a browser directly. Every field is JSON-safe.
 */
export interface GameSession {
  readonly version: 1;
  status: GameStatus;
  players: GamePlayer[];
  deck: Card[];
  discardPile: Card[];
  /** Cards whose effects are still resolving; they cannot be reshuffled yet. */
  resolvingCards: Card[];
  currentPlayerId: PlayerId;
  turn: TurnState;
  pendingResponse: PendingResponse | null;
  winner: GameWinner | null;
  logs: PublicLog[];
  /** Secret server-only ChaCha20 stream state; never expose through GameView. */
  rng: {
    readonly key: string;
    readonly counter: number;
  };
  nextLogId: number;
}

export interface CreateGameInput {
  readonly playerIds: PlayerId[];
  /** A server-generated 256-bit seed encoded as exactly 64 hexadecimal characters. */
  readonly seed: string;
}

export type RoleDistribution = Readonly<Record<Role, number>>;

export type GameAction =
  | {
      readonly type: "play_card";
      readonly playerId: PlayerId;
      readonly cardId: CardId;
      /** Required for a Slash or Duel; omitted for cards without a chosen target. */
      readonly targetId?: PlayerId;
    }
  | {
      readonly type: "respond";
      readonly playerId: PlayerId;
      /** Omit/null to decline the requested Slash or Dodge. */
      readonly cardId?: CardId | null;
    }
  | {
      readonly type: "end_play";
      readonly playerId: PlayerId;
    }
  | {
      readonly type: "discard";
      readonly playerId: PlayerId;
      readonly cardIds: CardId[];
    };

export interface GameViewPlayer {
  readonly id: PlayerId;
  readonly seat: number;
  readonly alive: boolean;
  readonly hp: number;
  readonly maxHp: number;
  readonly handCount: number;
  /** Only populated for the player viewing their own game. */
  readonly hand: Card[] | null;
  readonly equipment: Card[];
  /** Self, the public lord, dead players, and all players after game over are visible. */
  readonly role: Role | null;
}

export type TargetMode = "none" | "self" | "single-other";
export type PlayableCardKind = Exclude<CardKind, "dodge">;

export interface PlayableCardHint {
  readonly cardId: CardId;
  readonly kind: PlayableCardKind;
  readonly targetMode: TargetMode;
  /** Legal explicit targets. Empty for cards with targetMode "none". */
  readonly targetIds: PlayerId[];
}

export type ResponseContext =
  | "slash"
  | "duel"
  | "barbarian_invasion"
  | "arrow_barrage";

export type GamePrompt =
  | {
      readonly type: "play";
      readonly playerId: PlayerId;
      readonly cards: PlayableCardHint[];
    }
  | {
      readonly type: "respond";
      readonly playerId: PlayerId;
      /** The damage source/opponent whose effect is being answered. */
      readonly attackerId: PlayerId;
      readonly targetId: PlayerId;
      readonly context: ResponseContext;
      readonly responseKind: "slash" | "dodge";
      readonly allowedCardIds: CardId[];
      /** Compatibility field for the original Slash -> Dodge UI. */
      readonly dodgeCardIds: CardId[];
      /** Slash-family cards accepted by Duel or 南蛮入侵. */
      readonly slashCardIds: CardId[];
      readonly canPass: true;
    }
  | {
      readonly type: "dying";
      readonly playerId: PlayerId;
      readonly victimId: PlayerId;
      readonly allowedCardIds: CardId[];
      readonly peachCardIds: CardId[];
      readonly wineCardIds: CardId[];
      readonly canPass: true;
    }
  | {
      readonly type: "discard";
      readonly playerId: PlayerId;
      readonly count: number;
      readonly cardIds: CardId[];
    }
  | { readonly type: "waiting" }
  | { readonly type: "finished"; readonly winner: GameWinner };

/** Browser-safe projection. Hidden hands and identities are replaced with null. */
export interface GameView {
  readonly version: 1;
  readonly status: GameStatus;
  readonly players: GameViewPlayer[];
  readonly deckCount: number;
  readonly discardPile: Card[];
  readonly currentPlayerId: PlayerId;
  readonly turn: TurnState;
  readonly pendingResponse: PendingResponse | null;
  readonly winner: GameWinner | null;
  readonly logs: PublicLog[];
  readonly prompt: GamePrompt;
}

export type GameRuleErrorCode =
  | "INVALID_PLAYER_COUNT"
  | "INVALID_PLAYER_ID"
  | "INVALID_SEED"
  | "DUPLICATE_PLAYER"
  | "GAME_FINISHED"
  | "UNKNOWN_PLAYER"
  | "PLAYER_DEAD"
  | "NOT_YOUR_TURN"
  | "INVALID_PHASE"
  | "CARD_NOT_FOUND"
  | "INVALID_CARD"
  | "INVALID_TARGET"
  | "SLASH_ALREADY_USED"
  | "WINE_ALREADY_USED"
  | "FULL_HEALTH"
  | "INVALID_RESPONSE"
  | "INVALID_DISCARD";
