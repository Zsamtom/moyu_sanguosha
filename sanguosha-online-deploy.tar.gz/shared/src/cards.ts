import type {
  Card,
  CardCategory,
  CardKind,
  CardName,
  CardRank,
  CardSuit,
  DamageNature,
  EquipmentSlot,
  SlashCardKind,
} from "./types.js";

export interface CardDefinition {
  readonly name: CardName;
  readonly category: CardCategory;
  readonly equipmentSlot?: EquipmentSlot;
  readonly weaponRange?: number;
}

export const CARD_DEFINITIONS = {
  slash: { name: "杀", category: "basic" },
  fire_slash: { name: "火杀", category: "basic" },
  thunder_slash: { name: "雷杀", category: "basic" },
  dodge: { name: "闪", category: "basic" },
  peach: { name: "桃", category: "basic" },
  wine: { name: "酒", category: "basic" },
  ex_nihilo: { name: "无中生有", category: "trick" },
  duel: { name: "决斗", category: "trick" },
  barbarian_invasion: { name: "南蛮入侵", category: "trick" },
  arrow_barrage: { name: "万箭齐发", category: "trick" },
  peach_garden: { name: "桃园结义", category: "trick" },
  chi_tu: { name: "赤兔", category: "equipment", equipmentSlot: "offensive_horse" },
  da_wan: { name: "大宛", category: "equipment", equipmentSlot: "offensive_horse" },
  zi_xing: { name: "紫骍", category: "equipment", equipmentSlot: "offensive_horse" },
  di_lu: { name: "的卢", category: "equipment", equipmentSlot: "defensive_horse" },
  hua_liu: { name: "骅骝", category: "equipment", equipmentSlot: "defensive_horse" },
  jue_ying: { name: "绝影", category: "equipment", equipmentSlot: "defensive_horse" },
  zhua_huang_fei_dian: { name: "爪黄飞电", category: "equipment", equipmentSlot: "defensive_horse" },
  zhu_ge_lian_nu: { name: "诸葛连弩", category: "equipment", equipmentSlot: "weapon", weaponRange: 1 },
  gu_ding_dao: { name: "古锭刀", category: "equipment", equipmentSlot: "weapon", weaponRange: 2 },
  ren_wang_dun: { name: "仁王盾", category: "equipment", equipmentSlot: "armor" },
  teng_jia: { name: "藤甲", category: "equipment", equipmentSlot: "armor" },
  bai_yin_shi_zi: { name: "白银狮子", category: "equipment", equipmentSlot: "armor" },
} as const satisfies Readonly<Record<CardKind, CardDefinition>>;

export const STANDARD_DECK_SIZE = 111;

export function getCardDefinition(kind: CardKind): CardDefinition {
  return CARD_DEFINITIONS[kind];
}

export function isSlashCardKind(kind: CardKind): kind is SlashCardKind {
  return kind === "slash" || kind === "fire_slash" || kind === "thunder_slash";
}

export function damageNatureForSlash(kind: SlashCardKind): DamageNature {
  if (kind === "fire_slash") return "fire";
  if (kind === "thunder_slash") return "thunder";
  return "normal";
}

/**
 * Builds the first supported standard-card deck. Its 97 cards preserve the
 * suits, ranks, duplicates, and relative counts from the original Java
 * CardsHeap for exactly the card kinds implemented by this engine.
 */
export function createStandardDeck(): Card[] {
  const cards: Card[] = [];
  const counts = new Map<CardKind, number>();
  const add = (kind: CardKind, suit: CardSuit, ...ranks: CardRank[]): void => {
    const definition = getCardDefinition(kind);
    for (const rank of ranks) {
      const serial = (counts.get(kind) ?? 0) + 1;
      counts.set(kind, serial);
      cards.push({
        id: `${kind}-${String(serial).padStart(2, "0")}`,
        kind,
        name: definition.name,
        category: definition.category,
        suit,
        rank,
      });
    }
  };

  // Basic cards.
  add("slash", "heart", 10, 10, 11);
  add("slash", "diamond", 6, 7, 8, 9, 10, 13);
  add("slash", "spade", 7, 8, 8, 9, 9, 10, 10);
  add("slash", "club", 2, 3, 4, 5, 6, 7, 8, 8, 9, 9, 10, 10, 11, 11);

  add("dodge", "diamond", 2, 2, 3, 4, 5, 6, 6, 7, 8, 8, 9, 10, 10, 11, 11, 11);
  add("dodge", "heart", 2, 2, 8, 9, 10, 11, 12, 13);

  add("peach", "heart", 3, 4, 5, 6, 7, 8, 9, 12);
  add("peach", "diamond", 2, 2, 3, 12);

  add("wine", "club", 3, 9);
  add("wine", "spade", 3, 9);
  add("wine", "diamond", 9);

  add("thunder_slash", "spade", 4, 5, 6, 7, 8);
  add("thunder_slash", "club", 5, 6, 7, 8);
  add("fire_slash", "diamond", 4, 5);
  add("fire_slash", "heart", 4, 7, 10);

  // Immediate trick cards in this first migration batch.
  add("ex_nihilo", "heart", 7, 8, 9, 12);
  add("barbarian_invasion", "spade", 7, 13);
  add("barbarian_invasion", "club", 7);
  add("arrow_barrage", "heart", 1);
  add("duel", "spade", 1);
  add("duel", "diamond", 1);
  add("duel", "club", 1);
  add("peach_garden", "heart", 1);
  add("zhua_huang_fei_dian", "heart", 13);
  add("jue_ying", "spade", 5);
  add("di_lu", "club", 5);
  add("chi_tu", "heart", 5);
  add("zi_xing", "diamond", 13);
  add("da_wan", "spade", 13);
  add("hua_liu", "diamond", 13);
  add("zhu_ge_lian_nu", "diamond", 1);
  add("zhu_ge_lian_nu", "club", 1);
  add("gu_ding_dao", "spade", 1);
  add("ren_wang_dun", "club", 2);
  add("teng_jia", "club", 2);
  add("teng_jia", "spade", 2);
  add("bai_yin_shi_zi", "club", 1);

  if (cards.length !== STANDARD_DECK_SIZE) {
    throw new Error(`标准牌堆数量错误：预期 ${STANDARD_DECK_SIZE}，实际 ${cards.length}。`);
  }
  return cards;
}
