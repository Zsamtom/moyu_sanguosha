import {
  createStandardDeck,
  damageNatureForSlash,
  getCardDefinition,
  isSlashCardKind,
} from "./cards.js";
import type {
  Card,
  CardId,
  CardKind,
  CreateGameInput,
  DamageNature,
  GameAction,
  GamePlayer,
  GamePrompt,
  GameRuleErrorCode,
  GameSession,
  GameView,
  GameWinner,
  DyingResume,
  PendingDyingResponse,
  PendingMassAttackResponse,
  PendingResponse,
  PlayableCardHint,
  PlayerId,
  PublicLogType,
  ResponseContext,
  Role,
  RoleDistribution,
  TurnState,
} from "./types.js";
import {
  normalizeChaCha20Key,
  randomInteger,
  type ChaCha20State,
} from "./prng.js";

const MIN_PLAYERS = 2;
const MAX_PLAYERS = 10;
const INITIAL_HAND_SIZE = 4;
const TURN_DRAW_COUNT = 2;
const MAX_PUBLIC_LOGS = 500;

const ROLE_DISTRIBUTIONS: Readonly<Record<number, RoleDistribution>> = {
  2: { lord: 1, loyalist: 0, rebel: 1, renegade: 0 },
  3: { lord: 1, loyalist: 1, rebel: 1, renegade: 0 },
  4: { lord: 1, loyalist: 1, rebel: 2, renegade: 0 },
  5: { lord: 1, loyalist: 1, rebel: 2, renegade: 1 },
  6: { lord: 1, loyalist: 1, rebel: 3, renegade: 1 },
  7: { lord: 1, loyalist: 2, rebel: 3, renegade: 1 },
  8: { lord: 1, loyalist: 2, rebel: 4, renegade: 1 },
  9: { lord: 1, loyalist: 3, rebel: 4, renegade: 1 },
  10: { lord: 1, loyalist: 3, rebel: 5, renegade: 1 },
};

export class GameRuleError extends Error {
  readonly code: GameRuleErrorCode;

  constructor(code: GameRuleErrorCode, message: string) {
    super(message);
    this.name = "GameRuleError";
    this.code = code;
  }
}

function ruleError(code: GameRuleErrorCode, message: string): never {
  throw new GameRuleError(code, message);
}

export function getRoleDistribution(playerCount: number): RoleDistribution {
  const distribution = ROLE_DISTRIBUTIONS[playerCount];
  if (!distribution) {
    ruleError(
      "INVALID_PLAYER_COUNT",
      `玩家人数必须在 ${MIN_PLAYERS} 到 ${MAX_PLAYERS} 之间。`,
    );
  }
  return { ...distribution };
}

function rolesFor(playerCount: number): Role[] {
  const distribution = getRoleDistribution(playerCount);
  return [
    ...Array<Role>(distribution.lord).fill("lord"),
    ...Array<Role>(distribution.loyalist).fill("loyalist"),
    ...Array<Role>(distribution.rebel).fill("rebel"),
    ...Array<Role>(distribution.renegade).fill("renegade"),
  ];
}

function shuffle<T>(
  items: readonly T[],
  initialState: ChaCha20State,
): { items: T[]; state: ChaCha20State } {
  const shuffled = [...items];
  let state = initialState;
  for (let index = shuffled.length - 1; index > 0; index -= 1) {
    const generated = randomInteger(state, index + 1);
    state = generated.state;
    const swapIndex = generated.value;
    const current = shuffled[index];
    const replacement = shuffled[swapIndex];
    if (current === undefined || replacement === undefined) {
      throw new Error("洗牌索引越界。");
    }
    shuffled[index] = replacement;
    shuffled[swapIndex] = current;
  }
  return { items: shuffled, state };
}

function addLog(session: GameSession, type: PublicLogType, message: string): void {
  session.logs.push({ id: session.nextLogId, type, message });
  if (session.logs.length > MAX_PUBLIC_LOGS) {
    session.logs.splice(0, session.logs.length - MAX_PUBLIC_LOGS);
  }
  session.nextLogId += 1;
}

function refillDeck(session: GameSession): void {
  if (session.deck.length > 0 || session.discardPile.length === 0) return;
  const shuffled = shuffle(session.discardPile, session.rng);
  session.deck = shuffled.items;
  session.discardPile = [];
  session.rng = shuffled.state;
  addLog(session, "system", "弃牌堆已重新洗牌并成为新的牌堆。");
}

function drawCards(session: GameSession, player: GamePlayer, count: number): number {
  let drawn = 0;
  while (drawn < count) {
    refillDeck(session);
    const card = session.deck.pop();
    if (!card) break;
    player.hand.push(card);
    drawn += 1;
  }
  return drawn;
}

function getPlayer(session: GameSession, playerId: PlayerId): GamePlayer {
  const player = session.players.find((candidate) => candidate.id === playerId);
  if (!player) ruleError("UNKNOWN_PLAYER", `玩家 ${playerId} 不在本局游戏中。`);
  return player;
}

function getLivingPlayer(session: GameSession, playerId: PlayerId): GamePlayer {
  const player = getPlayer(session, playerId);
  if (!player.alive) ruleError("PLAYER_DEAD", `玩家 ${playerId} 已阵亡。`);
  return player;
}

/** Circular seat distance among living players. Dead seats do not block adjacency. */
export function distanceBetweenPlayers(
  session: GameSession,
  sourceId: PlayerId,
  targetId: PlayerId,
): number {
  if (sourceId === targetId) return 0;
  getLivingPlayer(session, sourceId);
  getLivingPlayer(session, targetId);
  const living = session.players
    .filter((player) => player.alive)
    .sort((left, right) => left.seat - right.seat);
  const sourceIndex = living.findIndex((player) => player.id === sourceId);
  const targetIndex = living.findIndex((player) => player.id === targetId);
  const clockwise = (targetIndex - sourceIndex + living.length) % living.length;
  const base = Math.min(clockwise, living.length - clockwise);
  const source = getLivingPlayer(session, sourceId);
  const target = getLivingPlayer(session, targetId);
  const offensive = source.equipment.offensive_horse ? 1 : 0;
  const defensive = target.equipment.defensive_horse ? 1 : 0;
  return Math.max(1, base - offensive + defensive);
}

export function attackRangeFor(_session: GameSession, _playerId: PlayerId): number {
  const player = getLivingPlayer(_session, _playerId);
  const weapon = player.equipment.weapon;
  return weapon ? getCardDefinition(weapon.kind).weaponRange ?? 1 : 1;
}

function isInSlashRange(session: GameSession, sourceId: PlayerId, targetId: PlayerId): boolean {
  return distanceBetweenPlayers(session, sourceId, targetId) <= attackRangeFor(session, sourceId);
}

function removeCard(player: GamePlayer, cardId: CardId): Card {
  const index = player.hand.findIndex((card) => card.id === cardId);
  if (index < 0) ruleError("CARD_NOT_FOUND", `手牌中不存在 ${cardId}。`);
  const [card] = player.hand.splice(index, 1);
  if (!card) throw new Error("移除手牌失败。");
  return card;
}

function assertPlayTurn(session: GameSession, playerId: PlayerId): void {
  if (session.turn.phase !== "play") {
    ruleError("INVALID_PHASE", "当前不是出牌阶段。");
  }
  if (session.currentPlayerId !== playerId) {
    ruleError("NOT_YOUR_TURN", "当前不是你的回合。");
  }
}

function playerIdsForSide(session: GameSession, side: GameWinner["side"]): PlayerId[] {
  if (side === "lord") {
    return session.players
      .filter((player) => player.role === "lord" || player.role === "loyalist")
      .map((player) => player.id);
  }
  return session.players
    .filter((player) => player.role === side)
    .map((player) => player.id);
}

function winnerFor(session: GameSession): GameWinner | null {
  const lord = session.players.find((player) => player.role === "lord");
  if (!lord) throw new Error("游戏状态中缺少主公。");
  const livingPlayers = session.players.filter((player) => player.alive);

  if (!lord.alive) {
    const survivor = livingPlayers.length === 1 ? livingPlayers[0] : undefined;
    if (survivor?.role === "renegade") {
      return {
        side: "renegade",
        playerIds: playerIdsForSide(session, "renegade"),
      };
    }
    return {
      side: "rebel",
      playerIds: playerIdsForSide(session, "rebel"),
    };
  }

  const threatsRemain = livingPlayers.some(
    (player) => player.role === "rebel" || player.role === "renegade",
  );
  if (!threatsRemain) {
    return {
      side: "lord",
      playerIds: playerIdsForSide(session, "lord"),
    };
  }
  return null;
}

function finishWithWinner(session: GameSession, winner: GameWinner): void {
  session.status = "finished";
  session.winner = winner;
  session.pendingResponse = null;
  const sideName: Record<GameWinner["side"], string> = {
    lord: "主公与忠臣",
    rebel: "反贼",
    renegade: "内奸",
  };
  addLog(session, "victory", `${sideName[winner.side]}获胜。`);
}

function finishIfWon(session: GameSession): boolean {
  const winner = winnerFor(session);
  if (!winner) return false;
  finishWithWinner(session, winner);
  return true;
}

function roleName(role: Role): string {
  const names: Record<Role, string> = {
    lord: "主公",
    loyalist: "忠臣",
    rebel: "反贼",
    renegade: "内奸",
  };
  return names[role];
}

function cardName(kind: CardKind): string {
  return getCardDefinition(kind).name;
}

function isBlackCard(card: Card): boolean {
  return card.suit === "spade" || card.suit === "club";
}

function isMassAttackImmune(player: GamePlayer, kind: "barbarian_invasion" | "arrow_barrage"): boolean {
  return player.equipment.armor?.kind === "teng_jia" && (kind === "barbarian_invasion" || kind === "arrow_barrage");
}

function killPlayer(session: GameSession, victim: GamePlayer, killer: GamePlayer): void {
  victim.hp = 0;
  victim.alive = false;
  if (victim.hand.length > 0) {
    session.discardPile.push(...victim.hand);
    victim.hand = [];
  }
  const equipment = Object.values(victim.equipment);
  if (equipment.length > 0) session.discardPile.push(...equipment);
  victim.equipment = {};
  addLog(session, "death", `${victim.id} 阵亡，身份是${roleName(victim.role)}。`);

  if (victim.role === "rebel" && killer.alive) {
    const drawn = drawCards(session, killer, 3);
    addLog(session, "card", `${killer.id} 击杀反贼，摸了 ${drawn} 张牌。`);
  } else if (killer.role === "lord" && victim.role === "loyalist") {
    const discarded = killer.hand.length;
    session.discardPile.push(...killer.hand);
    killer.hand = [];
    addLog(session, "card", `${killer.id} 误杀忠臣，弃置了全部 ${discarded} 张手牌。`);
  }
  if (!finishIfWon(session) && victim.id === session.currentPlayerId) {
    beginNextTurn(session);
  }
}

function natureName(nature: DamageNature): string {
  if (nature === "fire") return "火焰";
  if (nature === "thunder") return "雷电";
  return "";
}

function dealDamage(
  session: GameSession,
  target: GamePlayer,
  attacker: GamePlayer,
  amount: number,
  nature: DamageNature,
  reason: string,
  resume: DyingResume,
): boolean {
  let actualAmount = amount;
  if (nature === "fire" && target.equipment.armor?.kind === "teng_jia") actualAmount += 1;
  if (actualAmount > 1 && target.equipment.armor?.kind === "bai_yin_shi_zi") actualAmount = 1;
  target.hp -= actualAmount;
  const natureLabel = natureName(nature);
  addLog(
    session,
    "damage",
    `${target.id} ${reason}，受到 ${actualAmount} 点${natureLabel}伤害。`,
  );
  if (target.hp <= 0) {
    const responders = livingPlayersInSeatOrderFrom(session, target).map((player) => player.id);
    const [firstResponder, ...remainingResponderIds] = responders;
    if (!firstResponder) throw new Error("濒死结算没有可响应玩家。");
    session.turn.phase = "respond";
    session.pendingResponse = {
      type: "dying",
      victimId: target.id,
      damageSourceId: attacker.id,
      targetId: firstResponder,
      remainingResponderIds,
      resume,
    };
    addLog(session, "damage", `${target.id} 进入濒死状态，需要回复至至少 1 点体力。`);
    return true;
  }
  return false;
}

function nextLivingPlayer(session: GameSession, currentPlayerId: PlayerId): GamePlayer {
  const currentIndex = session.players.findIndex((player) => player.id === currentPlayerId);
  if (currentIndex < 0) throw new Error("当前玩家不在座位表中。");
  for (let offset = 1; offset <= session.players.length; offset += 1) {
    const candidate = session.players[(currentIndex + offset) % session.players.length];
    if (candidate?.alive) return candidate;
  }
  throw new Error("没有存活玩家可进入下一回合。");
}

/** Living opponents in circular seat order, beginning immediately after source. */
function livingOpponentsInSeatOrder(
  session: GameSession,
  sourceId: PlayerId,
): GamePlayer[] {
  const sourceIndex = session.players.findIndex((player) => player.id === sourceId);
  if (sourceIndex < 0) throw new Error("效果来源不在座位表中。");
  const ordered: GamePlayer[] = [];
  for (let offset = 1; offset < session.players.length; offset += 1) {
    const candidate = session.players[(sourceIndex + offset) % session.players.length];
    if (candidate?.alive) ordered.push(candidate);
  }
  return ordered;
}

/** Source first, followed by living players in circular seat order. */
function livingPlayersInSeatOrderFrom(
  session: GameSession,
  source: GamePlayer,
): GamePlayer[] {
  return [source, ...livingOpponentsInSeatOrder(session, source.id)];
}

function beginNextTurn(session: GameSession): void {
  const nextPlayer = nextLivingPlayer(session, session.currentPlayerId);
  session.currentPlayerId = nextPlayer.id;
  session.turn = {
    number: session.turn.number + 1,
    playerId: nextPlayer.id,
    phase: "play",
    slashUsed: false,
    wineUsed: false,
    slashDamageBonus: 0,
    requiredDiscardCount: 0,
  };
  addLog(session, "turn", `第 ${session.turn.number} 回合：${nextPlayer.id} 开始行动。`);
  const drawn = drawCards(session, nextPlayer, TURN_DRAW_COUNT);
  addLog(session, "card", `${nextPlayer.id} 摸了 ${drawn} 张牌。`);
}

function cloneCard(card: Card): Card {
  const definition = getCardDefinition(card.kind);
  return {
    id: card.id,
    kind: card.kind,
    // Fallbacks let a persisted v1 room created before card metadata was
    // introduced finish safely after a rolling deployment.
    name: card.name ?? definition.name,
    category: card.category ?? definition.category,
    suit: card.suit ?? "spade",
    rank: card.rank ?? 1,
  };
}

function cloneTurn(turn: TurnState): TurnState {
  return {
    ...turn,
    wineUsed: turn.wineUsed ?? false,
    slashDamageBonus: turn.slashDamageBonus ?? 0,
  };
}

function clonePendingResponse(pending: PendingResponse | null): PendingResponse | null {
  if (!pending) return null;
  if (pending.type === "mass_attack") {
    return { ...pending, remainingTargetIds: [...pending.remainingTargetIds] };
  }
  if (pending.type === "slash") {
    return {
      ...pending,
      slashKind: pending.slashKind ?? "slash",
      damage: pending.damage ?? 1,
      nature: pending.nature ?? "normal",
    };
  }
  if (pending.type === "dying") {
    return {
      ...pending,
      remainingResponderIds: [...pending.remainingResponderIds],
      resume: pending.resume.type === "mass_attack"
        ? {
            type: "mass_attack",
            pending: {
              ...pending.resume.pending,
              remainingTargetIds: [...pending.resume.pending.remainingTargetIds],
            },
          }
        : { type: "finish_effect" },
    };
  }
  return { ...pending };
}

function cloneSession(session: GameSession): GameSession {
  return {
    ...session,
    players: session.players.map((player) => ({
      ...player,
      hand: player.hand.map(cloneCard),
      equipment: Object.fromEntries(
        Object.entries(player.equipment ?? {}).map(([slot, card]) => [slot, cloneCard(card)]),
      ),
    })),
    deck: session.deck.map(cloneCard),
    discardPile: session.discardPile.map(cloneCard),
    resolvingCards: (session.resolvingCards ?? []).map(cloneCard),
    turn: cloneTurn(session.turn),
    pendingResponse: clonePendingResponse(session.pendingResponse),
    winner: session.winner
      ? { ...session.winner, playerIds: [...session.winner.playerIds] }
      : null,
    logs: session.logs.map((log) => ({ ...log })),
    rng: { ...session.rng },
  };
}

export function createGame(input: CreateGameInput): GameSession {
  const { playerIds } = input;
  if (playerIds.length < MIN_PLAYERS || playerIds.length > MAX_PLAYERS) {
    ruleError(
      "INVALID_PLAYER_COUNT",
      `玩家人数必须在 ${MIN_PLAYERS} 到 ${MAX_PLAYERS} 之间。`,
    );
  }
  for (const playerId of playerIds) {
    if (typeof playerId !== "string" || playerId.trim().length === 0) {
      ruleError("INVALID_PLAYER_ID", "玩家 ID 不能为空。");
    }
  }
  if (new Set(playerIds).size !== playerIds.length) {
    ruleError("DUPLICATE_PLAYER", "同一玩家不能重复加入游戏。");
  }

  let key: string;
  try {
    key = normalizeChaCha20Key(input.seed);
  } catch {
    ruleError("INVALID_SEED", "随机种子必须是 64 个十六进制字符（256 位）。");
  }
  let rng: ChaCha20State = { key, counter: 0 };
  const shuffledRoles = shuffle(rolesFor(playerIds.length), rng);
  rng = shuffledRoles.state;
  const players: GamePlayer[] = playerIds.map((id, seat) => {
    const role = shuffledRoles.items[seat];
    if (!role) throw new Error("身份分配数量不足。");
    const maxHp = role === "lord" ? 5 : 4;
    return { id, seat, role, hp: maxHp, maxHp, alive: true, hand: [], equipment: {} };
  });

  const shuffledDeck = shuffle(createStandardDeck(), rng);
  rng = shuffledDeck.state;
  const lord = players.find((player) => player.role === "lord");
  if (!lord) throw new Error("身份分配缺少主公。");

  const session: GameSession = {
    version: 1,
    status: "playing",
    players,
    deck: shuffledDeck.items,
    discardPile: [],
    resolvingCards: [],
    currentPlayerId: lord.id,
    turn: {
      number: 1,
      playerId: lord.id,
      phase: "play",
      slashUsed: false,
      wineUsed: false,
      slashDamageBonus: 0,
      requiredDiscardCount: 0,
    },
    pendingResponse: null,
    winner: null,
    logs: [],
    rng,
    nextLogId: 1,
  };

  addLog(session, "system", `游戏开始，共 ${players.length} 名玩家。`);
  addLog(session, "system", `${lord.id} 是主公。`);
  for (let round = 0; round < INITIAL_HAND_SIZE; round += 1) {
    for (const player of players) drawCards(session, player, 1);
  }
  addLog(session, "card", `所有玩家各摸了 ${INITIAL_HAND_SIZE} 张起始手牌。`);
  addLog(session, "turn", `第 1 回合：${lord.id} 开始行动。`);
  const drawn = drawCards(session, lord, TURN_DRAW_COUNT);
  addLog(session, "card", `${lord.id} 摸了 ${drawn} 张牌。`);
  return session;
}

function assertOptionalSelfTarget(
  player: GamePlayer,
  targetId: PlayerId | undefined,
  cardLabel: string,
): void {
  if (targetId !== undefined && targetId !== player.id) {
    ruleError("INVALID_TARGET", `${cardLabel}只能对自己使用。`);
  }
}

function assertNoTarget(targetId: PlayerId | undefined, cardLabel: string): void {
  if (targetId !== undefined) {
    ruleError("INVALID_TARGET", `${cardLabel}不需要指定目标。`);
  }
}

function moveCardToResolving(session: GameSession, player: GamePlayer, cardId: CardId): Card {
  const played = removeCard(player, cardId);
  session.resolvingCards.push(played);
  return played;
}

function finishResolvingCards(session: GameSession): void {
  if (session.resolvingCards.length === 0) return;
  session.discardPile.push(...session.resolvingCards);
  session.resolvingCards = [];
}

function playSlash(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  if (!isSlashCardKind(card.kind)) throw new Error("非杀牌进入杀结算。");
  const weapon = player.equipment.weapon;
  if (session.turn.slashUsed && weapon?.kind !== "zhu_ge_lian_nu") {
    ruleError("SLASH_ALREADY_USED", "每个出牌阶段只能使用一张杀。");
  }
  if (!targetId || targetId === player.id) {
    ruleError("INVALID_TARGET", `${card.name}必须指定一名其他存活玩家。`);
  }
  const target = getLivingPlayer(session, targetId);
  if (!isInSlashRange(session, player.id, target.id)) {
    ruleError("INVALID_TARGET", `${target.id} 不在${card.name}的攻击范围内。`);
  }
  const guDingBonus = weapon?.kind === "gu_ding_dao" && target.hand.length === 0 ? 1 : 0;
  const damage = 1 + session.turn.slashDamageBonus + guDingBonus;
  const played = moveCardToResolving(session, player, card.id);
  session.turn.slashUsed = true;
  session.turn.slashDamageBonus = 0;
  const armor = target.equipment.armor;
  const blockedByArmor =
    (armor?.kind === "ren_wang_dun" && isBlackCard(played)) ||
    (armor?.kind === "teng_jia" && played.kind === "slash");
  if (blockedByArmor) {
    addLog(session, "card", `${target.id} 的${armor.name}令${played.name}无效。`);
    finishResolvingCards(session);
    return;
  }
  session.turn.phase = "respond";
  session.pendingResponse = {
    type: "slash",
    attackerId: player.id,
    targetId: target.id,
    cardId: played.id,
    slashKind: card.kind,
    damage,
    nature: damageNatureForSlash(card.kind),
  };
  addLog(
    session,
    "card",
    `${player.id} 对 ${target.id} 使用了${card.name}${damage > 1 ? "（酒强化）" : ""}。`,
  );
}

function playPeach(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertOptionalSelfTarget(player, targetId, "桃");
  if (player.hp >= player.maxHp) {
    ruleError("FULL_HEALTH", "体力已满，不能使用桃。");
  }
  session.discardPile.push(removeCard(player, card.id));
  player.hp += 1;
  addLog(session, "card", `${player.id} 使用桃，回复了 1 点体力。`);
}

function playWine(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertOptionalSelfTarget(player, targetId, "酒");
  if (session.turn.wineUsed) {
    ruleError("WINE_ALREADY_USED", "每个出牌阶段只能使用一张酒。");
  }
  session.discardPile.push(removeCard(player, card.id));
  session.turn.wineUsed = true;
  session.turn.slashDamageBonus = 1;
  addLog(session, "card", `${player.id} 使用酒，本回合下一张杀伤害 +1。`);
}

function playExNihilo(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertOptionalSelfTarget(player, targetId, card.name);
  // Keep the resolving card out of the discard pile while drawing so an
  // empty deck cannot immediately recycle and draw the same 无中生有.
  const played = removeCard(player, card.id);
  const drawn = drawCards(session, player, 2);
  session.discardPile.push(played);
  addLog(session, "card", `${player.id} 使用无中生有，摸了 ${drawn} 张牌。`);
}

function playDuel(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  if (!targetId || targetId === player.id) {
    ruleError("INVALID_TARGET", "决斗必须指定一名其他存活玩家。");
  }
  const target = getLivingPlayer(session, targetId);
  moveCardToResolving(session, player, card.id);
  session.turn.phase = "respond";
  session.pendingResponse = {
    type: "duel",
    attackerId: player.id,
    targetId: target.id,
    cardId: card.id,
    initiatorId: player.id,
    originalTargetId: target.id,
  };
  addLog(session, "card", `${player.id} 对 ${target.id} 使用了决斗。`);
}

function playMassAttack(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertNoTarget(targetId, card.name);
  if (card.kind !== "barbarian_invasion" && card.kind !== "arrow_barrage") {
    throw new Error("非群体锦囊进入群体结算。");
  }
  const massKind = card.kind;
  const targets = livingOpponentsInSeatOrder(session, player.id)
    .filter((target) => !isMassAttackImmune(target, massKind));
  const [firstTarget, ...remainingTargets] = targets;
  if (!firstTarget) {
    session.discardPile.push(removeCard(player, card.id));
    addLog(session, "card", `${card.name}没有可结算目标。`);
    return;
  }
  moveCardToResolving(session, player, card.id);
  session.turn.phase = "respond";
  session.pendingResponse = {
    type: "mass_attack",
    attackerId: player.id,
    targetId: firstTarget.id,
    cardId: card.id,
    cardKind: massKind,
    responseKind: massKind === "barbarian_invasion" ? "slash" : "dodge",
    remainingTargetIds: remainingTargets.map((target) => target.id),
  };
  addLog(
    session,
    "card",
    `${player.id} 使用了${card.name}，从 ${firstTarget.id} 开始按座次结算。`,
  );
}

function playPeachGarden(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertNoTarget(targetId, card.name);
  session.discardPile.push(removeCard(player, card.id));
  addLog(session, "card", `${player.id} 使用了桃园结义。`);
  for (const target of livingPlayersInSeatOrderFrom(session, player)) {
    if (target.hp >= target.maxHp) continue;
    target.hp += 1;
    addLog(session, "card", `${target.id} 因桃园结义回复了 1 点体力。`);
  }
}

function playEquipment(
  session: GameSession,
  player: GamePlayer,
  card: Card,
  targetId: PlayerId | undefined,
): void {
  assertOptionalSelfTarget(player, targetId, card.name);
  const slot = getCardDefinition(card.kind).equipmentSlot;
  if (!slot) throw new Error(`${card.name} 缺少装备槽定义。`);
  const played = removeCard(player, card.id);
  const replaced = player.equipment[slot];
  if (replaced) {
    session.discardPile.push(replaced);
    if (replaced.kind === "bai_yin_shi_zi" && player.hp > 0 && player.hp < player.maxHp) {
      player.hp += 1;
      addLog(session, "card", `${player.id} 失去白银狮子，回复了 1 点体力。`);
    }
  }
  player.equipment[slot] = played;
  addLog(session, "card", `${player.id} 装备了${card.name}${replaced ? `，替换了${replaced.name}` : ""}。`);
}

function applyPlayCard(
  session: GameSession,
  action: Extract<GameAction, { type: "play_card" }>,
): void {
  assertPlayTurn(session, action.playerId);
  const player = getLivingPlayer(session, action.playerId);
  const card = player.hand.find((candidate) => candidate.id === action.cardId);
  if (!card) ruleError("CARD_NOT_FOUND", `手牌中不存在 ${action.cardId}。`);

  if (isSlashCardKind(card.kind)) {
    playSlash(session, player, card, action.targetId);
    return;
  }
  if (card.category === "equipment") {
    playEquipment(session, player, card, action.targetId);
    return;
  }
  switch (card.kind) {
    case "peach":
      playPeach(session, player, card, action.targetId);
      return;
    case "wine":
      playWine(session, player, card, action.targetId);
      return;
    case "ex_nihilo":
      playExNihilo(session, player, card, action.targetId);
      return;
    case "duel":
      playDuel(session, player, card, action.targetId);
      return;
    case "barbarian_invasion":
    case "arrow_barrage":
      playMassAttack(session, player, card, action.targetId);
      return;
    case "peach_garden":
      playPeachGarden(session, player, card, action.targetId);
      return;
    case "dodge":
      ruleError("INVALID_CARD", "闪不能在出牌阶段主动使用。");
  }
}

function finishResponse(session: GameSession): void {
  session.pendingResponse = null;
  if (session.status === "playing") session.turn.phase = "play";
}

function responseCard(
  session: GameSession,
  player: GamePlayer,
  cardId: CardId,
  required: "slash" | "dodge",
): Card {
  const card = player.hand.find((candidate) => candidate.id === cardId);
  if (!card) ruleError("CARD_NOT_FOUND", `手牌中不存在 ${cardId}。`);
  const valid = required === "slash" ? isSlashCardKind(card.kind) : card.kind === "dodge";
  if (!valid) {
    ruleError(
      "INVALID_RESPONSE",
      `当前响应只能使用${required === "slash" ? "杀" : "闪"}。`,
    );
  }
  return removeCard(player, card.id);
}

function applySlashResponse(
  session: GameSession,
  pending: Extract<PendingResponse, { type: "slash" }>,
  target: GamePlayer,
  cardId: CardId | null | undefined,
): void {
  if (cardId != null) {
    const played = responseCard(session, target, cardId, "dodge");
    session.resolvingCards.push(played);
    finishResponse(session);
    addLog(session, "card", `${target.id} 使用闪，抵消了${cardName(pending.slashKind)}。`);
    finishResolvingCards(session);
    return;
  }

  finishResponse(session);
  const attacker = getLivingPlayer(session, pending.attackerId);
  const enteredDying = dealDamage(
    session,
    target,
    attacker,
    pending.damage,
    pending.nature,
    `未出闪，被${cardName(pending.slashKind)}命中`,
    { type: "finish_effect" },
  );
  if (!enteredDying) finishResolvingCards(session);
}

function applyDuelResponse(
  session: GameSession,
  pending: Extract<PendingResponse, { type: "duel" }>,
  target: GamePlayer,
  cardId: CardId | null | undefined,
): void {
  if (cardId != null) {
    const played = responseCard(session, target, cardId, "slash");
    session.resolvingCards.push(played);
    const opponent = getLivingPlayer(session, pending.attackerId);
    session.pendingResponse = {
      ...pending,
      attackerId: target.id,
      targetId: opponent.id,
    };
    addLog(session, "card", `${target.id} 在决斗中打出${played.name}，轮到 ${opponent.id} 响应。`);
    return;
  }

  finishResponse(session);
  const opponent = getLivingPlayer(session, pending.attackerId);
  const enteredDying = dealDamage(
    session,
    target,
    opponent,
    1,
    "normal",
    "在决斗中未出杀",
    { type: "finish_effect" },
  );
  if (!enteredDying) finishResolvingCards(session);
}

function advanceMassAttack(
  session: GameSession,
  pending: PendingMassAttackResponse,
): void {
  for (const [index, playerId] of pending.remainingTargetIds.entries()) {
    const candidate = getPlayer(session, playerId);
    if (!candidate.alive || isMassAttackImmune(candidate, pending.cardKind)) continue;
    session.pendingResponse = {
      ...pending,
      targetId: candidate.id,
      remainingTargetIds: pending.remainingTargetIds.slice(index + 1),
    };
    addLog(session, "card", `${pending.cardKind === "barbarian_invasion" ? "南蛮入侵" : "万箭齐发"}轮到 ${candidate.id} 响应。`);
    return;
  }
  finishResponse(session);
  finishResolvingCards(session);
  addLog(
    session,
    "card",
    `${pending.cardKind === "barbarian_invasion" ? "南蛮入侵" : "万箭齐发"}结算完毕。`,
  );
}

function applyMassAttackResponse(
  session: GameSession,
  pending: PendingMassAttackResponse,
  target: GamePlayer,
  cardId: CardId | null | undefined,
): void {
  if (cardId != null) {
    const played = responseCard(session, target, cardId, pending.responseKind);
    session.resolvingCards.push(played);
    addLog(session, "card", `${target.id} 打出${played.name}，响应了${cardName(pending.cardKind)}。`);
  } else {
    const attacker = getLivingPlayer(session, pending.attackerId);
    const enteredDying = dealDamage(
      session,
      target,
      attacker,
      1,
      "normal",
      `未出${pending.responseKind === "slash" ? "杀" : "闪"}，受到${cardName(pending.cardKind)}影响`,
      { type: "mass_attack", pending: { ...pending, remainingTargetIds: [...pending.remainingTargetIds] } },
    );
    if (enteredDying) return;
  }

  if (session.status === "playing") advanceMassAttack(session, pending);
  else finishResolvingCards(session);
}

function rescueCardIds(player: GamePlayer, victimId: PlayerId): CardId[] {
  return player.hand
    .filter((card) => card.kind === "peach" || (player.id === victimId && card.kind === "wine"))
    .map((card) => card.id);
}

function resumeAfterDying(session: GameSession, resume: DyingResume): void {
  if (session.status === "finished") {
    finishResolvingCards(session);
    return;
  }
  if (resume.type === "mass_attack") {
    advanceMassAttack(session, resume.pending);
    return;
  }
  session.pendingResponse = null;
  session.turn.phase = "play";
  finishResolvingCards(session);
}

function failDyingRescue(session: GameSession, pending: PendingDyingResponse): void {
  session.pendingResponse = null;
  const victim = getPlayer(session, pending.victimId);
  const source = getPlayer(session, pending.damageSourceId);
  killPlayer(session, victim, source);
  resumeAfterDying(session, pending.resume);
}

function advanceDyingResponder(session: GameSession, pending: PendingDyingResponse): void {
  for (const [index, playerId] of pending.remainingResponderIds.entries()) {
    const candidate = getPlayer(session, playerId);
    if (!candidate.alive) continue;
    session.pendingResponse = {
      ...pending,
      targetId: candidate.id,
      remainingResponderIds: pending.remainingResponderIds.slice(index + 1),
    };
    return;
  }
  failDyingRescue(session, pending);
}

function applyDyingResponse(
  session: GameSession,
  pending: PendingDyingResponse,
  responder: GamePlayer,
  cardId: CardId | null | undefined,
): void {
  const victim = getPlayer(session, pending.victimId);
  if (cardId == null) {
    advanceDyingResponder(session, pending);
    return;
  }
  const card = responder.hand.find((candidate) => candidate.id === cardId);
  if (!card) ruleError("CARD_NOT_FOUND", `手牌中不存在 ${cardId}。`);
  const allowed = card.kind === "peach" || (responder.id === victim.id && card.kind === "wine");
  if (!allowed) ruleError("INVALID_RESPONSE", "濒死救援只能使用桃；濒死者本人也可以使用酒。 ");
  session.resolvingCards.push(removeCard(responder, card.id));
  victim.hp += 1;
  addLog(
    session,
    "card",
    `${responder.id} 对濒死的 ${victim.id} 使用${card.name}，其体力回复至 ${victim.hp}。`,
  );
  if (victim.hp > 0) {
    addLog(session, "card", `${victim.id} 脱离濒死状态。`);
    resumeAfterDying(session, pending.resume);
    return;
  }
  if (rescueCardIds(responder, victim.id).length === 0) {
    advanceDyingResponder(session, pending);
  }
}

function applyResponse(
  session: GameSession,
  action: Extract<GameAction, { type: "respond" }>,
): void {
  if (session.turn.phase !== "respond" || !session.pendingResponse) {
    ruleError("INVALID_PHASE", "当前没有需要响应的卡牌效果。");
  }
  const pending = session.pendingResponse;
  if (action.playerId !== pending.targetId) {
    ruleError("INVALID_RESPONSE", "只有当前结算目标可以响应。");
  }
  const target = getLivingPlayer(session, action.playerId);

  if (pending.type === "dying") {
    applyDyingResponse(session, pending, target, action.cardId);
  } else if (pending.type === "slash") {
    applySlashResponse(session, pending, target, action.cardId);
  } else if (pending.type === "duel") {
    applyDuelResponse(session, pending, target, action.cardId);
  } else {
    applyMassAttackResponse(session, pending, target, action.cardId);
  }
}

function applyEndPlay(
  session: GameSession,
  action: Extract<GameAction, { type: "end_play" }>,
): void {
  assertPlayTurn(session, action.playerId);
  const player = getLivingPlayer(session, action.playerId);
  const excess = Math.max(0, player.hand.length - player.hp);
  if (excess > 0) {
    session.turn.phase = "discard";
    session.turn.requiredDiscardCount = excess;
    addLog(session, "turn", `${player.id} 进入弃牌阶段，需要弃置 ${excess} 张牌。`);
    return;
  }
  beginNextTurn(session);
}

function applyDiscard(
  session: GameSession,
  action: Extract<GameAction, { type: "discard" }>,
): void {
  if (session.turn.phase !== "discard") {
    ruleError("INVALID_PHASE", "当前不是弃牌阶段。");
  }
  if (session.currentPlayerId !== action.playerId) {
    ruleError("NOT_YOUR_TURN", "当前不是你的回合。");
  }
  const player = getLivingPlayer(session, action.playerId);
  const required = session.turn.requiredDiscardCount;
  if (action.cardIds.length !== required || new Set(action.cardIds).size !== action.cardIds.length) {
    ruleError("INVALID_DISCARD", `必须选择 ${required} 张不同的手牌弃置。`);
  }
  const handIds = new Set(player.hand.map((card) => card.id));
  if (action.cardIds.some((cardId) => !handIds.has(cardId))) {
    ruleError("INVALID_DISCARD", "只能弃置自己持有的手牌。");
  }
  const discarded = action.cardIds.map((cardId) => removeCard(player, cardId));
  session.discardPile.push(...discarded);
  addLog(
    session,
    "card",
    `${player.id} 弃置了 ${discarded.length} 张牌：${discarded
      .map((card) => card.name)
      .join("、")}。`,
  );
  beginNextTurn(session);
}

export function applyAction(session: GameSession, action: GameAction): GameSession {
  if (session.status === "finished") {
    ruleError("GAME_FINISHED", "游戏已经结束。");
  }
  // Validate the actor before cloning so malformed actions fail consistently.
  getLivingPlayer(session, action.playerId);
  const next = cloneSession(session);
  switch (action.type) {
    case "play_card":
      applyPlayCard(next, action);
      break;
    case "respond":
      applyResponse(next, action);
      break;
    case "end_play":
      applyEndPlay(next, action);
      break;
    case "discard":
      applyDiscard(next, action);
      break;
  }
  return next;
}

function forfeitureWinner(session: GameSession, forfeiter: GamePlayer): GameWinner {
  const living = (role: Role): boolean =>
    session.players.some((player) => player.alive && player.role === role);

  // A forfeiture aborts the match. If ordinary identity rules do not yet
  // produce a result, award the opposing surviving camp so leaving cannot
  // keep a room stuck in the playing state.
  let side: GameWinner["side"];
  if (forfeiter.role === "lord" || forfeiter.role === "loyalist") {
    side = living("rebel") ? "rebel" : living("renegade") ? "renegade" : "lord";
  } else if (forfeiter.role === "rebel") {
    side = living("lord") ? "lord" : living("renegade") ? "renegade" : "rebel";
  } else {
    side = living("lord") ? "lord" : "rebel";
  }
  return { side, playerIds: playerIdsForSide(session, side) };
}

/**
 * Ends a running game when a room member leaves. The player is marked dead,
 * their private hand is discarded, and normal identity victory is evaluated
 * first. If the match would otherwise continue, it is settled as a forfeiture.
 */
export function forfeitPlayer(session: GameSession, playerId: PlayerId): GameSession {
  if (session.status === "finished") {
    ruleError("GAME_FINISHED", "游戏已经结束。");
  }
  getLivingPlayer(session, playerId);
  const next = cloneSession(session);
  const forfeiter = getLivingPlayer(next, playerId);
  if (forfeiter.hand.length > 0) {
    next.discardPile.push(...forfeiter.hand);
    forfeiter.hand = [];
  }
  const forfeitedEquipment = Object.values(forfeiter.equipment);
  if (forfeitedEquipment.length > 0) next.discardPile.push(...forfeitedEquipment);
  forfeiter.equipment = {};
  forfeiter.alive = false;
  forfeiter.hp = 0;
  next.pendingResponse = null;
  finishResolvingCards(next);
  addLog(
    next,
    "death",
    `${forfeiter.id} 投降并离开游戏，身份是${roleName(forfeiter.role)}。`,
  );

  const ordinaryWinner = winnerFor(next);
  if (ordinaryWinner) {
    finishWithWinner(next, ordinaryWinner);
  } else {
    addLog(next, "system", "因玩家投降，本局按弃局规则立即结算。");
    finishWithWinner(next, forfeitureWinner(next, forfeiter));
  }
  return next;
}

function playableCards(session: GameSession, viewer: GamePlayer): PlayableCardHint[] {
  const targets = session.players
    .filter((player) => player.alive && player.id !== viewer.id)
    .map((player) => player.id);
  const slashTargets = targets.filter((targetId) => isInSlashRange(session, viewer.id, targetId));
  const cards: PlayableCardHint[] = [];
  for (const card of viewer.hand) {
    if (isSlashCardKind(card.kind)) {
      if (!session.turn.slashUsed || viewer.equipment.weapon?.kind === "zhu_ge_lian_nu") {
        cards.push({
          cardId: card.id,
          kind: card.kind,
          targetMode: "single-other",
          targetIds: [...slashTargets],
        });
      }
      continue;
    }
    switch (card.kind) {
      case "chi_tu":
      case "da_wan":
      case "zi_xing":
      case "di_lu":
      case "hua_liu":
      case "jue_ying":
      case "zhua_huang_fei_dian":
      case "zhu_ge_lian_nu":
      case "gu_ding_dao":
      case "ren_wang_dun":
      case "teng_jia":
      case "bai_yin_shi_zi":
        cards.push({ cardId: card.id, kind: card.kind, targetMode: "self", targetIds: [viewer.id] });
        break;
      case "peach":
        if (viewer.hp < viewer.maxHp) {
          cards.push({
            cardId: card.id,
            kind: card.kind,
            targetMode: "self",
            targetIds: [viewer.id],
          });
        }
        break;
      case "wine":
        if (!session.turn.wineUsed) {
          cards.push({
            cardId: card.id,
            kind: card.kind,
            targetMode: "self",
            targetIds: [viewer.id],
          });
        }
        break;
      case "duel":
        cards.push({
          cardId: card.id,
          kind: card.kind,
          targetMode: "single-other",
          targetIds: [...targets],
        });
        break;
      case "ex_nihilo":
        cards.push({
          cardId: card.id,
          kind: card.kind,
          targetMode: "self",
          targetIds: [viewer.id],
        });
        break;
      case "barbarian_invasion":
      case "arrow_barrage":
      case "peach_garden":
        cards.push({
          cardId: card.id,
          kind: card.kind,
          targetMode: "none",
          targetIds: [],
        });
        break;
      case "dodge":
        break;
    }
  }
  return cards;
}

function responseContext(pending: Exclude<PendingResponse, { type: "dying" }>): ResponseContext {
  if (pending.type !== "mass_attack") return pending.type;
  return pending.cardKind;
}

function responseKind(pending: Exclude<PendingResponse, { type: "dying" }>): "slash" | "dodge" {
  if (pending.type === "slash") return "dodge";
  if (pending.type === "duel") return "slash";
  return pending.responseKind;
}

function promptFor(session: GameSession, viewerId: PlayerId | null): GamePrompt {
  if (session.status === "finished") {
    if (!session.winner) throw new Error("结束的游戏缺少胜者。");
    return {
      type: "finished",
      winner: { ...session.winner, playerIds: [...session.winner.playerIds] },
    };
  }
  if (viewerId === null) return { type: "waiting" };
  const viewer = session.players.find((player) => player.id === viewerId);
  if (!viewer?.alive) return { type: "waiting" };

  if (session.turn.phase === "play" && session.currentPlayerId === viewer.id) {
    return { type: "play", playerId: viewer.id, cards: playableCards(session, viewer) };
  }

  const pending = session.pendingResponse;
  if (session.turn.phase === "respond" && pending?.targetId === viewer.id) {
    if (pending.type === "dying") {
      const peachCardIds = viewer.hand.filter((card) => card.kind === "peach").map((card) => card.id);
      const wineCardIds = viewer.id === pending.victimId
        ? viewer.hand.filter((card) => card.kind === "wine").map((card) => card.id)
        : [];
      return {
        type: "dying",
        playerId: viewer.id,
        victimId: pending.victimId,
        allowedCardIds: [...peachCardIds, ...wineCardIds],
        peachCardIds,
        wineCardIds,
        canPass: true,
      };
    }
    const required = responseKind(pending);
    const dodgeCardIds =
      required === "dodge"
        ? viewer.hand.filter((card) => card.kind === "dodge").map((card) => card.id)
        : [];
    const slashCardIds =
      required === "slash"
        ? viewer.hand.filter((card) => isSlashCardKind(card.kind)).map((card) => card.id)
        : [];
    return {
      type: "respond",
      playerId: viewer.id,
      attackerId: pending.attackerId,
      targetId: pending.targetId,
      context: responseContext(pending),
      responseKind: required,
      allowedCardIds: required === "dodge" ? [...dodgeCardIds] : [...slashCardIds],
      dodgeCardIds,
      slashCardIds,
      canPass: true,
    };
  }

  if (session.turn.phase === "discard" && session.currentPlayerId === viewer.id) {
    return {
      type: "discard",
      playerId: viewer.id,
      count: session.turn.requiredDiscardCount,
      cardIds: viewer.hand.map((card) => card.id),
    };
  }
  return { type: "waiting" };
}

export function getGameView(session: GameSession, viewerId: PlayerId | null): GameView {
  return {
    version: 1,
    status: session.status,
    players: session.players.map((player) => ({
      id: player.id,
      seat: player.seat,
      alive: player.alive,
      hp: player.hp,
      maxHp: player.maxHp,
      handCount: player.hand.length,
      hand: player.id === viewerId ? player.hand.map(cloneCard) : null,
      equipment: Object.values(player.equipment).map(cloneCard),
      role:
        player.id === viewerId ||
        player.role === "lord" ||
        !player.alive ||
        session.status === "finished"
          ? player.role
          : null,
    })),
    deckCount: session.deck.length,
    discardPile: session.discardPile.map(cloneCard),
    currentPlayerId: session.currentPlayerId,
    turn: cloneTurn(session.turn),
    pendingResponse: clonePendingResponse(session.pendingResponse),
    winner: session.winner
      ? { ...session.winner, playerIds: [...session.winner.playerIds] }
      : null,
    logs: session.logs.map((log) => ({ ...log })),
    prompt: promptFor(session, viewerId),
  };
}

export const viewGame = getGameView;
