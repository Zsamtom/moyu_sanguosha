import { describe, expect, it } from "vitest";

import {
  GameRuleError,
  STANDARD_DECK_SIZE,
  applyAction,
  createGame,
  createStandardDeck,
  distanceBetweenPlayers,
  getCardDefinition,
  getGameView,
  type Card,
  type CardKind,
  type GamePlayer,
  type GameSession,
  type PendingMassAttackResponse,
  type TurnState,
} from "../src/index.js";

function seedFor(value: number): string {
  return value.toString(16).padStart(64, "0");
}

function card(id: string, kind: CardKind): Card {
  return {
    id,
    kind,
    ...getCardDefinition(kind),
    suit: "spade",
    rank: 1,
  };
}

function player(session: GameSession, playerId: string): GamePlayer {
  const found = session.players.find((candidate) => candidate.id === playerId);
  if (!found) throw new Error(`Missing test player ${playerId}`);
  return found;
}

function setTurn(session: GameSession, playerId: string): void {
  session.currentPlayerId = playerId;
  session.turn = {
    number: session.turn.number,
    playerId,
    phase: "play",
    slashUsed: false,
    wineUsed: false,
    slashDamageBonus: 0,
    requiredDiscardCount: 0,
  };
  session.pendingResponse = null;
}

function orderedOpponents(session: GameSession, sourceId: string): GamePlayer[] {
  const sourceIndex = session.players.findIndex((candidate) => candidate.id === sourceId);
  if (sourceIndex < 0) throw new Error("Missing source");
  const result: GamePlayer[] = [];
  for (let offset = 1; offset < session.players.length; offset += 1) {
    const candidate = session.players[(sourceIndex + offset) % session.players.length];
    if (candidate?.alive) result.push(candidate);
  }
  return result;
}

function expectRuleError(run: () => unknown, code: string): void {
  expect(run).toThrowError(expect.objectContaining({ code }));
}

function declineAllDyingRescues(session: GameSession): GameSession {
  let current = session;
  while (current.pendingResponse?.type === "dying") {
    current = applyAction(current, {
      type: "respond",
      playerId: current.pendingResponse.targetId,
      cardId: null,
    });
  }
  return current;
}

describe("standard deck metadata", () => {
  it("preserves the selected CardsHeap distribution with unique JSON-safe cards", () => {
    const deck = createStandardDeck();
    expect(deck).toHaveLength(STANDARD_DECK_SIZE);
    expect(new Set(deck.map((candidate) => candidate.id))).toHaveLength(STANDARD_DECK_SIZE);

    const counts = Object.fromEntries(
      [...new Set(deck.map((candidate) => candidate.kind))].map((kind) => [
        kind,
        deck.filter((candidate) => candidate.kind === kind).length,
      ]),
    );
    expect(counts).toEqual({
      slash: 30,
      dodge: 24,
      peach: 12,
      wine: 5,
      thunder_slash: 9,
      fire_slash: 5,
      ex_nihilo: 4,
      barbarian_invasion: 3,
      arrow_barrage: 1,
      duel: 3,
      peach_garden: 1,
      zhua_huang_fei_dian: 1,
      jue_ying: 1,
      di_lu: 1,
      chi_tu: 1,
      zi_xing: 1,
      da_wan: 1,
      hua_liu: 1,
      zhu_ge_lian_nu: 2,
      gu_ding_dao: 1,
      ren_wang_dun: 1,
      teng_jia: 2,
      bai_yin_shi_zi: 1,
    });
    expect(
      deck
        .filter((candidate) => candidate.kind === "barbarian_invasion")
        .map(({ suit, rank }) => ({ suit, rank })),
    ).toEqual([
      { suit: "spade", rank: 7 },
      { suit: "spade", rank: 13 },
      { suit: "club", rank: 7 },
    ]);
    expect(deck.every((candidate) => candidate.name.length > 0)).toBe(true);
    expect(deck.every((candidate) => candidate.rank >= 1 && candidate.rank <= 13)).toBe(true);
    expect(JSON.parse(JSON.stringify(deck))).toEqual(deck);
  });

  it("uses the complete supported deck independently in each seeded game", () => {
    const session = createGame({ playerIds: ["a", "b", "c", "d"], seed: seedFor(901) });
    const allCards = [
      ...session.deck,
      ...session.discardPile,
      ...session.players.flatMap((candidate) => candidate.hand),
    ];
    expect(allCards).toHaveLength(STANDARD_DECK_SIZE);
    expect(new Set(allCards.map((candidate) => candidate.id))).toHaveLength(
      STANDARD_DECK_SIZE,
    );
    expect(JSON.parse(JSON.stringify(session))).toEqual(session);
  });
});

describe("elemental Slash, Wine, and immediate cards", () => {
  it("uses Wine once, consumes its bonus on a Fire Slash, and deals two fire damage", () => {
    const initial = createGame({ playerIds: ["a", "b", "c"], seed: seedFor(902) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    actor.hand = [
      card("wine-1", "wine"),
      card("wine-2", "wine"),
      card("fire-1", "fire_slash"),
    ];
    target.hand = [];
    const startingHp = target.hp;

    const drank = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "wine-1",
    });
    expect(initial.turn).toMatchObject({ wineUsed: false, slashDamageBonus: 0 });
    expect(drank.turn).toMatchObject({ wineUsed: true, slashDamageBonus: 1 });
    expectRuleError(
      () =>
        applyAction(drank, {
          type: "play_card",
          playerId: actor.id,
          cardId: "wine-2",
        }),
      "WINE_ALREADY_USED",
    );

    const attacked = applyAction(drank, {
      type: "play_card",
      playerId: actor.id,
      cardId: "fire-1",
      targetId: target.id,
    });
    expect(attacked.pendingResponse).toMatchObject({
      type: "slash",
      slashKind: "fire_slash",
      nature: "fire",
      damage: 2,
    });
    expect(attacked.turn.slashDamageBonus).toBe(0);

    const damaged = applyAction(attacked, {
      type: "respond",
      playerId: target.id,
      cardId: null,
    });
    expect(player(damaged, target.id).hp).toBe(startingHp - 2);
    expect(damaged.logs.at(-1)?.message).toContain("2 点火焰伤害");
  });

  it("lets Dodge answer Thunder Slash and exposes its response contract", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(903) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    actor.hand = [card("thunder-1", "thunder_slash")];
    target.hand = [card("dodge-1", "dodge")];

    const attacked = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "thunder-1",
      targetId: target.id,
    });
    expect(getGameView(attacked, target.id).prompt).toMatchObject({
      type: "respond",
      targetId: target.id,
      context: "slash",
      responseKind: "dodge",
      allowedCardIds: ["dodge-1"],
      dodgeCardIds: ["dodge-1"],
      slashCardIds: [],
    });
    const dodged = applyAction(attacked, {
      type: "respond",
      playerId: target.id,
      cardId: "dodge-1",
    });
    expect(dodged.pendingResponse).toBeNull();
    expect(dodged.turn.phase).toBe("play");
  });

  it("draws two for Ex Nihilo without accepting a forged target", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(904) });
    const actor = player(initial, initial.currentPlayerId);
    const other = orderedOpponents(initial, actor.id)[0];
    if (!other) throw new Error("Missing target");
    actor.hand = [card("draw-two", "ex_nihilo")];
    initial.deck = [card("drawn-1", "peach"), card("drawn-2", "dodge")];
    initial.discardPile = [];

    expectRuleError(
      () =>
        applyAction(initial, {
          type: "play_card",
          playerId: actor.id,
          cardId: "draw-two",
          targetId: other.id,
        }),
      "INVALID_TARGET",
    );
    const resolved = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "draw-two",
    });
    expect(player(resolved, actor.id).hand.map((candidate) => candidate.id)).toEqual([
      "drawn-2",
      "drawn-1",
    ]);
    expect(resolved.discardPile.map((candidate) => candidate.id)).toEqual(["draw-two"]);
  });

  it("does not recycle the resolving Ex Nihilo into its own draw", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(9041) });
    const actor = player(initial, initial.currentPlayerId);
    actor.hand = [card("draw-two", "ex_nihilo")];
    initial.deck = [];
    initial.discardPile = [card("old-discard", "dodge")];

    const resolved = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "draw-two",
    });
    expect(player(resolved, actor.id).hand.map((candidate) => candidate.id)).toEqual([
      "old-discard",
    ]);
    expect(resolved.discardPile.map((candidate) => candidate.id)).toEqual(["draw-two"]);
  });

  it("heals every wounded living player once with Peach Garden in seat order", () => {
    const initial = createGame({
      playerIds: ["a", "b", "c", "d", "e"],
      seed: seedFor(905),
    });
    const actor = player(initial, initial.currentPlayerId);
    actor.hand = [card("garden", "peach_garden")];
    const living = initial.players.filter((candidate) => candidate.alive);
    living.forEach((candidate, index) => {
      candidate.hp = index === 0 ? candidate.maxHp : candidate.maxHp - 1;
    });
    const dead = initial.players.find((candidate) => candidate.id !== actor.id);
    if (!dead) throw new Error("Missing dead fixture");
    dead.alive = false;
    dead.hp = 0;

    const resolved = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "garden",
    });
    for (const before of initial.players) {
      const after = player(resolved, before.id);
      if (!before.alive) {
        expect(after.hp).toBe(0);
      } else {
        expect(after.hp).toBe(Math.min(before.maxHp, before.hp + 1));
      }
    }
    const healingLogs = resolved.logs.filter((entry) => entry.message.includes("因桃园结义回复"));
    expect(healingLogs.map((entry) => entry.message.split(" ")[0])).toEqual(
      [actor, ...orderedOpponents(initial, actor.id)]
        .filter((candidate) => candidate.alive && candidate.hp < candidate.maxHp)
        .map((candidate) => candidate.id),
    );
    expect(resolved.turn.phase).toBe("play");
  });
});

describe("chained responses", () => {
  it("alternates Slash responses during Duel until one side passes", () => {
    const initial = createGame({ playerIds: ["a", "b", "c"], seed: seedFor(906) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    actor.hand = [card("duel", "duel"), card("actor-fire", "fire_slash")];
    target.hand = [card("target-slash", "slash"), card("wrong-dodge", "dodge")];
    const targetHp = target.hp;

    const challenged = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "duel",
      targetId: target.id,
    });
    expect(challenged.pendingResponse).toMatchObject({
      type: "duel",
      attackerId: actor.id,
      targetId: target.id,
      initiatorId: actor.id,
      originalTargetId: target.id,
    });
    expect(getGameView(challenged, target.id).prompt).toMatchObject({
      type: "respond",
      context: "duel",
      responseKind: "slash",
      allowedCardIds: ["target-slash"],
    });
    expectRuleError(
      () =>
        applyAction(challenged, {
          type: "respond",
          playerId: target.id,
          cardId: "wrong-dodge",
        }),
      "INVALID_RESPONSE",
    );
    expect(player(challenged, target.id).hand).toHaveLength(2);

    const returned = applyAction(challenged, {
      type: "respond",
      playerId: target.id,
      cardId: "target-slash",
    });
    expect(returned.pendingResponse).toMatchObject({
      type: "duel",
      attackerId: target.id,
      targetId: actor.id,
    });
    const countered = applyAction(returned, {
      type: "respond",
      playerId: actor.id,
      cardId: "actor-fire",
    });
    expect(countered.pendingResponse).toMatchObject({
      type: "duel",
      attackerId: actor.id,
      targetId: target.id,
    });
    const resolved = applyAction(countered, {
      type: "respond",
      playerId: target.id,
      cardId: null,
    });
    expect(player(resolved, target.id).hp).toBe(targetHp - 1);
    expect(resolved.pendingResponse).toBeNull();
    expect(resolved.turn.phase).toBe("play");
    expect(resolved.discardPile.map((candidate) => candidate.kind)).toEqual([
      "duel",
      "slash",
      "fire_slash",
    ]);
  });

  it("resolves Barbarian Invasion one seat at a time with Slash-family cards", () => {
    const initial = createGame({
      playerIds: ["a", "b", "c", "d"],
      seed: seedFor(907),
    });
    const actor = player(initial, initial.currentPlayerId);
    const targets = orderedOpponents(initial, actor.id);
    const [first, second, third] = targets;
    if (!first || !second || !third) throw new Error("Missing targets");
    actor.hand = [card("barbarians", "barbarian_invasion")];
    first.hand = [card("first-fire", "fire_slash")];
    second.hand = [card("second-dodge", "dodge")];
    third.hand = [card("third-thunder", "thunder_slash")];
    const secondHp = second.hp;

    const started = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "barbarians",
    });
    expect(started.pendingResponse).toEqual({
      type: "mass_attack",
      attackerId: actor.id,
      targetId: first.id,
      cardId: "barbarians",
      cardKind: "barbarian_invasion",
      responseKind: "slash",
      remainingTargetIds: [second.id, third.id],
    });
    expectRuleError(
      () =>
        applyAction(started, {
          type: "respond",
          playerId: second.id,
          cardId: null,
        }),
      "INVALID_RESPONSE",
    );
    const firstDone = applyAction(started, {
      type: "respond",
      playerId: first.id,
      cardId: "first-fire",
    });
    expect(firstDone.pendingResponse).toMatchObject({
      targetId: second.id,
      remainingTargetIds: [third.id],
    });
    expectRuleError(
      () =>
        applyAction(firstDone, {
          type: "respond",
          playerId: second.id,
          cardId: "second-dodge",
        }),
      "INVALID_RESPONSE",
    );
    const secondDone = applyAction(firstDone, {
      type: "respond",
      playerId: second.id,
      cardId: null,
    });
    expect(player(secondDone, second.id).hp).toBe(secondHp - 1);
    expect(secondDone.pendingResponse).toMatchObject({
      targetId: third.id,
      remainingTargetIds: [],
    });
    const resolved = applyAction(secondDone, {
      type: "respond",
      playerId: third.id,
      cardId: "third-thunder",
    });
    expect(resolved.pendingResponse).toBeNull();
    expect(resolved.turn.phase).toBe("play");
  });

  it("resolves Arrow Barrage one seat at a time and requests Dodge", () => {
    const initial = createGame({ playerIds: ["a", "b", "c"], seed: seedFor(908) });
    const actor = player(initial, initial.currentPlayerId);
    const [first, second] = orderedOpponents(initial, actor.id);
    if (!first || !second) throw new Error("Missing targets");
    actor.hand = [card("arrows", "arrow_barrage")];
    first.hand = [card("first-dodge", "dodge")];
    second.hand = [card("wrong-slash", "slash")];
    const secondHp = second.hp;

    const started = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "arrows",
    });
    expect(getGameView(started, first.id).prompt).toMatchObject({
      type: "respond",
      context: "arrow_barrage",
      responseKind: "dodge",
      allowedCardIds: ["first-dodge"],
    });
    const firstDone = applyAction(started, {
      type: "respond",
      playerId: first.id,
      cardId: "first-dodge",
    });
    expect(firstDone.pendingResponse).toMatchObject({ targetId: second.id });
    expectRuleError(
      () =>
        applyAction(firstDone, {
          type: "respond",
          playerId: second.id,
          cardId: "wrong-slash",
        }),
      "INVALID_RESPONSE",
    );
    const resolved = applyAction(firstDone, {
      type: "respond",
      playerId: second.id,
      cardId: null,
    });
    expect(player(resolved, second.id).hp).toBe(secondHp - 1);
    expect(resolved.pendingResponse).toBeNull();
  });

  it("continues a mass attack after a non-final target dies", () => {
    const initial = createGame({
      playerIds: ["a", "b", "c", "d", "e"],
      seed: seedFor(9082),
    });
    const victim = initial.players.find((candidate) => candidate.role !== "lord");
    if (!victim) throw new Error("Missing non-lord victim");
    const source = initial.players[(victim.seat - 1 + initial.players.length) % initial.players.length];
    if (!source) throw new Error("Missing source");
    setTurn(initial, source.id);
    source.hand = [card("barbarians", "barbarian_invasion")];
    victim.hand = [];
    victim.hp = 1;

    const started = applyAction(initial, {
      type: "play_card",
      playerId: source.id,
      cardId: "barbarians",
    });
    expect(started.pendingResponse).toMatchObject({ targetId: victim.id });
    const victimDying = applyAction(started, {
      type: "respond",
      playerId: victim.id,
      cardId: null,
    });
    const victimDone = declineAllDyingRescues(victimDying);
    expect(player(victimDone, victim.id)).toMatchObject({ alive: false, hp: 0 });
    expect(victimDone.status).toBe("playing");
    expect(victimDone.pendingResponse).toMatchObject({ type: "mass_attack" });
    expect(victimDone.pendingResponse?.targetId).not.toBe(victim.id);
  });

  it("advances the turn when the current player dies during their Duel", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d", "e"], seed: seedFor(9083) });
    const [lord, actor, opponent, remainingRebel, renegade] = initial.players;
    if (!lord || !actor || !opponent || !remainingRebel || !renegade) throw new Error("Missing players");
    lord.role = "lord";
    actor.role = "loyalist";
    opponent.role = "rebel";
    remainingRebel.role = "rebel";
    renegade.role = "renegade";
    initial.players.forEach((candidate) => { candidate.hand = []; });
    initial.deck = [];
    initial.discardPile = [];
    initial.resolvingCards = [];
    actor.hp = 1;
    actor.hand = [card("fatal-duel", "duel")];
    opponent.hand = [card("duel-answer", "slash")];
    setTurn(initial, actor.id);

    const challenged = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "fatal-duel",
      targetId: opponent.id,
    });
    const returned = applyAction(challenged, {
      type: "respond",
      playerId: opponent.id,
      cardId: "duel-answer",
    });
    const dying = applyAction(returned, {
      type: "respond",
      playerId: actor.id,
      cardId: null,
    });
    const resolved = declineAllDyingRescues(dying);

    expect(player(resolved, actor.id)).toMatchObject({ alive: false, hp: 0 });
    expect(resolved).toMatchObject({
      status: "playing",
      currentPlayerId: opponent.id,
      pendingResponse: null,
      turn: { playerId: opponent.id, phase: "play" },
    });
  });

  it("keeps a mass-attack card out of reshuffling until every target resolves", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d"], seed: seedFor(9084) });
    const actor = player(initial, initial.currentPlayerId);
    const [first, second, third] = orderedOpponents(initial, actor.id);
    if (!first || !second || !third) throw new Error("Missing targets");
    actor.role = "lord";
    first.role = "rebel";
    second.role = "rebel";
    third.role = "loyalist";
    initial.players.forEach((candidate) => { candidate.hand = []; });
    initial.deck = [];
    initial.discardPile = [];
    initial.resolvingCards = [];
    actor.hand = [card("active-barbarians", "barbarian_invasion")];
    first.hp = 1;

    const started = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "active-barbarians",
    });
    const firstDying = applyAction(started, {
      type: "respond",
      playerId: first.id,
      cardId: null,
    });
    const firstDone = declineAllDyingRescues(firstDying);

    expect(firstDone.status).toBe("playing");
    expect(player(firstDone, actor.id).hand.map((candidate) => candidate.id)).not.toContain("active-barbarians");
    expect(firstDone.discardPile.map((candidate) => candidate.id)).not.toContain("active-barbarians");
    expect(firstDone.resolvingCards.map((candidate) => candidate.id)).toContain("active-barbarians");

    const secondDone = applyAction(firstDone, {
      type: "respond",
      playerId: second.id,
      cardId: null,
    });
    const resolved = applyAction(secondDone, {
      type: "respond",
      playerId: third.id,
      cardId: null,
    });
    expect(resolved.pendingResponse).toBeNull();
    expect(resolved.resolvingCards).toEqual([]);
    expect(resolved.discardPile.map((candidate) => candidate.id)).toContain("active-barbarians");
  });
});

describe("living-seat distance", () => {
  it("allows Slash only against adjacent living seats and closes gaps left by dead players", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d", "e"], seed: seedFor(909) });
    const actor = player(initial, initial.currentPlayerId);
    const bySeat = [...initial.players].sort((left, right) => left.seat - right.seat);
    const clockwiseNeighbor = bySeat[(actor.seat + 1) % bySeat.length];
    const clockwiseFar = bySeat[(actor.seat + 2) % bySeat.length];
    const counterNeighbor = bySeat[(actor.seat - 1 + bySeat.length) % bySeat.length];
    if (!clockwiseNeighbor || !clockwiseFar || !counterNeighbor) throw new Error("Missing distance targets");
    actor.hand = [card("range-slash", "slash")];

    expect(distanceBetweenPlayers(initial, actor.id, clockwiseNeighbor.id)).toBe(1);
    expect(distanceBetweenPlayers(initial, actor.id, clockwiseFar.id)).toBe(2);
    const prompt = getGameView(initial, actor.id).prompt;
    expect(prompt).toMatchObject({ type: "play" });
    if (prompt.type !== "play") throw new Error("Missing play prompt");
    expect(prompt.cards[0]?.targetIds).toEqual(expect.arrayContaining([
      clockwiseNeighbor.id,
      counterNeighbor.id,
    ]));
    expect(prompt.cards[0]?.targetIds).not.toContain(clockwiseFar.id);
    expectRuleError(() => applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "range-slash",
      targetId: clockwiseFar.id,
    }), "INVALID_TARGET");

    clockwiseNeighbor.alive = false;
    clockwiseNeighbor.hp = 0;
    expect(distanceBetweenPlayers(initial, actor.id, clockwiseFar.id)).toBe(1);
    expect(() => applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "range-slash",
      targetId: clockwiseFar.id,
    })).not.toThrow();
  });
});

describe("horse equipment", () => {
  it("equips and replaces an offensive horse, reducing outgoing distance by one", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d", "e"], seed: seedFor(910) });
    const actor = player(initial, initial.currentPlayerId);
    const bySeat = [...initial.players].sort((left, right) => left.seat - right.seat);
    const far = bySeat[(actor.seat + 2) % bySeat.length];
    if (!far) throw new Error("Missing far target");
    actor.hand = [card("horse-one", "chi_tu"), card("horse-two", "da_wan"), card("horse-slash", "slash")];
    expect(distanceBetweenPlayers(initial, actor.id, far.id)).toBe(2);

    const equipped = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "horse-one" });
    expect(player(equipped, actor.id).equipment.offensive_horse?.id).toBe("horse-one");
    expect(distanceBetweenPlayers(equipped, actor.id, far.id)).toBe(1);
    const replaced = applyAction(equipped, { type: "play_card", playerId: actor.id, cardId: "horse-two" });
    expect(player(replaced, actor.id).equipment.offensive_horse?.id).toBe("horse-two");
    expect(replaced.discardPile.map((candidate) => candidate.id)).toContain("horse-one");
    expect(() => applyAction(replaced, {
      type: "play_card",
      playerId: actor.id,
      cardId: "horse-slash",
      targetId: far.id,
    })).not.toThrow();
  });

  it("makes an adjacent target out of range while they have a defensive horse", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d"], seed: seedFor(911) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    target.equipment.defensive_horse = card("defensive-horse", "jue_ying");
    actor.hand = [card("blocked-slash", "slash")];
    expect(distanceBetweenPlayers(initial, actor.id, target.id)).toBe(2);
    expectRuleError(() => applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "blocked-slash",
      targetId: target.id,
    }), "INVALID_TARGET");
  });
});

describe("first weapon batch", () => {
  it("lets Zhuge Crossbow use multiple Slashes in one play phase", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(912) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0]!;
    actor.hand = [card("crossbow", "zhu_ge_lian_nu"), card("replacement-blade", "gu_ding_dao"), card("slash-one", "slash"), card("slash-two", "fire_slash")];
    target.hand = [];
    const equipped = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "crossbow" });
    const first = applyAction(equipped, { type: "play_card", playerId: actor.id, cardId: "slash-one", targetId: target.id });
    const firstDone = applyAction(first, { type: "respond", playerId: target.id, cardId: null });
    expect(firstDone.turn.slashUsed).toBe(true);
    expect(() => applyAction(firstDone, { type: "play_card", playerId: actor.id, cardId: "slash-two", targetId: target.id })).not.toThrow();
    const replaced = applyAction(firstDone, { type: "play_card", playerId: actor.id, cardId: "replacement-blade" });
    expectRuleError(() => applyAction(replaced, {
      type: "play_card",
      playerId: actor.id,
      cardId: "slash-two",
      targetId: target.id,
    }), "SLASH_ALREADY_USED");
  });

  it("gives GuDing Blade range two and +1 damage against an empty hand", () => {
    const initial = createGame({ playerIds: ["a", "b", "c", "d", "e"], seed: seedFor(913) });
    const actor = player(initial, initial.currentPlayerId);
    const bySeat = [...initial.players].sort((left, right) => left.seat - right.seat);
    const target = bySeat[(actor.seat + 2) % bySeat.length]!;
    actor.hand = [card("blade", "gu_ding_dao"), card("blade-slash", "slash")];
    target.hand = [];
    const hp = target.hp;
    const equipped = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "blade" });
    expect(distanceBetweenPlayers(equipped, actor.id, target.id)).toBe(2);
    const attacked = applyAction(equipped, { type: "play_card", playerId: actor.id, cardId: "blade-slash", targetId: target.id });
    const damaged = applyAction(attacked, { type: "respond", playerId: target.id, cardId: null });
    expect(player(damaged, target.id).hp).toBe(hp - 2);
  });
});

describe("first armor batch", () => {
  it("makes black Slash ineffective against RenWang Shield", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(914) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0]!;
    actor.hand = [{ ...card("black-slash", "slash"), suit: "spade" }];
    target.equipment.armor = card("renwang", "ren_wang_dun");
    const hp = target.hp;
    const resolved = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "black-slash", targetId: target.id });
    expect(player(resolved, target.id).hp).toBe(hp);
    expect(resolved.pendingResponse).toBeNull();
    expect(resolved.discardPile.map((candidate) => candidate.id)).toContain("black-slash");
  });

  it("blocks normal Slash and mass attacks with Vine Armor but increases fire damage", () => {
    const initial = createGame({ playerIds: ["a", "b", "c"], seed: seedFor(915) });
    const actor = player(initial, initial.currentPlayerId);
    const [target, other] = orderedOpponents(initial, actor.id);
    if (!target || !other) throw new Error("Missing targets");
    target.equipment.armor = card("vine", "teng_jia");
    actor.hand = [card("normal", "slash"), card("fire", "fire_slash"), card("barbarians", "barbarian_invasion")];
    const blocked = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "normal", targetId: target.id });
    blocked.turn.slashUsed = false;
    const hp = player(blocked, target.id).hp;
    const fire = applyAction(blocked, { type: "play_card", playerId: actor.id, cardId: "fire", targetId: target.id });
    const burned = applyAction(fire, { type: "respond", playerId: target.id, cardId: null });
    expect(player(burned, target.id).hp).toBe(hp - 2);
    burned.turn.slashUsed = false;
    const mass = applyAction(burned, { type: "play_card", playerId: actor.id, cardId: "barbarians" });
    expect(mass.pendingResponse).toMatchObject({ type: "mass_attack", targetId: other.id });
  });

  it("caps damage with Silver Lion and heals when it is replaced", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(916) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0]!;
    target.equipment.armor = card("lion", "bai_yin_shi_zi");
    actor.hand = [card("wine", "wine"), card("boosted", "fire_slash")];
    target.hand = [];
    const hp = target.hp;
    const drank = applyAction(initial, { type: "play_card", playerId: actor.id, cardId: "wine" });
    const attacked = applyAction(drank, { type: "play_card", playerId: actor.id, cardId: "boosted", targetId: target.id });
    const damaged = applyAction(attacked, { type: "respond", playerId: target.id, cardId: null });
    expect(player(damaged, target.id).hp).toBe(hp - 1);

    const wounded = player(damaged, target.id);
    setTurn(damaged, target.id);
    wounded.hand = [card("new-armor", "teng_jia")];
    const replaced = applyAction(damaged, { type: "play_card", playerId: target.id, cardId: "new-armor" });
    expect(player(replaced, target.id).hp).toBe(hp);
    expect(replaced.discardPile.map((candidate) => candidate.id)).toContain("lion");
  });
});

describe("authority, immutability, and private projection", () => {
  it("normalizes persisted pre-metadata cards and turn fields during an upgrade", () => {
    const initial = createGame({ playerIds: ["a", "b"], seed: seedFor(9081) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    const legacySlash = card("legacy-slash", "slash") as unknown as Record<string, unknown>;
    delete legacySlash.name;
    delete legacySlash.category;
    delete legacySlash.suit;
    delete legacySlash.rank;
    actor.hand = [legacySlash as unknown as Card];
    target.hand = [];
    const legacyTurn = initial.turn as unknown as Partial<TurnState>;
    delete legacyTurn.wineUsed;
    delete legacyTurn.slashDamageBonus;
    const targetHp = target.hp;

    const attacked = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "legacy-slash",
      targetId: target.id,
    });
    expect(attacked.turn).toMatchObject({ wineUsed: false, slashDamageBonus: 0 });
    expect(attacked.resolvingCards[0]).toMatchObject({
      name: "杀",
      category: "basic",
      suit: "spade",
      rank: 1,
    });
    const legacyPending = attacked.pendingResponse as unknown as Record<string, unknown>;
    delete legacyPending.slashKind;
    delete legacyPending.damage;
    delete legacyPending.nature;
    const resolved = applyAction(attacked, {
      type: "respond",
      playerId: target.id,
      cardId: null,
    });
    expect(player(resolved, target.id).hp).toBe(targetHp - 1);
    expect(resolved.resolvingCards).toEqual([]);
    expect(resolved.discardPile[0]).toMatchObject({ id: "legacy-slash", name: "杀" });
  });

  it("rejects active Dodge, invalid Duel targets, and responses with unknown cards", () => {
    const initial = createGame({ playerIds: ["a", "b", "c"], seed: seedFor(909) });
    const actor = player(initial, initial.currentPlayerId);
    const target = orderedOpponents(initial, actor.id)[0];
    if (!target) throw new Error("Missing target");
    actor.hand = [card("active-dodge", "dodge"), card("duel", "duel")];

    expectRuleError(
      () =>
        applyAction(initial, {
          type: "play_card",
          playerId: actor.id,
          cardId: "active-dodge",
        }),
      "INVALID_CARD",
    );
    expectRuleError(
      () =>
        applyAction(initial, {
          type: "play_card",
          playerId: actor.id,
          cardId: "duel",
          targetId: actor.id,
        }),
      "INVALID_TARGET",
    );
    const challenged = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "duel",
      targetId: target.id,
    });
    expectRuleError(
      () =>
        applyAction(challenged, {
          type: "respond",
          playerId: target.id,
          cardId: "not-owned",
        }),
      "CARD_NOT_FOUND",
    );
    expect(challenged.pendingResponse).not.toBeNull();
    expect(player(challenged, target.id).hand).toEqual(player(initial, target.id).hand);
  });

  it("hides hands, deck, RNG, and another player's actionable card IDs", () => {
    const initial = createGame({
      playerIds: ["a", "b", "c", "d"],
      seed: seedFor(910),
    });
    const actor = player(initial, initial.currentPlayerId);
    const [target, observer] = orderedOpponents(initial, actor.id);
    if (!target || !observer) throw new Error("Missing players");
    actor.hand = [card("public-duel", "duel")];
    target.hand = [card("private-slash", "slash"), card("private-peach", "peach")];

    const challenged = applyAction(initial, {
      type: "play_card",
      playerId: actor.id,
      cardId: "public-duel",
      targetId: target.id,
    });
    const targetView = getGameView(challenged, target.id);
    expect(targetView.prompt).toMatchObject({
      type: "respond",
      allowedCardIds: ["private-slash"],
    });
    expect(targetView.players.find((candidate) => candidate.id === target.id)?.hand).toEqual(
      player(challenged, target.id).hand,
    );

    const observerView = getGameView(challenged, observer.id);
    expect(observerView.prompt).toEqual({ type: "waiting" });
    expect(observerView.players.find((candidate) => candidate.id === target.id)).toMatchObject({
      hand: null,
      handCount: 2,
    });
    const serialized = JSON.stringify(observerView);
    expect(serialized).not.toContain("private-slash");
    expect(serialized).not.toContain("private-peach");
    expect(serialized).not.toContain(challenged.rng.key);
    expect(serialized).not.toContain(challenged.deck[0]?.id ?? "impossible-secret");
    expect("deck" in observerView).toBe(false);
    expect(JSON.parse(serialized)).toEqual(observerView);

    const pending = observerView.pendingResponse;
    expect(pending?.type).toBe("duel");
    expect("remainingTargetIds" in (pending as PendingMassAttackResponse)).toBe(false);
  });
});
