import { describe, expect, it } from "vitest";
import { gameActionSchema } from "./room-schemas.js";

const playerId = "11111111-1111-4111-8111-111111111111";
const targetId = "22222222-2222-4222-8222-222222222222";

describe("gameActionSchema skill actions", () => {
  it("accepts supported active and conversion skill payloads", () => {
    expect(gameActionSchema.parse({
      type: "use_skill",
      playerId,
      skillId: "wusheng",
      cardIds: ["red-card"],
      targetId,
    })).toEqual({
      type: "use_skill",
      playerId,
      skillId: "wusheng",
      cardIds: ["red-card"],
      targetId,
    });

    expect(gameActionSchema.safeParse({
      type: "use_skill",
      playerId,
      skillId: "kurou",
    }).success).toBe(true);

    for (const skillId of ["zhiheng", "rende", "qingnang", "jieyin", "guose", "qingguo", "jijiu"] as const) {
      expect(gameActionSchema.safeParse({
        type: "use_skill",
        playerId,
        skillId,
        cardIds: skillId === "jieyin" ? ["first", "second"] : ["cost-card"],
        targetId,
      }).success).toBe(true);
    }

    expect(gameActionSchema.parse({
      type: "resolve_skill",
      playerId,
      skillId: "keji",
      activate: true,
    })).toEqual({
      type: "resolve_skill",
      playerId,
      skillId: "keji",
      activate: true,
    });
  });

  it("rejects unsupported skills and oversized skill costs", () => {
    expect(gameActionSchema.safeParse({
      type: "use_skill",
      playerId,
      skillId: "paoxiao",
    }).success).toBe(false);
    expect(gameActionSchema.safeParse({
      type: "use_skill",
      playerId,
      skillId: "zhiheng",
      cardIds: Array.from({ length: 201 }, (_, index) => `card-${index}`),
      targetId,
    }).success).toBe(false);
    expect(gameActionSchema.safeParse({
      type: "resolve_skill",
      playerId,
      skillId: "kurou",
      activate: true,
    }).success).toBe(false);
  });
});
