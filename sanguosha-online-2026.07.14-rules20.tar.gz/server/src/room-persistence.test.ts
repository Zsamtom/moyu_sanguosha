import type { Pool } from "pg";
import { createGame } from "@sanguosha/shared";
import { describe, expect, it, vi } from "vitest";
import {
  loadRoomSnapshot,
  RoomSnapshotWriter,
} from "./room-persistence.js";
import { RoomService, type RoomServiceSnapshot } from "./rooms.js";

function poolWithQuery(query: Pool["query"]): Pool {
  return { query } as unknown as Pool;
}

describe("room snapshot persistence", () => {
  it("restores a departed seat tombstone while allowing that account in a new room", async () => {
    const playerIds = [
      "11111111-1111-4111-8111-111111111111",
      "22222222-2222-4222-8222-222222222222",
      "33333333-3333-4333-8333-333333333333",
      "44444444-4444-4444-8444-444444444444",
      "55555555-5555-4555-8555-555555555555",
    ];
    const game = createGame({ playerIds, seed: "6".padStart(64, "0") });
    const loyalist = game.players.find((player) => player.role === "loyalist");
    const lord = game.players.find((player) => player.role === "lord");
    if (!loyalist || !lord) throw new Error("Missing required roles");
    game.discardPile.push(...loyalist.hand, ...Object.values(loyalist.equipment), ...loyalist.judgment);
    loyalist.hand = [];
    loyalist.equipment = {};
    loyalist.judgment = [];
    loyalist.alive = false;
    loyalist.hp = 0;
    const startedRoomId = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
    const newRoomId = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
    const snapshot: RoomServiceSnapshot = {
      version: 1,
      rooms: [
        {
          id: startedRoomId,
          name: "离席后仍在运行",
          ownerId: lord.id,
          status: "playing",
          maxPlayers: 5,
          createdAt: new Date().toISOString(),
          players: playerIds.map((id, seat) => ({
            id,
            username: `player-${seat}`,
            displayName: `player-${seat}`,
            ready: id !== loyalist.id,
            connected: false,
            seat,
            departed: id === loyalist.id,
          })),
          game,
        },
        {
          id: newRoomId,
          name: "离席者的新房间",
          ownerId: loyalist.id,
          status: "waiting",
          maxPlayers: 2,
          createdAt: new Date().toISOString(),
          players: [{
            id: loyalist.id,
            username: "leaver",
            displayName: "leaver",
            ready: false,
            connected: false,
            seat: 0,
          }],
        },
      ],
    };
    const pool = poolWithQuery(vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"]);

    const result = await loadRoomSnapshot(pool);

    expect(result.kind).toBe("valid");
    if (result.kind !== "valid") throw new Error(result.reason);
    const restored = new RoomService();
    restored.restoreSnapshot(result.snapshot);
    expect(restored.get(startedRoomId)).toMatchObject({ status: "playing", playerCount: 4 });
    expect(restored.members(startedRoomId)).not.toContain(loyalist.id);
    expect(restored.getForUser(loyalist.id)?.id).toBe(newRoomId);
  });

  it("upgrades an old snapshot and preserves a turn-start rescue continuation", async () => {
    const ownerId = "11111111-1111-4111-8111-111111111111";
    const guestId = "22222222-2222-4222-8222-222222222222";
    const game = createGame({ playerIds: [ownerId, guestId], seed: "7".padStart(64, "0") });
    const victim = game.players.find((player) => player.id !== game.currentPlayerId);
    if (!victim) throw new Error("Missing victim");
    victim.hp = 0;
    game.turn.phase = "respond";
    game.pendingResponse = {
      type: "dying",
      victimId: victim.id,
      damageSourceId: game.currentPlayerId,
      targetId: victim.id,
      remainingResponderIds: [game.currentPlayerId],
      resume: { type: "turn_start" },
    };
    const snapshot: RoomServiceSnapshot = {
      version: 1,
      rooms: [{
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        name: "濒死恢复",
        ownerId,
        status: "playing",
        maxPlayers: 2,
        createdAt: new Date().toISOString(),
        players: [
          { id: ownerId, username: "owner", displayName: "owner", ready: true, connected: false, seat: 0 },
          { id: guestId, username: "guest", displayName: "guest", ready: true, connected: false, seat: 1 },
        ],
        game,
      }],
    };
    const legacySnapshot = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: {
        players: Array<Record<string, unknown>>;
        turn: Record<string, unknown>;
        virtualCardOrigins?: Record<string, unknown>;
      } }>;
    };
    for (const player of legacySnapshot.rooms[0]!.game.players) {
      delete player.judgment;
      delete player.chained;
      delete player.generalId;
    }
    delete legacySnapshot.rooms[0]!.game.turn.skipDraw;
    delete legacySnapshot.rooms[0]!.game.turn.skipPlay;
    delete legacySnapshot.rooms[0]!.game.turn.luoyiActive;
    delete legacySnapshot.rooms[0]!.game.turn.slashRespondedInPlayPhase;
    delete legacySnapshot.rooms[0]!.game.turn.skillUseCounts;
    delete legacySnapshot.rooms[0]!.game.turn.rendeGivenCount;
    delete legacySnapshot.rooms[0]!.game.turn.rendeRecovered;
    delete legacySnapshot.rooms[0]!.game.virtualCardOrigins;
    const pool = poolWithQuery(vi.fn().mockResolvedValue({ rows: [{ snapshot: legacySnapshot }] }) as Pool["query"]);

    const result = await loadRoomSnapshot(pool);

    expect(result).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: {
        players: [{ judgment: [], chained: false, generalId: null }, { judgment: [], chained: false, generalId: null }],
        turn: {
          skipDraw: false,
          skipPlay: false,
          luoyiActive: false,
          slashRespondedInPlayPhase: false,
          skillUseCounts: {},
          rendeGivenCount: 0,
          rendeRecovered: false,
        },
        virtualCardOrigins: {},
        pendingResponse: { type: "dying", victimId: victim.id, resume: { type: "turn_start" } },
      } }] },
    });

    victim.hp = 1;
    game.pendingResponse = {
      type: "nullification",
      attackerId: ownerId,
      targetId: guestId,
      effectTargetId: guestId,
      cardId: "persisted-duel",
      cardKind: "duel",
      remainingResponderIds: [ownerId],
      negated: true,
      effect: { type: "duel", sourceId: ownerId, targetId: guestId, cardId: "persisted-duel" },
    };
    const nullificationResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(nullificationResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "nullification", negated: true } } }] },
    });

    game.pendingResponse = {
      type: "skill_choice",
      targetId: ownerId,
      skillId: "luoyi",
      resume: { type: "finish_draw", playerId: ownerId },
    };
    const skillChoiceResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(skillChoiceResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "skill_choice",
        skillId: "luoyi",
        resume: { type: "finish_draw", playerId: ownerId },
      } } }] },
    });

    const incompatibleSkillChoice = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: { pendingResponse: { skillId: string; resume: { type: string } } } }>;
    };
    incompatibleSkillChoice.rooms[0]!.game.pendingResponse.skillId = "keji";
    const incompatibleSkillChoiceResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: incompatibleSkillChoice }] }) as Pool["query"],
    ));
    expect(incompatibleSkillChoiceResult).toMatchObject({
      kind: "invalid",
      reason: expect.stringContaining("incompatible resume point"),
    });

    game.pendingResponse = {
      type: "zone_selection",
      attackerId: ownerId,
      targetId: ownerId,
      victimId: guestId,
      cardId: "persisted-snatch",
      cardKind: "shun_shou_qian_yang",
      mode: "gain",
    };
    const zoneSelectionResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(zoneSelectionResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "zone_selection", mode: "gain" } } }] },
    });

    const poolCard = game.deck.pop();
    if (!poolCard) throw new Error("Missing Amazing Grace pool fixture");
    game.pendingResponse = {
      type: "amazing_grace_selection",
      attackerId: ownerId,
      targetId: guestId,
      cardId: "persisted-grace",
      pool: [poolCard],
      remainingTargetIds: [ownerId],
    };
    const amazingGraceResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(amazingGraceResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "amazing_grace_selection", pool: [{ id: poolCard.id }] } } }] },
    });

    game.pendingResponse = {
      type: "dying",
      victimId: guestId,
      damageSourceId: ownerId,
      targetId: guestId,
      remainingResponderIds: [ownerId],
      resume: {
        type: "chain_damage",
        sourceId: ownerId,
        amount: 1,
        nature: "fire",
        remainingTargetIds: [ownerId],
        finalResume: { type: "finish_effect" },
      },
    };
    const chainDamageResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(chainDamageResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "dying", resume: { type: "chain_damage", nature: "fire" } } } }] },
    });

    const kurouPlayer = game.players.find((player) => player.id === guestId);
    if (!kurouPlayer) throw new Error("Missing Kurou persistence fixture player");
    kurouPlayer.alive = true;
    kurouPlayer.hp = 0;
    game.pendingResponse = {
      type: "dying",
      victimId: guestId,
      damageSourceId: null,
      targetId: guestId,
      remainingResponderIds: [ownerId],
      resume: { type: "skill", skillId: "kurou", playerId: guestId },
    };
    const kurouResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(kurouResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "dying",
        damageSourceId: null,
        resume: { type: "skill", skillId: "kurou", playerId: guestId },
      } } }] },
    });

    const invalidKurouSnapshot = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: { pendingResponse: { resume: { playerId: string } } } }>;
    };
    invalidKurouSnapshot.rooms[0]!.game.pendingResponse.resume.playerId = "99999999-9999-4999-8999-999999999999";
    const invalidKurouResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: invalidKurouSnapshot }] }) as Pool["query"],
    ));
    expect(invalidKurouResult).toMatchObject({
      kind: "invalid",
      reason: expect.stringContaining("unknown player"),
    });

    kurouPlayer.hp = 1;

    const slashCard = game.deck.pop();
    if (!slashCard) throw new Error("Missing weapon Slash fixture");
    game.resolvingCards = [slashCard];
    game.pendingResponse = {
      type: "weapon_action",
      weaponKind: "han_bing_jian",
      stage: "hanbing_select",
      attackerId: ownerId,
      targetId: ownerId,
      victimId: guestId,
      remainingSelections: 2,
      slash: {
        type: "slash",
        attackerId: ownerId,
        targetId: guestId,
        cardId: slashCard.id,
        slashKind: "slash",
        damage: 1,
        nature: "normal",
        color: "black",
        remainingTargetIds: [],
        zhuQueChecked: true,
        ciXiongChecked: true,
      },
    };
    const weaponResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(weaponResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: { type: "weapon_action", stage: "hanbing_select" } } }] },
    });
  });

  it("defaults legacy Wushuang response counters while restoring Slash and Duel prompts", async () => {
    const ownerId = "11111111-1111-4111-8111-111111111111";
    const guestId = "22222222-2222-4222-8222-222222222222";
    const game = createGame({ playerIds: [ownerId, guestId], seed: "8".padStart(64, "0") });
    const resolving = game.players[0]!.hand.shift();
    if (!resolving) throw new Error("Missing response-counter fixture card");
    game.resolvingCards = [resolving];
    game.turn.phase = "respond";
    game.pendingResponse = {
      type: "slash",
      attackerId: ownerId,
      targetId: guestId,
      cardId: resolving.id,
      slashKind: "slash",
      damage: 1,
      nature: "normal",
      color: "black",
      remainingTargetIds: [],
      zhuQueChecked: true,
      ciXiongChecked: true,
    };
    const snapshot: RoomServiceSnapshot = {
      version: 1,
      rooms: [{
        id: "cccccccc-cccc-4ccc-8ccc-cccccccccccc",
        name: "旧无双响应",
        ownerId,
        status: "playing",
        maxPlayers: 2,
        createdAt: new Date().toISOString(),
        players: [
          { id: ownerId, username: "owner", displayName: "owner", ready: true, connected: false, seat: 0 },
          { id: guestId, username: "guest", displayName: "guest", ready: true, connected: false, seat: 1 },
        ],
        game,
      }],
    };

    const slashResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: structuredClone(snapshot) }] }) as Pool["query"],
    ));
    expect(slashResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "slash", requiredDodgeCount: 1, dodgesPlayed: 0,
      } } }] },
    });

    game.pendingResponse = { ...game.pendingResponse, requiredDodgeCount: 2, dodgesPlayed: 1 };
    const progressedSlashResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: structuredClone(snapshot) }] }) as Pool["query"],
    ));
    expect(progressedSlashResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "slash", requiredDodgeCount: 2, dodgesPlayed: 1,
      } } }] },
    });

    game.pendingResponse = {
      type: "duel",
      attackerId: ownerId,
      targetId: guestId,
      cardId: resolving.id,
      initiatorId: ownerId,
      originalTargetId: guestId,
    };
    const legacyDuelResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: structuredClone(snapshot) }] }) as Pool["query"],
    ));
    expect(legacyDuelResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "duel", requiredSlashCount: 1, slashesPlayed: 0,
      } } }] },
    });

    game.pendingResponse = { ...game.pendingResponse, requiredSlashCount: 2, slashesPlayed: 1 };
    const progressedDuelResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: structuredClone(snapshot) }] }) as Pool["query"],
    ));
    expect(progressedDuelResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: { pendingResponse: {
        type: "duel", requiredSlashCount: 2, slashesPlayed: 1,
      } } }] },
    });
  });

  it("validates per-turn skill counters and virtual delayed-card origins", async () => {
    const ownerId = "11111111-1111-4111-8111-111111111111";
    const guestId = "22222222-2222-4222-8222-222222222222";
    const game = createGame({ playerIds: [ownerId, guestId], seed: "9".padStart(64, "0") });
    const originIndex = game.deck.findIndex((card) => card.kind !== "le_bu_si_shu");
    const [origin] = game.deck.splice(originIndex, 1);
    if (!origin) throw new Error("Missing virtual delayed-card origin fixture");
    const virtualCard: typeof origin = { ...origin, kind: "le_bu_si_shu" };
    game.players[1]!.judgment.push(virtualCard);
    game.virtualCardOrigins[virtualCard.id] = origin.kind;
    game.turn.skillUseCounts = { zhiheng: 1, qingnang: 0 };
    game.turn.rendeGivenCount = 1;
    game.turn.rendeRecovered = false;
    const snapshot: RoomServiceSnapshot = {
      version: 1,
      rooms: [{
        id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
        name: "技能状态持久化",
        ownerId,
        status: "playing",
        maxPlayers: 2,
        createdAt: new Date().toISOString(),
        players: [
          { id: ownerId, username: "owner", displayName: "owner", ready: true, connected: false, seat: 0 },
          { id: guestId, username: "guest", displayName: "guest", ready: true, connected: false, seat: 1 },
        ],
        game,
      }],
    };

    const validResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot }] }) as Pool["query"],
    ));
    expect(validResult).toMatchObject({
      kind: "valid",
      snapshot: { rooms: [{ game: {
        turn: { skillUseCounts: { zhiheng: 1, qingnang: 0 }, rendeGivenCount: 1, rendeRecovered: false },
        virtualCardOrigins: { [virtualCard.id]: origin.kind },
      } }] },
    });

    const missingVirtualCard = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: { virtualCardOrigins: Record<string, string> } }>;
    };
    missingVirtualCard.rooms[0]!.game.virtualCardOrigins.missing = "slash";
    const missingVirtualCardResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: missingVirtualCard }] }) as Pool["query"],
    ));
    expect(missingVirtualCardResult).toMatchObject({
      kind: "invalid",
      reason: expect.stringContaining("exactly one resolving or judgment card"),
    });

    const wrongVirtualKind = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: { players: Array<{ judgment: Array<{ id: string; kind: string }> }> } }>;
    };
    const mappedCard = wrongVirtualKind.rooms[0]!.game.players
      .flatMap((player) => player.judgment)
      .find((card) => card.id === virtualCard.id);
    if (!mappedCard) throw new Error("Missing mapped virtual-card fixture");
    mappedCard.kind = origin.kind;
    const wrongVirtualKindResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: wrongVirtualKind }] }) as Pool["query"],
    ));
    expect(wrongVirtualKindResult).toMatchObject({
      kind: "invalid",
      reason: expect.stringContaining("virtual le_bu_si_shu"),
    });

    const invalidCounters = structuredClone(snapshot) as unknown as {
      rooms: Array<{ game: { turn: { skillUseCounts: Record<string, number> } } }>;
    };
    invalidCounters.rooms[0]!.game.turn.skillUseCounts = { not_a_skill: 1, zhiheng: -1 };
    const invalidCounterResult = await loadRoomSnapshot(poolWithQuery(
      vi.fn().mockResolvedValue({ rows: [{ snapshot: invalidCounters }] }) as Pool["query"],
    ));
    expect(invalidCounterResult.kind).toBe("invalid");
  });

  it("rejects an incomplete game before RoomService restoration", async () => {
    const pool = poolWithQuery(vi.fn().mockResolvedValue({
      rows: [{
        snapshot: {
          version: 1,
          rooms: [{
            id: "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa",
            name: "损坏对局",
            ownerId: "11111111-1111-4111-8111-111111111111",
            status: "playing",
            maxPlayers: 2,
            createdAt: new Date().toISOString(),
            players: [{
              id: "11111111-1111-4111-8111-111111111111",
              username: "owner",
              displayName: "owner",
              ready: true,
              connected: false,
              seat: 0,
            }],
            game: { version: 1 },
          }],
        },
      }],
    }) as Pool["query"]);

    const result = await loadRoomSnapshot(pool);

    expect(result.kind).toBe("invalid");
    if (result.kind === "invalid") expect(result.reason).toContain("Required");
  });

  it("coalesces queued mutations to the newest snapshot", async () => {
    let releaseFirstWrite: (() => void) | undefined;
    const firstWrite = new Promise<void>((resolve) => { releaseFirstWrite = resolve; });
    const query = vi.fn()
      .mockImplementationOnce(async () => {
        await firstWrite;
        return { rows: [] };
      })
      .mockResolvedValue({ rows: [] });
    const writer = new RoomSnapshotWriter(poolWithQuery(query as Pool["query"]), vi.fn());
    const first = { version: 1, rooms: [], marker: "first" } as unknown as RoomServiceSnapshot;
    const middle = { version: 1, rooms: [], marker: "middle" } as unknown as RoomServiceSnapshot;
    const newest = { version: 1, rooms: [], marker: "newest" } as unknown as RoomServiceSnapshot;

    writer.enqueue(first);
    await vi.waitFor(() => expect(query).toHaveBeenCalledTimes(1));
    writer.enqueue(middle);
    writer.enqueue(newest);
    releaseFirstWrite?.();
    await writer.flush();

    expect(query).toHaveBeenCalledTimes(2);
    expect(query.mock.calls[1]?.[1]).toEqual([JSON.stringify(newest)]);
  });
});
