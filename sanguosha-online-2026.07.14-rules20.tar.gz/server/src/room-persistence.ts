import type { Pool } from "pg";
import { z } from "zod";
import type { RoomServiceSnapshot } from "./rooms.js";

const playerIdSchema = z.string().uuid();
const generalIdSchema = z.enum([
  "guan_yu", "huang_yue_ying", "liu_bei", "ma_chao", "zhang_fei", "zhao_yun", "zhu_ge_liang",
  "cao_cao", "guo_jia", "si_ma_yi", "xia_hou_dun", "xu_chu", "xun_yu", "zhang_liao", "zhen_ji",
  "da_qiao", "gan_ning", "huang_gai", "lu_xun", "lv_meng", "sun_quan", "sun_shang_xiang", "zhou_yu",
  "hua_tuo", "lv_bu", "diao_chan", "yuan_shu",
]);
const generalSkillIdSchema = z.enum([
  "wusheng", "jizhi", "qicai", "rende", "jijiang", "mashu", "tieqi",
  "paoxiao", "longdan", "guanxing", "kongcheng",
  "jianxiong", "hujia", "tiandu", "yiji", "guicai", "fankui", "ganglie",
  "luoyi", "tuxi", "luoshen", "qingguo",
  "guose", "liuli", "qixi", "kurou", "qianxun", "lianying", "keji",
  "zhiheng", "jiuyuan", "xiaoji", "jieyin", "yingzi", "fanjian",
  "jijiu", "qingnang", "wushuang", "biyue", "lijian", "yongsi", "weidi",
  "quhu", "jieming",
]);
const nonnegativeSafeIntegerSchema = z.number().int().nonnegative().max(Number.MAX_SAFE_INTEGER);
const cardKindSchema = z.enum([
  "slash",
  "fire_slash",
  "thunder_slash",
  "dodge",
  "peach",
  "wine",
  "ex_nihilo",
  "duel",
  "barbarian_invasion",
  "arrow_barrage",
  "peach_garden",
  "chi_tu", "da_wan", "zi_xing", "di_lu", "hua_liu", "jue_ying", "zhua_huang_fei_dian",
  "zhu_ge_lian_nu", "gu_ding_dao", "ci_xiong_shuang_gu_jian", "han_bing_jian",
  "qing_long_yan_yue_dao", "zhang_ba_she_mao", "guan_shi_fu", "fang_tian_hua_ji",
  "zhu_que_yu_shan", "qi_lin_gong",
  "ren_wang_dun", "teng_jia", "bai_yin_shi_zi", "ba_gua_zhen", "qing_gang_jian",
  "le_bu_si_shu", "bing_liang_cun_duan", "shan_dian",
  "wu_xie_ke_ji",
  "guo_he_chai_qiao", "shun_shou_qian_yang",
  "fire_attack", "amazing_grace", "borrowed_sword", "iron_chain",
]);
const cardSchema = z.object({
  id: z.string().min(1).max(80),
  kind: cardKindSchema,
  // These fields were added without changing the v1 snapshot version. Keep
  // them optional so rooms created by the previous production build migrate.
  name: z.string().min(1).max(20).optional(),
  category: z.enum(["basic", "trick", "equipment"]).optional(),
  suit: z.enum(["spade", "heart", "club", "diamond"]).optional(),
  rank: z.number().int().min(1).max(13).optional(),
});
const gamePlayerSchema = z.object({
  id: playerIdSchema,
  seat: z.number().int().min(0).max(9),
  role: z.enum(["lord", "loyalist", "rebel", "renegade"]),
  generalId: generalIdSchema.nullable().default(null),
  hp: z.number().int().min(0).max(10),
  maxHp: z.number().int().min(1).max(10),
  alive: z.boolean(),
  hand: z.array(cardSchema).max(200),
  equipment: z.object({
    weapon: cardSchema.optional(),
    armor: cardSchema.optional(),
    offensive_horse: cardSchema.optional(),
    defensive_horse: cardSchema.optional(),
  }).default({}),
  judgment: z.array(cardSchema).max(3).default([]),
  chained: z.boolean().default(false),
});
const turnSchema = z.object({
  number: z.number().int().positive(),
  playerId: playerIdSchema,
  phase: z.enum(["prepare", "judgment", "draw", "play", "respond", "discard", "end"]),
  slashUsed: z.boolean(),
  wineUsed: z.boolean().optional(),
  slashDamageBonus: z.number().int().min(0).max(1).optional(),
  requiredDiscardCount: z.number().int().min(0).max(200),
  skipDraw: z.boolean().default(false),
  skipPlay: z.boolean().default(false),
  luoyiActive: z.boolean().default(false),
  slashRespondedInPlayPhase: z.boolean().default(false),
  skillUseCounts: z.record(generalSkillIdSchema, nonnegativeSafeIntegerSchema).default({}),
  rendeGivenCount: nonnegativeSafeIntegerSchema.default(0),
  rendeRecovered: z.boolean().default(false),
});
const massAttackResponseSchema = z.object({
  type: z.literal("mass_attack"),
  attackerId: playerIdSchema,
  targetId: playerIdSchema,
  cardId: z.string().min(1).max(80),
  cardKind: z.enum(["barbarian_invasion", "arrow_barrage"]),
  responseKind: z.enum(["slash", "dodge"]),
  remainingTargetIds: z.array(playerIdSchema).max(9),
  armorAttempted: z.boolean().optional(),
});
const slashResponseSchema = z.object({
  type: z.literal("slash"),
  attackerId: playerIdSchema,
  targetId: playerIdSchema,
  cardId: z.string().min(1).max(100),
  slashKind: z.enum(["slash", "fire_slash", "thunder_slash"]).default("slash"),
  damage: z.number().int().positive().max(10).default(1),
  nature: z.enum(["normal", "fire", "thunder"]).default("normal"),
  color: z.enum(["red", "black", "colorless"]).default("colorless"),
  armorAttempted: z.boolean().optional(),
  armorIgnored: z.boolean().optional(),
  requiredDodgeCount: z.number().int().min(1).max(2).default(1),
  // A completed 2/2 Wushuang response can remain nested inside a weapon
  // decision (Guan Shi Fu / Qing Long Yan Yue Dao) until that prompt resolves.
  dodgesPlayed: z.number().int().min(0).max(2).default(0),
  remainingTargetIds: z.array(playerIdSchema).max(2).default([]),
  zhuQueChecked: z.boolean().default(true),
  ciXiongChecked: z.boolean().default(true),
});
const trickEffectSchema = z.discriminatedUnion("type", [
  z.object({ type: z.literal("ex_nihilo"), sourceId: playerIdSchema, targetId: playerIdSchema, cardId: z.string().min(1).max(80) }),
  z.object({ type: z.literal("duel"), sourceId: playerIdSchema, targetId: playerIdSchema, cardId: z.string().min(1).max(80) }),
  z.object({ type: z.literal("mass_attack"), pending: massAttackResponseSchema }),
  z.object({
    type: z.literal("peach_garden"), sourceId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), remainingTargetIds: z.array(playerIdSchema).max(9),
  }),
  z.object({
    type: z.literal("delayed_trick"), sourceId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), cardKind: z.enum(["le_bu_si_shu", "bing_liang_cun_duan", "shan_dian"]),
  }),
  z.object({
    type: z.literal("zone_trick"), sourceId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), cardKind: z.enum(["guo_he_chai_qiao", "shun_shou_qian_yang"]),
  }),
  z.object({ type: z.literal("fire_attack"), sourceId: playerIdSchema, targetId: playerIdSchema, cardId: z.string().min(1).max(80) }),
  z.object({
    type: z.literal("borrowed_sword"), sourceId: playerIdSchema, targetId: playerIdSchema,
    attackTargetId: playerIdSchema, cardId: z.string().min(1).max(80),
  }),
  z.object({
    type: z.literal("iron_chain"), sourceId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), remainingTargetIds: z.array(playerIdSchema).max(2),
  }),
  z.object({
    type: z.literal("amazing_grace"), sourceId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), pool: z.array(cardSchema).max(10), remainingTargetIds: z.array(playerIdSchema).max(9),
  }),
]);
const baseDyingResumeSchema = z.union([
  z.object({ type: z.literal("finish_effect") }),
  z.object({ type: z.literal("turn_start") }),
  z.object({ type: z.literal("mass_attack"), pending: massAttackResponseSchema }),
  z.object({ type: z.literal("slash_sequence"), pending: slashResponseSchema }),
  z.object({ type: z.literal("skill"), skillId: z.literal("kurou"), playerId: playerIdSchema }),
]);

function baseDyingResumePlayerIds(resume: z.infer<typeof baseDyingResumeSchema>): string[] {
  if (resume.type === "mass_attack" || resume.type === "slash_sequence") {
    return [resume.pending.attackerId, resume.pending.targetId, ...resume.pending.remainingTargetIds];
  }
  if (resume.type === "skill") return [resume.playerId];
  return [];
}

const pendingResponseSchema = z.discriminatedUnion("type", [
  slashResponseSchema,
  z.object({
    type: z.literal("weapon_action"),
    weaponKind: z.enum(["zhu_que_yu_shan", "ci_xiong_shuang_gu_jian", "guan_shi_fu", "qing_long_yan_yue_dao", "han_bing_jian", "qi_lin_gong"]),
    stage: z.enum(["zhuque_convert", "cixiong_activate", "cixiong_choice", "guanshi_force_hit", "qinglong_followup", "hanbing_prevent", "hanbing_select", "qilin_discard_horse"]),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    victimId: playerIdSchema,
    slash: slashResponseSchema,
    remainingSelections: z.number().int().min(1).max(2).optional(),
  }),
  z.object({
    type: z.literal("duel"),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    cardId: z.string().min(1).max(80),
    initiatorId: playerIdSchema,
    originalTargetId: playerIdSchema,
    requiredSlashCount: z.number().int().min(1).max(2).default(1),
    slashesPlayed: z.number().int().min(0).max(1).default(0),
  }),
  massAttackResponseSchema,
  z.object({
    type: z.literal("nullification"),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    effectTargetId: playerIdSchema,
    cardId: z.string().min(1).max(80),
    cardKind: z.enum(["ex_nihilo", "duel", "barbarian_invasion", "arrow_barrage", "peach_garden", "le_bu_si_shu", "bing_liang_cun_duan", "shan_dian", "guo_he_chai_qiao", "shun_shou_qian_yang", "fire_attack", "amazing_grace", "borrowed_sword", "iron_chain"]),
    remainingResponderIds: z.array(playerIdSchema).max(9),
    negated: z.boolean(),
    effect: trickEffectSchema,
  }),
  z.object({
    type: z.literal("zone_selection"),
    attackerId: playerIdSchema,
    targetId: playerIdSchema,
    victimId: playerIdSchema,
    cardId: z.string().min(1).max(80),
    cardKind: z.enum(["guo_he_chai_qiao", "shun_shou_qian_yang"]),
    mode: z.enum(["discard", "gain"]),
  }),
  z.object({
    type: z.literal("fire_attack_reveal"), attackerId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80),
  }),
  z.object({
    type: z.literal("fire_attack_discard"), attackerId: playerIdSchema, targetId: playerIdSchema,
    victimId: playerIdSchema, cardId: z.string().min(1).max(80), revealedCardId: z.string().min(1).max(80),
  }),
  z.object({
    type: z.literal("amazing_grace_selection"), attackerId: playerIdSchema, targetId: playerIdSchema,
    cardId: z.string().min(1).max(80), pool: z.array(cardSchema).max(10), remainingTargetIds: z.array(playerIdSchema).max(9),
  }),
  z.object({
    type: z.literal("borrowed_sword"), attackerId: playerIdSchema, targetId: playerIdSchema,
    attackTargetId: playerIdSchema, cardId: z.string().min(1).max(80),
  }),
  z.object({
    type: z.literal("dying"),
    victimId: playerIdSchema,
    damageSourceId: playerIdSchema.nullable(),
    targetId: playerIdSchema,
    remainingResponderIds: z.array(playerIdSchema).max(9),
    resume: z.union([
      baseDyingResumeSchema,
      z.object({
        type: z.literal("chain_damage"), sourceId: playerIdSchema,
        amount: z.number().int().positive().max(10), nature: z.enum(["fire", "thunder"]),
        remainingTargetIds: z.array(playerIdSchema).max(9), finalResume: baseDyingResumeSchema,
      }),
    ]),
  }),
  z.object({
    type: z.literal("skill_choice"),
    targetId: playerIdSchema,
    skillId: z.enum(["luoyi", "keji"]),
    resume: z.discriminatedUnion("type", [
      z.object({ type: z.literal("finish_draw"), playerId: playerIdSchema }),
      z.object({
        type: z.literal("enter_discard"),
        playerId: playerIdSchema,
        count: z.number().int().min(0).max(200),
      }),
    ]),
  }),
]);
const gameSessionSchema = z.object({
  version: z.literal(1),
  status: z.enum(["playing", "finished"]),
  players: z.array(gamePlayerSchema).min(2).max(10),
  deck: z.array(cardSchema).max(200),
  discardPile: z.array(cardSchema).max(200),
  resolvingCards: z.array(cardSchema).max(200).optional(),
  virtualCardOrigins: z.record(z.string().min(1).max(80), cardKindSchema).default({}),
  currentPlayerId: playerIdSchema,
  turn: turnSchema,
  pendingResponse: pendingResponseSchema.nullable(),
  winner: z.object({
    side: z.enum(["lord", "rebel", "renegade"]),
    playerIds: z.array(playerIdSchema).min(1).max(10),
  }).nullable(),
  logs: z.array(z.object({
    id: z.number().int().positive(),
    type: z.enum(["system", "turn", "card", "damage", "death", "victory"]),
    message: z.string().min(1).max(500),
  })).max(500),
  rng: z.object({
    key: z.string().regex(/^[0-9a-f]{64}$/i),
    counter: z.number().int().min(0).max(0xffff_ffff),
  }),
  nextLogId: z.number().int().positive(),
}).superRefine((game, context) => {
  const playerIds = game.players.map((player) => player.id);
  const knownPlayers = new Set(playerIds);
  const issue = (message: string) => context.addIssue({ code: z.ZodIssueCode.custom, message });
  if (knownPlayers.size !== playerIds.length) issue("Game contains duplicate players");
  if (!knownPlayers.has(game.currentPlayerId)) issue("Current player is not in the game");
  if (game.turn.playerId !== game.currentPlayerId) issue("Turn player does not match current player");
  if (game.players.some((player, index) => player.seat !== index)) issue("Game seats are not contiguous");
  if (game.players.some((player) => player.hp > player.maxHp)) issue("Player hp exceeds maxHp");
  const dyingVictimId = game.pendingResponse?.type === "dying" ? game.pendingResponse.victimId : undefined;
  if (game.players.some((player) =>
    (!player.alive && player.hp !== 0) ||
    (player.alive && player.hp <= 0 && player.id !== dyingVictimId)
  )) issue("Player alive flag disagrees with hp");
  const allCards = [
    ...game.deck,
    ...game.discardPile,
    ...(game.resolvingCards ?? []),
    ...game.players.flatMap((player) => player.hand),
    ...game.players.flatMap((player) => Object.values(player.equipment)),
    ...game.players.flatMap((player) => player.judgment),
    ...(game.pendingResponse?.type === "amazing_grace_selection"
      ? game.pendingResponse.pool
      : game.pendingResponse?.type === "nullification" && game.pendingResponse.effect.type === "amazing_grace"
        ? game.pendingResponse.effect.pool
        : []),
  ];
  if (new Set(allCards.map((card) => card.id)).size !== allCards.length) issue("Card appears in multiple zones");
  const virtualDelayedCards = [
    ...(game.resolvingCards ?? []),
    ...game.players.flatMap((player) => player.judgment),
  ];
  for (const cardId of Object.keys(game.virtualCardOrigins)) {
    const matches = virtualDelayedCards.filter((card) => card.id === cardId);
    if (matches.length !== 1) {
      issue("Virtual card origin must reference exactly one resolving or judgment card");
      continue;
    }
    if (matches[0]!.kind !== "le_bu_si_shu") {
      issue("Virtual card origin must reference a virtual le_bu_si_shu card");
    }
  }
  if (game.pendingResponse) {
    const relatedIds = game.pendingResponse.type === "dying"
      ? [
          game.pendingResponse.victimId,
          ...(game.pendingResponse.damageSourceId === null ? [] : [game.pendingResponse.damageSourceId]),
          game.pendingResponse.targetId,
          ...game.pendingResponse.remainingResponderIds,
          ...(game.pendingResponse.resume.type === "chain_damage"
            ? [
                game.pendingResponse.resume.sourceId,
                ...game.pendingResponse.resume.remainingTargetIds,
                ...baseDyingResumePlayerIds(game.pendingResponse.resume.finalResume),
              ]
            : baseDyingResumePlayerIds(game.pendingResponse.resume)),
        ]
      : game.pendingResponse.type === "zone_selection"
        ? [game.pendingResponse.attackerId, game.pendingResponse.targetId, game.pendingResponse.victimId]
      : game.pendingResponse.type === "fire_attack_discard"
        ? [game.pendingResponse.attackerId, game.pendingResponse.targetId, game.pendingResponse.victimId]
      : game.pendingResponse.type === "amazing_grace_selection"
        ? [game.pendingResponse.attackerId, game.pendingResponse.targetId, ...game.pendingResponse.remainingTargetIds]
      : game.pendingResponse.type === "nullification"
        ? [
            game.pendingResponse.attackerId,
            game.pendingResponse.targetId,
            game.pendingResponse.effectTargetId,
            ...game.pendingResponse.remainingResponderIds,
            ...(game.pendingResponse.effect.type === "mass_attack"
              ? [game.pendingResponse.effect.pending.attackerId, game.pendingResponse.effect.pending.targetId, ...game.pendingResponse.effect.pending.remainingTargetIds]
              : [
                  game.pendingResponse.effect.sourceId,
                  game.pendingResponse.effect.targetId,
                  ...(game.pendingResponse.effect.type === "peach_garden" || game.pendingResponse.effect.type === "iron_chain" || game.pendingResponse.effect.type === "amazing_grace"
                    ? game.pendingResponse.effect.remainingTargetIds
                    : []),
                  ...(game.pendingResponse.effect.type === "borrowed_sword" ? [game.pendingResponse.effect.attackTargetId] : []),
                ]),
          ]
        : game.pendingResponse.type === "skill_choice"
          ? [game.pendingResponse.targetId, game.pendingResponse.resume.playerId]
        : [
          game.pendingResponse.attackerId,
          game.pendingResponse.targetId,
          ...(game.pendingResponse.type === "duel"
            ? [game.pendingResponse.initiatorId, game.pendingResponse.originalTargetId]
            : []),
          ...(game.pendingResponse.type === "mass_attack" ? game.pendingResponse.remainingTargetIds : []),
          ...(game.pendingResponse.type === "borrowed_sword" ? [game.pendingResponse.attackTargetId] : []),
        ];
    if (relatedIds.some((id) => !knownPlayers.has(id))) issue("Pending response references an unknown player");
    if (game.pendingResponse.type === "skill_choice") {
      if (game.pendingResponse.targetId !== game.pendingResponse.resume.playerId) {
        issue("Skill choice target and resume player disagree");
      }
      if (
        (game.pendingResponse.skillId === "luoyi" && game.pendingResponse.resume.type !== "finish_draw") ||
        (game.pendingResponse.skillId === "keji" && game.pendingResponse.resume.type !== "enter_discard")
      ) {
        issue("Skill choice has an incompatible resume point");
      }
    }
    if (
      game.pendingResponse.type === "slash" &&
      (game.pendingResponse.dodgesPlayed ?? 0) >= (game.pendingResponse.requiredDodgeCount ?? 1)
    ) {
      issue("Slash response progress must remain below its required Dodge count");
    }
    if (
      game.pendingResponse.type === "duel" &&
      (game.pendingResponse.slashesPlayed ?? 0) >= (game.pendingResponse.requiredSlashCount ?? 1)
    ) {
      issue("Duel response progress must remain below its required Slash count");
    }
    if (game.turn.phase !== "respond") issue("Pending response exists outside respond phase");
  } else if (game.turn.phase === "respond") {
    issue("Respond phase has no pending response");
  }
  if (game.winner?.playerIds.some((id) => !knownPlayers.has(id))) issue("Winner references an unknown player");
  if ((game.status === "finished") !== (game.winner !== null)) issue("Game status and winner disagree");
});

const playerSchema = z.object({
  id: playerIdSchema,
  username: z.string().min(1).max(32),
  displayName: z.string().min(1).max(40),
  ready: z.boolean(),
  connected: z.boolean(),
  seat: z.number().int().min(0).max(9),
  isBot: z.boolean().default(false),
  // Started rooms retain departed players as hidden seat-roster tombstones so
  // their authoritative GameSession remains restorable after a leave/timeout.
  departed: z.boolean().default(false),
});

const roomSchema = z.object({
  id: z.string().uuid(),
  name: z.string().min(1).max(40),
  ownerId: playerIdSchema,
  status: z.enum(["waiting", "playing", "finished"]),
  maxPlayers: z.number().int().min(2).max(10),
  createdAt: z.string().datetime(),
  players: z.array(playerSchema).min(1).max(10),
  game: gameSessionSchema.optional(),
}).superRefine((room, context) => {
  const issue = (message: string) => context.addIssue({ code: z.ZodIssueCode.custom, message });
  const playerIds = room.players.map((player) => player.id);
  const activePlayerIds = room.players.filter((player) => !player.departed).map((player) => player.id);
  if (new Set(playerIds).size !== playerIds.length) issue("Room contains duplicate players");
  if (room.players.some((player, index) => player.seat !== index)) issue("Room seats are not contiguous");
  if (!activePlayerIds.includes(room.ownerId)) issue("Room owner is not an active member");
  if (room.players.length > room.maxPlayers) issue("Room exceeds maxPlayers");
  if (room.status === "waiting" && room.game) issue("Waiting room unexpectedly contains a game");
  if (room.status !== "waiting" && !room.game) issue("Started room has no game state");
  if (room.game) {
    const gamePlayerIds = room.game.players.map((player) => player.id);
    if (gamePlayerIds.length !== playerIds.length || gamePlayerIds.some((id, index) => id !== playerIds[index])) {
      issue("Room members and game players disagree");
    }
    if (room.status !== room.game.status) issue("Room status and game status disagree");
  }
});

const roomSnapshotSchema = z.object({
  version: z.literal(1),
  rooms: z.array(roomSchema).max(1_000),
}).superRefine((snapshot, context) => {
  const roomIds = snapshot.rooms.map((room) => room.id);
  const userIds = snapshot.rooms.flatMap((room) =>
    room.players.filter((player) => !player.departed).map((player) => player.id)
  );
  if (new Set(roomIds).size !== roomIds.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "Snapshot contains duplicate rooms" });
  }
  if (new Set(userIds).size !== userIds.length) {
    context.addIssue({ code: z.ZodIssueCode.custom, message: "User appears in multiple rooms" });
  }
});

export type RoomSnapshotLoadResult =
  | { readonly kind: "empty" }
  | { readonly kind: "valid"; readonly snapshot: RoomServiceSnapshot }
  | { readonly kind: "invalid"; readonly reason: string };

export async function loadRoomSnapshot(pool: Pool): Promise<RoomSnapshotLoadResult> {
  const result = await pool.query<{ snapshot: unknown }>(
    "SELECT snapshot FROM room_state WHERE id = 1",
  );
  const value = result.rows[0]?.snapshot;
  if (value === undefined) return { kind: "empty" };
  const parsed = roomSnapshotSchema.safeParse(value);
  if (!parsed.success) {
    return { kind: "invalid", reason: parsed.error.issues.map((issue) => issue.message).join("; ").slice(0, 2_000) };
  }
  return { kind: "valid", snapshot: parsed.data as unknown as RoomServiceSnapshot };
}

export async function quarantineInvalidRoomSnapshot(pool: Pool, reason: string): Promise<void> {
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      `INSERT INTO room_state_quarantine (snapshot, reason)
       SELECT snapshot, $1 FROM room_state WHERE id = 1`,
      [reason],
    );
    await client.query("DELETE FROM room_state WHERE id = 1");
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }
}

export async function saveRoomSnapshot(pool: Pool, snapshot: RoomServiceSnapshot): Promise<void> {
  await pool.query(
    `INSERT INTO room_state (id, snapshot, updated_at)
     VALUES (1, $1::jsonb, NOW())
     ON CONFLICT (id) DO UPDATE SET snapshot = EXCLUDED.snapshot, updated_at = NOW()`,
    [JSON.stringify(snapshot)],
  );
}

/**
 * Keeps at most one unsaved snapshot. A burst of game actions therefore
 * coalesces to the newest state instead of building an unbounded Promise queue.
 * A transient database failure leaves the snapshot dirty and retries it.
 */
export class RoomSnapshotWriter {
  private pending: RoomServiceSnapshot | undefined;
  private running: Promise<void> | undefined;
  private retryTimer: NodeJS.Timeout | undefined;
  private stopped = false;

  constructor(
    private readonly pool: Pool,
    private readonly onError: (error: unknown) => void,
    private readonly retryMs = 1_000,
  ) {}

  enqueue(snapshot: RoomServiceSnapshot): void {
    this.pending = snapshot;
    if (!this.stopped) this.start();
  }

  private start(): void {
    if (this.running || !this.pending || this.stopped) return;
    const operation = this.drain();
    this.running = operation;
    void operation
      .catch(this.onError)
      .finally(() => {
        if (this.running === operation) this.running = undefined;
        if (this.pending && !this.stopped && !this.retryTimer) {
          this.retryTimer = setTimeout(() => {
            this.retryTimer = undefined;
            this.start();
          }, this.retryMs);
          this.retryTimer.unref();
        }
      });
  }

  private async drain(): Promise<void> {
    while (this.pending) {
      const snapshot = this.pending;
      this.pending = undefined;
      try {
        await saveRoomSnapshot(this.pool, snapshot);
      } catch (error) {
        // Keep the newer state if another mutation arrived during the write.
        this.pending ??= snapshot;
        throw error;
      }
    }
  }

  async flush(snapshot?: RoomServiceSnapshot): Promise<void> {
    if (snapshot) this.pending = snapshot;
    this.stopped = true;
    if (this.retryTimer) clearTimeout(this.retryTimer);
    this.retryTimer = undefined;
    if (this.running) {
      try {
        await this.running;
      } catch {
        // Retry the retained dirty snapshot once synchronously below.
      }
    }
    await this.drain();
  }
}
