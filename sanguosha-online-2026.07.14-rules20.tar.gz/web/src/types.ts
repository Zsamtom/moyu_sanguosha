import {
  cardPresentation,
  formatCardRank,
  type CardCategory,
  type CardTargetMode,
  type StandardCardKind,
} from './gameCards';

export type UserRole = 'admin' | 'player';

export interface AuthUser {
  id: string;
  username: string;
  displayName: string;
  role: UserRole;
  disabled: boolean;
  mustChangePassword: boolean;
  createdAt?: string;
  updatedAt?: string;
}

export type RoomStatus = 'waiting' | 'playing' | 'finished';

export interface RoomSummary {
  id: string;
  name: string;
  status: RoomStatus;
  hostId: string;
  hostName: string;
  playerCount: number;
  maxPlayers: number;
  createdAt?: string;
}

export interface RoomMember {
  userId: string;
  username: string;
  displayName: string;
  seat: number;
  ready: boolean;
  online: boolean;
  isHost: boolean;
  isBot?: boolean;
}

export interface RoomDetail extends RoomSummary {
  members: RoomMember[];
}

export type CardSuit = 'spade' | 'heart' | 'club' | 'diamond' | 'none';

export interface GameCard {
  id: string;
  name: string;
  kind?: StandardCardKind | string;
  suit: CardSuit;
  rank: string;
  description?: string;
  category?: CardCategory | string;
  targetMode?: CardTargetMode;
  playable?: boolean;
  allowedTargetIds?: string[];
  allowedTargetPairs?: Array<readonly [string, string]>;
}

export interface EquipmentView extends GameCard {
  slot: string;
}

export type ActiveGeneralSkillId =
  | 'wusheng'
  | 'longdan'
  | 'qixi'
  | 'kurou'
  | 'zhiheng'
  | 'rende'
  | 'qingnang'
  | 'jieyin'
  | 'guose'
  | 'qingguo'
  | 'jijiu';
export type SkillChoiceId = 'luoyi' | 'keji';

export interface PlayableSkillHint {
  skillId: ActiveGeneralSkillId;
  cardIds: string[];
  minCards: number;
  maxCards: number;
  targetMode: CardTargetMode;
  targetIds: string[];
  cardTargetIds?: Record<string, string[]>;
  virtualCardKind?: 'slash' | 'guo_he_chai_qiao' | 'le_bu_si_shu';
}

export interface SkillResponseHint {
  skillId: Extract<ActiveGeneralSkillId, 'wusheng' | 'longdan' | 'qingguo' | 'jijiu'>;
  cardIds: string[];
  responseKind: 'slash' | 'dodge' | 'peach';
}

export interface GamePlayerView {
  id: string;
  userId?: string;
  displayName: string;
  seat: number;
  general?: string;
  faction?: string;
  gender?: 'male' | 'female';
  identity?: string;
  hp: number;
  maxHp: number;
  handCount: number;
  alive: boolean;
  online: boolean;
  isSelf: boolean;
  isCurrent: boolean;
  equipment?: EquipmentView[];
  judgment?: EquipmentView[];
  chained?: boolean;
}

export interface GameLogEntry {
  id: string;
  at?: string;
  text: string;
  tone?: 'normal' | 'important' | 'damage' | 'heal';
}

export type PromptKind =
  | 'respond-slash'
  | 'respond-dodge'
  | 'respond-peach'
  | 'discard'
  | 'choose-card'
  | 'choose-target'
  | 'confirm'
  | string;

export interface ActionPrompt {
  id: string;
  kind: PromptKind;
  message: string;
  min?: number;
  max?: number;
  optional?: boolean;
  responseKind?: 'slash' | 'dodge' | 'nullification';
  allowedCardIds?: string[];
  allowedTargetIds?: string[];
  zoneChoices?: Array<{ token: string; zone: 'hand' | 'equipment' | 'judgment'; label: string }>;
  cardChoices?: GameCard[];
  weaponStage?: string;
  zhangBaAllowedCardIds?: string[];
  skillResponses?: SkillResponseHint[];
  skillId?: SkillChoiceId;
  requiredCount?: number;
  respondedCount?: number;
}

export interface GameView {
  roomId: string;
  status: 'playing' | 'finished';
  round: number;
  phase: string;
  turnPlayerId?: string;
  selfPlayerId: string;
  canAct: boolean;
  players: GamePlayerView[];
  hand: GameCard[];
  publicCards?: GameCard[];
  zhangBaSlash?: { allowedCardIds: string[]; targetIds: string[] } | null;
  skills: PlayableSkillHint[];
  logs: GameLogEntry[];
  prompt?: ActionPrompt | null;
  availableActions?: string[];
  winner?: string;
}

export type GameAction =
  | { type: 'play_card'; playerId: string; cardId: string; targetId?: string; targetIds?: string[] }
  | { type: 'respond'; playerId: string; cardId?: string | null; cardIds?: string[] }
  | { type: 'use_zhang_ba_slash'; playerId: string; cardIds: string[]; targetId: string }
  | { type: 'discard'; playerId: string; cardIds: string[] }
  | { type: 'end_play'; playerId: string }
  | { type: 'activate_armor'; playerId: string; activate: boolean }
  | { type: 'choose_zone_card'; playerId: string; token: string }
  | { type: 'choose_hand_card'; playerId: string; cardId?: string | null }
  | { type: 'choose_amazing_grace_card'; playerId: string; cardId: string }
  | {
      type: 'use_skill';
      playerId: string;
      skillId: ActiveGeneralSkillId;
      cardIds?: string[];
      targetId?: string;
      targetIds?: string[];
    }
  | { type: 'resolve_skill'; playerId: string; skillId: SkillChoiceId; activate: boolean }
  | { type: 'resolve_weapon'; playerId: string; activate: boolean; cardIds?: string[]; tokens?: string[] };

export interface ApiErrorBody {
  code?: string;
  message?: string;
}

export interface SocketAck<T = unknown> {
  ok: boolean;
  data?: T;
  error?: ApiErrorBody;
}

export interface ServerState {
  rooms?: RoomSummary[];
  room?: RoomDetail | null;
  game?: GameView | null;
}

type EngineCardKind = StandardCardKind;

interface EngineCard {
  id: string;
  kind: EngineCardKind;
  name?: string;
  suit?: Exclude<CardSuit, 'none'>;
  rank?: number | string;
  category?: CardCategory;
}

interface EnginePlayer {
  id: string;
  seat: number;
  alive: boolean;
  hp: number;
  maxHp: number;
  handCount: number;
  hand: EngineCard[] | null;
  equipment?: EngineCard[];
  judgment?: EngineCard[];
  chained?: boolean;
  role: 'lord' | 'loyalist' | 'rebel' | 'renegade' | null;
  general?: { id: string; name: string; faction: 'wei' | 'shu' | 'wu' | 'qun' | 'god'; gender: 'male' | 'female' } | null;
}

interface EnginePlayableCardHint {
  cardId: string;
  kind: EngineCardKind;
  targetIds: string[];
  targetMode?: CardTargetMode;
  targetPairs?: Array<readonly [string, string]>;
}

interface EnginePlayableSkillHint {
  skillId: ActiveGeneralSkillId;
  cardIds: string[];
  minCards: number;
  maxCards: number;
  targetMode: CardTargetMode;
  targetIds: string[];
  cardTargetIds?: Readonly<Record<string, string[]>>;
  virtualCardKind?: 'slash' | 'guo_he_chai_qiao' | 'le_bu_si_shu';
}

interface EngineSkillResponseHint {
  skillId: Extract<ActiveGeneralSkillId, 'wusheng' | 'longdan' | 'qingguo' | 'jijiu'>;
  cardIds: string[];
  responseKind: 'slash' | 'dodge' | 'peach';
}

type EngineResponseContext = 'slash' | 'duel' | 'barbarian_invasion' | 'arrow_barrage' | 'borrowed_sword';

type EnginePrompt =
  | {
      type: 'play';
      playerId: string;
      cards: EnginePlayableCardHint[];
      skills?: EnginePlayableSkillHint[];
      zhangBaSlash?: { allowedCardIds: string[]; targetIds: string[] } | null;
    }
  | {
      type: 'armor'; playerId: string; armorKind: 'ba_gua_zhen';
      requiredCount?: number; respondedCount?: number; canPass: true;
    }
  | {
      type: 'nullification'; playerId: string; sourceId: string; effectTargetId: string;
      cardKind: EngineCardKind; allowedCardIds: string[]; canPass: true;
    }
  | {
      type: 'zone_selection'; playerId: string; victimId: string; mode: 'discard' | 'gain';
      choices: Array<{ token: string; zone: 'hand' | 'equipment' | 'judgment'; card: EngineCard | null }>;
    }
  | { type: 'fire_attack_reveal'; playerId: string; sourceId: string; allowedCardIds: string[] }
  | {
      type: 'fire_attack_discard'; playerId: string; victimId: string;
      revealedCard: EngineCard; allowedCardIds: string[]; canPass: true;
    }
  | { type: 'amazing_grace_selection'; playerId: string; cards: EngineCard[] }
  | {
      type: 'weapon_action'; playerId: string; weaponKind: EngineCardKind; stage: string; victimId: string;
      allowedCardIds: string[]; minCards: number; maxCards: number; canPass: boolean;
      choices?: Array<{ token: string; zone: 'hand' | 'equipment'; card: EngineCard | null }>;
    }
  | {
      type: 'respond';
      playerId: string;
      attackerId?: string;
      targetId?: string;
      responseKind?: 'slash' | 'dodge';
      allowedCardIds?: string[];
      dodgeCardIds?: string[];
      slashCardIds?: string[];
      zhangBaCardIds?: string[];
      skillResponses?: EngineSkillResponseHint[];
      requiredCount?: number;
      respondedCount?: number;
      canPass: true;
      context?: EngineResponseContext;
    }
  | {
      type: 'dying';
      playerId: string;
      victimId: string;
      allowedCardIds: string[];
      peachCardIds: string[];
      wineCardIds: string[];
      skillResponses?: EngineSkillResponseHint[];
      canPass: true;
    }
  | { type: 'skill_choice'; playerId: string; skillId: SkillChoiceId; canPass: true }
  | { type: 'discard'; playerId: string; count: number; cardIds: string[] }
  | { type: 'waiting' }
  | { type: 'finished'; winner: { side: 'lord' | 'rebel' | 'renegade'; playerIds: string[] } };

interface EngineGameView {
  version: 1;
  status: 'playing' | 'finished';
  players: EnginePlayer[];
  currentPlayerId: string;
  turn: { number: number; playerId: string; phase: 'prepare' | 'judgment' | 'draw' | 'play' | 'respond' | 'discard' | 'end' };
  winner: { side: 'lord' | 'rebel' | 'renegade'; playerIds: string[] } | null;
  logs: { id: number; type: 'system' | 'turn' | 'card' | 'damage' | 'death' | 'victory'; message: string }[];
  publicCards?: EngineCard[];
  prompt: EnginePrompt;
}

const roleNames = { lord: '主公', loyalist: '忠臣', rebel: '反贼', renegade: '内奸' } as const;
const winnerNames = { lord: '主公与忠臣', rebel: '反贼', renegade: '内奸' } as const;
const factionNames = { wei: '魏', shu: '蜀', wu: '吴', qun: '群', god: '神' } as const;

function isEngineGameView(value: unknown): value is EngineGameView {
  return Boolean(value && typeof value === 'object' && (value as { version?: unknown }).version === 1 && 'turn' in value);
}

function responsePromptMessage(prompt: Extract<EnginePrompt, { type: 'respond' }>): string {
  const responseName = prompt.responseKind === 'slash' ? '杀' : '闪';
  const sourceNames: Record<EngineResponseContext, string> = {
    slash: '杀',
    duel: '决斗',
    barbarian_invasion: '南蛮入侵',
    arrow_barrage: '万箭齐发',
    borrowed_sword: '借刀杀人',
  };
  const sourceName = prompt.context ? sourceNames[prompt.context] : undefined;
  const requiredCount = prompt.requiredCount ?? 1;
  const respondedCount = prompt.respondedCount ?? 0;
  const progress = requiredCount > 1 ? `第 ${respondedCount + 1}/${requiredCount} 张` : '一张';
  if (sourceName) return `「${sourceName}」正在结算，请打出${progress}「${responseName}」或选择跳过。`;
  return `需要你打出一张「${responseName}」，也可以选择跳过。`;
}

export function normalizeGameView(
  payload: unknown,
  options: { roomId?: string; room?: RoomDetail | null; userId: string },
): GameView {
  const container = payload as { roomId?: string; view?: unknown; game?: unknown };
  const raw = container?.view ?? container?.game ?? payload;
  if (!isEngineGameView(raw)) return raw as GameView;

  const roomId = container?.roomId ?? options.roomId ?? options.room?.id ?? '';
  const prompt = raw.prompt;
  const selfId = prompt && 'playerId' in prompt && prompt.playerId === options.userId
    ? prompt.playerId
    : raw.players.some((player) => player.id === options.userId)
      ? options.userId
      : raw.players.find((player) => player.hand !== null)?.id ?? options.userId;
  const memberFor = (player: EnginePlayer) =>
    options.room?.members.find((member) => member.userId === player.id || member.seat === player.seat);
  const playableCards = prompt.type === 'play' ? new Map(prompt.cards.map((card) => [card.cardId, card])) : new Map();
  const playableSkills: PlayableSkillHint[] = prompt.type === 'play'
    ? (prompt.skills ?? []).map((skill) => ({
        ...skill,
        cardIds: [...skill.cardIds],
        targetIds: [...skill.targetIds],
        cardTargetIds: skill.cardTargetIds
          ? Object.fromEntries(Object.entries(skill.cardTargetIds).map(([cardId, targetIds]) => [cardId, [...targetIds]]))
          : undefined,
      }))
    : [];
  const responseCardIds = prompt.type === 'dying'
    ? prompt.allowedCardIds
    : prompt.type === 'nullification'
      ? prompt.allowedCardIds
    : prompt.type === 'respond'
      ? prompt.allowedCardIds
        ?? (prompt.responseKind === 'slash' ? prompt.slashCardIds : prompt.dodgeCardIds)
        ?? []
      : prompt.type === 'fire_attack_reveal' || prompt.type === 'fire_attack_discard' || prompt.type === 'weapon_action'
        ? prompt.allowedCardIds
      : [];
  const selfRaw = raw.players.find((player) => player.id === selfId || player.hand !== null);
  const displayNameById = new Map(raw.players.map((player) => {
    const member = memberFor(player);
    return [player.id, member?.displayName ?? `玩家 ${player.seat + 1}`] as const;
  }));
  const readableLog = (message: string) => {
    let result = message;
    for (const [playerId, displayName] of displayNameById) {
      result = result.replaceAll(playerId, displayName);
    }
    return result;
  };

  const mapCard = (card: EngineCard): GameCard => {
    const hint = playableCards.get(card.id);
    const presentation = cardPresentation(card.kind);
    return {
      id: card.id,
      kind: card.kind,
      name: card.name ?? presentation?.name ?? card.kind,
      suit: card.suit ?? 'none',
      rank: formatCardRank(card.rank),
      category: card.category ?? presentation?.category ?? 'basic',
      description: presentation?.description,
      targetMode: hint?.targetMode ?? presentation?.targetMode,
      playable:
        prompt.type === 'play'
          ? playableCards.has(card.id)
          : prompt.type === 'respond' || prompt.type === 'dying' || prompt.type === 'nullification' || prompt.type === 'fire_attack_reveal' || prompt.type === 'fire_attack_discard' || prompt.type === 'weapon_action'
            ? responseCardIds.includes(card.id)
            : prompt.type === 'discard'
              ? prompt.cardIds.includes(card.id)
              : false,
      allowedTargetIds: hint?.targetIds,
      allowedTargetPairs: hint?.targetPairs,
    };
  };

  let normalizedPrompt: ActionPrompt | null = null;
  if (prompt.type === 'skill_choice' && prompt.playerId === selfId) {
    const skillCopy: Record<SkillChoiceId, { name: string; message: string }> = {
      luoyi: {
        name: '裸衣',
        message: '是否发动「裸衣」？少摸一张牌，本回合使用「杀」或「决斗」造成的伤害 +1。',
      },
      keji: {
        name: '克己',
        message: '本回合未使用或打出过「杀」，是否发动「克己」跳过弃牌阶段？',
      },
    };
    normalizedPrompt = {
      id: `skill-choice-${raw.turn.number}-${prompt.skillId}-${prompt.playerId}`,
      kind: 'skill-choice',
      message: skillCopy[prompt.skillId].message,
      optional: prompt.canPass,
      skillId: prompt.skillId,
    };
  } else if (prompt.type === 'armor' && prompt.playerId === selfId) {
    const requiredCount = prompt.requiredCount ?? 1;
    const respondedCount = prompt.respondedCount ?? 0;
    const progress = requiredCount > 1 ? `（第 ${respondedCount + 1}/${requiredCount} 张闪）` : '';
    normalizedPrompt = {
      id: `armor-${raw.turn.number}-${prompt.playerId}-${respondedCount}-of-${requiredCount}`,
      kind: 'activate-armor',
      message: `是否发动「八卦阵」进行判定${progress}？红色判定牌视为打出一张「闪」。`,
      optional: prompt.canPass,
      requiredCount,
      respondedCount,
    };
  } else if (prompt.type === 'nullification' && prompt.playerId === selfId) {
    const targetName = displayNameById.get(prompt.effectTargetId) ?? '当前目标';
    normalizedPrompt = {
      id: `nullification-${raw.turn.number}-${prompt.cardKind}-${prompt.playerId}`,
      kind: 'respond-nullification',
      message: `是否对影响 ${targetName} 的「${cardPresentation(prompt.cardKind)?.name ?? prompt.cardKind}」使用「无懈可击」？`,
      optional: true,
      min: 0,
      max: 1,
      responseKind: 'nullification',
      allowedCardIds: responseCardIds,
    };
  } else if (prompt.type === 'respond' && prompt.playerId === selfId) {
    const responseKind = prompt.responseKind ?? 'dodge';
    const contextId = prompt.context ?? prompt.attackerId ?? 'card';
    const requiredCount = prompt.requiredCount ?? 1;
    const respondedCount = prompt.respondedCount ?? 0;
    normalizedPrompt = {
      id: `respond-${raw.turn.number}-${contextId}-${prompt.playerId}-${respondedCount}-of-${requiredCount}`,
      kind: responseKind === 'slash' ? 'respond-slash' : 'respond-dodge',
      message: responsePromptMessage(prompt),
      optional: true,
      min: 0,
      max: 1,
      responseKind,
      allowedCardIds: responseCardIds,
      zhangBaAllowedCardIds: prompt.zhangBaCardIds,
      requiredCount,
      respondedCount,
      skillResponses: (prompt.skillResponses ?? []).map((skill) => ({
        ...skill,
        cardIds: [...skill.cardIds],
      })),
    };
  } else if (prompt.type === 'dying' && prompt.playerId === selfId) {
    const victimName = displayNameById.get(prompt.victimId) ?? '濒死角色';
    normalizedPrompt = {
      id: `dying-${raw.turn.number}-${prompt.victimId}-${prompt.playerId}`,
      kind: 'respond-peach',
      message: prompt.playerId === prompt.victimId
        ? '你正处于濒死状态，请使用「桃」或「酒」自救，也可以放弃。'
        : `${victimName} 正处于濒死状态，请使用一张「桃」救援，也可以放弃。`,
      optional: true,
      min: 0,
      max: 1,
      allowedCardIds: responseCardIds,
      skillResponses: (prompt.skillResponses ?? []).map((skill) => ({
        ...skill,
        cardIds: [...skill.cardIds],
      })),
    };
  } else if (prompt.type === 'zone_selection' && prompt.playerId === selfId) {
    const victimName = displayNameById.get(prompt.victimId) ?? '目标角色';
    normalizedPrompt = {
      id: `zone-selection-${raw.turn.number}-${prompt.victimId}-${prompt.mode}`,
      kind: 'choose-zone-card',
      message: `请选择${victimName}区域内的一张牌${prompt.mode === 'gain' ? '获得' : '弃置'}。手牌为匿名暗牌。`,
      zoneChoices: prompt.choices.map((choice, index) => ({
        token: choice.token,
        zone: choice.zone,
        label: choice.card
          ? `${choice.zone === 'equipment' ? '装备区' : '判定区'} · ${choice.card.name ?? cardPresentation(choice.card.kind)?.name ?? choice.card.kind}`
          : `手牌 ${index + 1}（暗牌）`,
      })),
    };
  } else if (prompt.type === 'fire_attack_reveal' && prompt.playerId === selfId) {
    normalizedPrompt = {
      id: `fire-attack-reveal-${raw.turn.number}-${prompt.playerId}`,
      kind: 'fire-attack-reveal',
      message: '火攻生效：请选择并展示一张手牌。',
      min: 1,
      max: 1,
      allowedCardIds: prompt.allowedCardIds,
    };
  } else if (prompt.type === 'fire_attack_discard' && prompt.playerId === selfId) {
    normalizedPrompt = {
      id: `fire-attack-discard-${raw.turn.number}-${prompt.playerId}-${prompt.revealedCard.id}`,
      kind: 'fire-attack-discard',
      message: `目标展示了${prompt.revealedCard.name ?? cardPresentation(prompt.revealedCard.kind)?.name ?? prompt.revealedCard.kind}，可弃置一张同花色手牌造成 1 点火焰伤害，或放弃。`,
      min: 0,
      max: 1,
      optional: prompt.canPass,
      allowedCardIds: prompt.allowedCardIds,
    };
  } else if (prompt.type === 'amazing_grace_selection' && prompt.playerId === selfId) {
    normalizedPrompt = {
      id: `amazing-grace-${raw.turn.number}-${prompt.playerId}-${prompt.cards.map((card) => card.id).join('-')}`,
      kind: 'amazing-grace-selection',
      message: '五谷丰登生效：请选择一张亮出的牌获得。',
      min: 1,
      max: 1,
      cardChoices: prompt.cards.map(mapCard),
    };
  } else if (prompt.type === 'weapon_action' && prompt.playerId === selfId) {
    const victimName = displayNameById.get(prompt.victimId) ?? '目标角色';
    const weaponName = cardPresentation(prompt.weaponKind)?.name ?? prompt.weaponKind;
    const messages: Record<string, string> = {
      zhuque_convert: `是否发动「${weaponName}」，将此普通杀改为火杀？`,
      cixiong_activate: `是否对 ${victimName} 发动「${weaponName}」？`,
      cixiong_choice: `请选择弃置一张手牌；若不弃置，攻击者摸一张牌。`,
      guanshi_force_hit: `可弃置两张牌发动「${weaponName}」，令被闪抵消的杀强制命中。`,
      qinglong_followup: `可选择另一张杀发动「${weaponName}」，继续攻击 ${victimName}。`,
      hanbing_prevent: `是否发动「${weaponName}」，防止伤害并改为弃置 ${victimName} 至多两张牌？`,
      hanbing_select: prompt.canPass
        ? `可继续选择 ${victimName} 的一张手牌或装备弃置，也可结束选择。`
        : `请选择 ${victimName} 的一张手牌或装备弃置；发动后至少弃置一张。`,
      qilin_discard_horse: `是否发动「${weaponName}」，弃置 ${victimName} 的一匹坐骑？`,
    };
    normalizedPrompt = {
      id: `weapon-${raw.turn.number}-${prompt.stage}-${prompt.playerId}-${prompt.victimId}`,
      kind: 'weapon-action',
      weaponStage: prompt.stage,
      message: messages[prompt.stage] ?? `是否发动「${weaponName}」？`,
      min: prompt.minCards,
      max: prompt.maxCards,
      optional: prompt.canPass,
      allowedCardIds: prompt.allowedCardIds,
      zoneChoices: prompt.choices?.map((choice, index) => ({
        token: choice.token,
        zone: choice.zone,
        label: choice.card
          ? `${choice.zone === 'equipment' ? '装备区' : '手牌'} · ${choice.card.name ?? cardPresentation(choice.card.kind)?.name ?? choice.card.kind}`
          : `手牌 ${index + 1}（暗牌）`,
      })),
    };
  } else if (prompt.type === 'discard' && prompt.playerId === selfId) {
    normalizedPrompt = {
      id: `discard-${raw.turn.number}-${prompt.playerId}`,
      kind: 'discard',
      message: `请弃置 ${prompt.count} 张手牌。`,
      min: prompt.count,
      max: prompt.count,
      allowedCardIds: prompt.cardIds,
    };
  }

  return {
    roomId,
    status: raw.status,
    round: raw.turn.number,
    phase: raw.turn.phase,
    turnPlayerId: raw.currentPlayerId,
    selfPlayerId: selfId,
    canAct: prompt.type === 'play' && prompt.playerId === selfId,
    players: raw.players.map((player) => {
      const member = memberFor(player);
      return {
        id: player.id,
        userId: player.id,
        displayName: member?.displayName ?? `玩家 ${player.seat + 1}`,
        seat: player.seat,
        general: player.general?.name,
        faction: player.general ? factionNames[player.general.faction] : undefined,
        gender: player.general?.gender,
        identity: player.role ? roleNames[player.role] : undefined,
        hp: player.hp,
        maxHp: player.maxHp,
        handCount: player.handCount,
        alive: player.alive,
        online: member?.online ?? true,
        isSelf: player.id === selfId,
        isCurrent: player.id === raw.currentPlayerId,
        equipment: (player.equipment ?? []).map((card) => ({
          ...mapCard(card),
            slot: ['zhu_ge_lian_nu', 'gu_ding_dao', 'qing_gang_jian', 'ci_xiong_shuang_gu_jian', 'han_bing_jian', 'qing_long_yan_yue_dao', 'zhang_ba_she_mao', 'guan_shi_fu', 'fang_tian_hua_ji', 'zhu_que_yu_shan', 'qi_lin_gong'].includes(card.kind)
              ? '武器'
              : ['ren_wang_dun', 'teng_jia', 'bai_yin_shi_zi', 'ba_gua_zhen'].includes(card.kind)
              ? '防具'
              : ['chi_tu', 'da_wan', 'zi_xing'].includes(card.kind) ? '进攻坐骑' : '防御坐骑',
        })),
        judgment: (player.judgment ?? []).map((card) => ({
          ...mapCard(card),
          slot: '判定区',
        })),
        chained: player.chained ?? false,
      };
    }),
    hand: (selfRaw?.hand ?? []).map(mapCard),
    zhangBaSlash: prompt.type === 'play' ? prompt.zhangBaSlash ?? null : null,
    skills: playableSkills,
    publicCards: (raw.publicCards ?? []).map(mapCard),
    logs: raw.logs.map((log) => ({
      id: String(log.id),
      text: readableLog(log.message),
      tone: log.type === 'damage' || log.type === 'death' ? 'damage' : log.type === 'victory' ? 'important' : 'normal',
    })),
    prompt: normalizedPrompt,
    winner: raw.winner ? winnerNames[raw.winner.side] : undefined,
  };
}

export function normalizeRoomSummary(room: Partial<RoomSummary> & Record<string, unknown>): RoomSummary {
  const members = Array.isArray(room.members) ? room.members : [];
  const host = members.find((member) => Boolean((member as Record<string, unknown>).isHost)) as
    | Record<string, unknown>
    | undefined;
  return {
    id: String(room.id ?? ''),
    name: String(room.name ?? '未命名房间'),
    status: (room.status as RoomStatus | undefined) ?? 'waiting',
    hostId: String(room.hostId ?? room.ownerId ?? host?.userId ?? ''),
    hostName: String(room.hostName ?? room.ownerName ?? host?.displayName ?? ''),
    playerCount: Number(room.playerCount ?? members.length ?? 0),
    maxPlayers: Number(room.maxPlayers ?? 8),
    createdAt: typeof room.createdAt === 'string' ? room.createdAt : undefined,
  };
}

export function normalizeRoomDetail(room: Partial<RoomDetail> & Record<string, unknown>): RoomDetail {
  const summary = normalizeRoomSummary(room);
  const rawMembers = Array.isArray(room.members)
    ? room.members
    : Array.isArray(room.players)
      ? room.players
      : [];
  const members = rawMembers.map((raw, index) => {
    const member = raw as Record<string, unknown>;
    return {
      userId: String(member.userId ?? member.id ?? ''),
      username: String(member.username ?? ''),
      displayName: String(member.displayName ?? member.name ?? member.username ?? `玩家${index + 1}`),
      seat: Number(member.seat ?? index),
      ready: Boolean(member.ready),
      online: (member.online ?? member.connected) !== false,
      isHost: Boolean(member.isHost ?? String(member.userId ?? member.id ?? '') === summary.hostId),
      isBot: Boolean(member.isBot),
    };
  });
  return { ...summary, members, playerCount: members.length };
}
