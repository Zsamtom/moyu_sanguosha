import type { Faction, Gender, GeneralId, GeneralSkillId } from "./types.js";

export interface GeneralDefinition {
  readonly id: GeneralId;
  readonly name: string;
  readonly faction: Faction;
  readonly gender: Gender;
  readonly maxHp: number;
  readonly pack: "standard" | "sp" | "fire";
  readonly skillIds: readonly GeneralSkillId[];
}

export const STANDARD_GENERALS = [
  { id: "guan_yu", name: "关羽", faction: "shu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["wusheng"] },
  { id: "huang_yue_ying", name: "黄月英", faction: "shu", gender: "female", maxHp: 3, pack: "standard", skillIds: ["jizhi", "qicai"] },
  { id: "liu_bei", name: "刘备", faction: "shu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["rende", "jijiang"] },
  { id: "ma_chao", name: "马超", faction: "shu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["mashu", "tieqi"] },
  { id: "zhang_fei", name: "张飞", faction: "shu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["paoxiao"] },
  { id: "zhao_yun", name: "赵云", faction: "shu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["longdan"] },
  { id: "zhu_ge_liang", name: "诸葛亮", faction: "shu", gender: "male", maxHp: 3, pack: "standard", skillIds: ["guanxing", "kongcheng"] },

  { id: "cao_cao", name: "曹操", faction: "wei", gender: "male", maxHp: 4, pack: "standard", skillIds: ["jianxiong", "hujia"] },
  { id: "guo_jia", name: "郭嘉", faction: "wei", gender: "male", maxHp: 3, pack: "standard", skillIds: ["tiandu", "yiji"] },
  { id: "si_ma_yi", name: "司马懿", faction: "wei", gender: "male", maxHp: 3, pack: "standard", skillIds: ["guicai", "fankui"] },
  { id: "xia_hou_dun", name: "夏侯惇", faction: "wei", gender: "male", maxHp: 4, pack: "standard", skillIds: ["ganglie"] },
  { id: "xu_chu", name: "许褚", faction: "wei", gender: "male", maxHp: 4, pack: "standard", skillIds: ["luoyi"] },
  { id: "zhang_liao", name: "张辽", faction: "wei", gender: "male", maxHp: 4, pack: "standard", skillIds: ["tuxi"] },
  { id: "zhen_ji", name: "甄姬", faction: "wei", gender: "female", maxHp: 3, pack: "standard", skillIds: ["luoshen", "qingguo"] },

  { id: "da_qiao", name: "大乔", faction: "wu", gender: "female", maxHp: 3, pack: "standard", skillIds: ["guose", "liuli"] },
  { id: "gan_ning", name: "甘宁", faction: "wu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["qixi"] },
  { id: "huang_gai", name: "黄盖", faction: "wu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["kurou"] },
  { id: "lu_xun", name: "陆逊", faction: "wu", gender: "male", maxHp: 3, pack: "standard", skillIds: ["qianxun", "lianying"] },
  { id: "lv_meng", name: "吕蒙", faction: "wu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["keji"] },
  { id: "sun_quan", name: "孙权", faction: "wu", gender: "male", maxHp: 4, pack: "standard", skillIds: ["zhiheng", "jiuyuan"] },
  { id: "sun_shang_xiang", name: "孙尚香", faction: "wu", gender: "female", maxHp: 3, pack: "standard", skillIds: ["xiaoji", "jieyin"] },
  { id: "zhou_yu", name: "周瑜", faction: "wu", gender: "male", maxHp: 3, pack: "standard", skillIds: ["yingzi", "fanjian"] },

  { id: "hua_tuo", name: "华佗", faction: "qun", gender: "male", maxHp: 3, pack: "standard", skillIds: ["jijiu", "qingnang"] },
  { id: "lv_bu", name: "吕布", faction: "qun", gender: "male", maxHp: 4, pack: "standard", skillIds: ["wushuang"] },
  { id: "diao_chan", name: "貂蝉", faction: "qun", gender: "female", maxHp: 3, pack: "standard", skillIds: ["biyue", "lijian"] },
] as const satisfies readonly GeneralDefinition[];

export const SP_GENERALS = [
  { id: "yuan_shu", name: "袁术", faction: "qun", gender: "male", maxHp: 4, pack: "sp", skillIds: ["yongsi", "weidi"] },
] as const satisfies readonly GeneralDefinition[];

/** Retained for rolling-snapshot compatibility; fire-pack generals are not dealt in standard games. */
export const EXTENSION_GENERALS = [
  { id: "xun_yu", name: "荀彧", faction: "wei", gender: "male", maxHp: 3, pack: "fire", skillIds: ["quhu", "jieming"] },
] as const satisfies readonly GeneralDefinition[];

/** Default MVP pool: the 25 standard generals plus the original project's SP Yuan Shu. */
export const DEFAULT_GENERALS: readonly GeneralDefinition[] = [...STANDARD_GENERALS, ...SP_GENERALS];
export const ALL_GENERALS: readonly GeneralDefinition[] = [...DEFAULT_GENERALS, ...EXTENSION_GENERALS];

export function getGeneralDefinition(id: GeneralId): GeneralDefinition {
  const general = ALL_GENERALS.find((candidate) => candidate.id === id);
  if (!general) throw new Error(`未知武将：${id}`);
  return general;
}

export function hasGeneralSkill(id: GeneralId | null, skillId: GeneralSkillId): boolean {
  return id ? getGeneralDefinition(id).skillIds.includes(skillId) : false;
}
