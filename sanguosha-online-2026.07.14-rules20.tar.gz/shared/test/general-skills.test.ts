import { describe, expect, it } from "vitest";

import {
  GameRuleError,
  DEFAULT_GENERALS,
  STANDARD_GENERALS,
  applyAction,
  createGame,
  distanceBetweenPlayers,
  getCardDefinition,
  getGameView,
  getGeneralDefinition,
  type Card,
  type CardKind,
  type GamePlayer,
  type GameSession,
} from "../src/index.js";

const seed = "51".padStart(64, "0");

function makeCard(id: string, kind: CardKind, suit: Card["suit"] = "spade"): Card {
  return { id, kind, ...getCardDefinition(kind), suit, rank: 1 };
}

function setup(playerCount = 5): { session: GameSession; actor: GamePlayer; targets: GamePlayer[] } {
  const session = createGame({
    playerIds: Array.from({ length: playerCount }, (_, index) => `p${index + 1}`),
    seed,
  });
  const actor = session.players.find((player) => player.id === session.currentPlayerId)!;
  const targets = session.players.filter((player) => player.id !== actor.id);
  for (const player of session.players) {
    player.hand = [];
    player.equipment = {};
    player.judgment = [];
    player.hp = 4;
    player.maxHp = 4;
  }
  session.deck = [];
  session.discardPile = [];
  session.resolvingCards = [];
  session.pendingResponse = null;
  session.turn.phase = "play";
  session.turn.slashUsed = false;
  return { session, actor, targets };
}

function ruleCode(action: () => unknown): string | undefined {
  try {
    action();
    return undefined;
  } catch (error) {
    if (!(error instanceof GameRuleError)) throw error;
    return error.code;
  }
}

describe("standard general roster", () => {
  it("deals the original standard roster while retaining Xun Yu as a fire-pack snapshot", () => {
    expect(STANDARD_GENERALS).toHaveLength(25);
    expect(DEFAULT_GENERALS).toHaveLength(26);
    expect(STANDARD_GENERALS.some((general) => general.id === "xu_chu")).toBe(true);
    expect(STANDARD_GENERALS.some((general) => general.id === "xun_yu")).toBe(false);
    expect(DEFAULT_GENERALS.find((general) => general.id === "yuan_shu")?.pack).toBe("sp");
    expect(getGeneralDefinition("xu_chu")).toMatchObject({ name: "许褚", pack: "standard", maxHp: 4 });
    expect(getGeneralDefinition("xun_yu")).toMatchObject({ name: "荀彧", pack: "fire", maxHp: 3 });
  });
});

describe("implemented locked standard skills", () => {
  it("applies Ma Chao's Mashu to seat distance", () => {
    const { session } = setup();
    const source = session.players[0]!;
    const target = session.players[2]!;
    source.generalId = "ma_chao";
    expect(distanceBetweenPlayers(session, source.id, target.id)).toBe(1);
    source.generalId = "zhao_yun";
    expect(distanceBetweenPlayers(session, source.id, target.id)).toBe(2);
  });

  it("lets Zhang Fei use more than one Slash in the same play phase", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "zhang_fei";
    actor.hand = [makeCard("slash-1", "slash"), makeCard("slash-2", "slash")];
    target!.hand = [];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "slash-1",
      targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });
    expect(() => applyAction(game, {
      type: "play_card",
      playerId: actor.id,
      cardId: "slash-2",
      targetId: target!.id,
    })).not.toThrow();
  });

  it("requires two sequential Dodges against Lu Bu's Slash and preserves progress", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_bu";
    actor.hand = [makeCard("wushuang-slash", "slash")];
    target!.hand = [makeCard("dodge-1", "dodge"), makeCard("dodge-2", "dodge")];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "wushuang-slash",
      targetId: target!.id,
    });
    expect(game.pendingResponse).toMatchObject({
      type: "slash", targetId: target!.id, requiredDodgeCount: 2, dodgesPlayed: 0,
    });
    expect(getGameView(game, target!.id).prompt).toMatchObject({
      type: "respond", responseKind: "dodge", requiredCount: 2, respondedCount: 0,
    });

    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "dodge-1" });
    expect(game.pendingResponse).toMatchObject({
      type: "slash", targetId: target!.id, requiredDodgeCount: 2, dodgesPlayed: 1,
    });
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(4);
    expect(getGameView(game, target!.id).prompt).toMatchObject({
      type: "respond", requiredCount: 2, respondedCount: 1, allowedCardIds: ["dodge-2"],
    });

    // A JSON round-trip models a restored authoritative snapshot between both responses.
    game = applyAction(JSON.parse(JSON.stringify(game)) as GameSession, {
      type: "respond", playerId: target!.id, cardId: "dodge-2",
    });
    expect(game.pendingResponse).toBeNull();
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(4);
    expect(game.discardPile.map((card) => card.id)).toEqual(expect.arrayContaining([
      "wushuang-slash", "dodge-1", "dodge-2",
    ]));
  });

  it("still consumes the first Dodge when the second Wushuang response is passed", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_bu";
    actor.hand = [makeCard("wushuang-slash", "slash")];
    target!.hand = [makeCard("only-dodge", "dodge")];

    let game = applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "wushuang-slash", targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "only-dodge" });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });

    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(3);
    expect(game.discardPile.map((card) => card.id)).toEqual(expect.arrayContaining([
      "wushuang-slash", "only-dodge",
    ]));
  });

  it("resets the two-Dodge counter for every Fang Tian Halberd target", () => {
    const { session, actor, targets } = setup(4);
    actor.generalId = "lv_bu";
    actor.equipment.weapon = makeCard("halberd", "fang_tian_hua_ji");
    actor.hand = [makeCard("multi-slash", "slash")];
    targets.forEach((target, index) => {
      target.hand = [makeCard(`multi-dodge-${index}-1`, "dodge"), makeCard(`multi-dodge-${index}-2`, "dodge")];
    });

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "multi-slash",
      targetIds: targets.map((target) => target.id),
    });
    for (const [index, target] of targets.entries()) {
      expect(game.pendingResponse).toMatchObject({
        type: "slash", targetId: target.id, requiredDodgeCount: 2, dodgesPlayed: 0,
      });
      game = applyAction(game, {
        type: "respond", playerId: target.id, cardId: `multi-dodge-${index}-1`,
      });
      expect(game.pendingResponse).toMatchObject({ targetId: target.id, dodgesPlayed: 1 });
      game = applyAction(game, {
        type: "respond", playerId: target.id, cardId: `multi-dodge-${index}-2`,
      });
    }
    expect(game.pendingResponse).toBeNull();
    expect(targets.map((target) => game.players.find((player) => player.id === target.id)?.hp)).toEqual([4, 4, 4]);
  });

  it("allows Ba Gua Zhen to satisfy each Wushuang Dodge request separately", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_bu";
    actor.hand = [makeCard("bagua-wushuang-slash", "slash")];
    target!.equipment.armor = makeCard("bagua", "ba_gua_zhen");
    target!.hand = [makeCard("second-dodge", "dodge")];
    session.deck = [makeCard("red-judgment", "peach", "heart")];

    let game = applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "bagua-wushuang-slash", targetId: target!.id,
    });
    expect(getGameView(game, target!.id).prompt).toMatchObject({
      type: "armor", requiredCount: 2, respondedCount: 0,
    });
    game = applyAction(game, { type: "activate_armor", playerId: target!.id, activate: true });
    expect(game.pendingResponse).toMatchObject({ dodgesPlayed: 1, armorAttempted: false });
    expect(getGameView(game, target!.id).prompt).toMatchObject({
      type: "armor", requiredCount: 2, respondedCount: 1,
    });
    game = applyAction(game, { type: "activate_armor", playerId: target!.id, activate: false });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "second-dodge" });
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(4);
  });

  it("requires two Slashes per Duel exchange only from the player facing Wushuang", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_bu";
    actor.hand = [makeCard("wushuang-duel", "duel")];
    target!.hand = [makeCard("answer-1", "slash"), makeCard("answer-2", "fire_slash", "heart")];

    let game = applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "wushuang-duel", targetId: target!.id,
    });
    expect(game.pendingResponse).toMatchObject({
      type: "duel", attackerId: actor.id, targetId: target!.id, requiredSlashCount: 2, slashesPlayed: 0,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "answer-1" });
    expect(game.pendingResponse).toMatchObject({
      type: "duel", attackerId: actor.id, targetId: target!.id, requiredSlashCount: 2, slashesPlayed: 1,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "answer-2" });
    expect(game.pendingResponse).toMatchObject({
      type: "duel", attackerId: target!.id, targetId: actor.id, requiredSlashCount: 1, slashesPlayed: 0,
    });
    game = applyAction(game, { type: "respond", playerId: actor.id, cardId: null });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
  });

  it("consumes the first Duel Slash before a player declines the second Wushuang response", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_bu";
    actor.hand = [makeCard("short-duel", "duel")];
    target!.hand = [makeCard("only-answer", "slash")];

    let game = applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "short-duel", targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "only-answer" });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });

    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(3);
    expect(game.discardPile.map((card) => card.id)).toEqual(expect.arrayContaining(["short-duel", "only-answer"]));
  });

  it("applies Wushuang symmetrically when Lu Bu is the target of Duel", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.hand = [makeCard("duel-lubu", "duel"), makeCard("reply-1", "slash"), makeCard("reply-2", "slash")];
    target!.generalId = "lv_bu";
    target!.hand = [makeCard("lubu-answer", "slash")];

    let game = applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "duel-lubu", targetId: target!.id,
    });
    expect(game.pendingResponse).toMatchObject({ requiredSlashCount: 1, targetId: target!.id });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "lubu-answer" });
    expect(game.pendingResponse).toMatchObject({
      type: "duel", attackerId: target!.id, targetId: actor.id, requiredSlashCount: 2, slashesPlayed: 0,
    });
    game = applyAction(game, { type: "respond", playerId: actor.id, cardId: "reply-1" });
    expect(game.pendingResponse).toMatchObject({ targetId: actor.id, slashesPlayed: 1 });
    game = applyAction(game, { type: "respond", playerId: actor.id, cardId: "reply-2" });
    expect(game.pendingResponse).toMatchObject({ targetId: target!.id, requiredSlashCount: 1, slashesPlayed: 0 });
  });

  it("lets Huang Yueying ignore trick-card distance", () => {
    const { session } = setup();
    const actor = session.players[0]!;
    const farTarget = session.players[2]!;
    session.currentPlayerId = actor.id;
    session.turn.playerId = actor.id;
    actor.generalId = "huang_yue_ying";
    actor.hand = [makeCard("snatch", "shun_shou_qian_yang")];
    farTarget.hand = [makeCard("loot", "dodge")];

    const prompt = getGameView(session, actor.id).prompt;
    expect(prompt).toMatchObject({ type: "play" });
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.cards.find((card) => card.cardId === "snatch")?.targetIds).toContain(farTarget.id);
    expect(() => applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "snatch",
      targetId: farTarget.id,
    })).not.toThrow();
  });

  it("enforces Lu Xun's Qianxun in validation and action hints", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.hand = [
      makeCard("snatch", "shun_shou_qian_yang"),
      makeCard("indulgence", "le_bu_si_shu"),
    ];
    target!.generalId = "lu_xun";
    target!.hand = [makeCard("loot", "dodge")];

    const prompt = getGameView(session, actor.id).prompt;
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.cards.find((card) => card.cardId === "snatch")?.targetIds ?? []).not.toContain(target!.id);
    expect(prompt.cards.find((card) => card.cardId === "indulgence")?.targetIds ?? []).not.toContain(target!.id);
    expect(ruleCode(() => applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "snatch", targetId: target!.id,
    }))).toBe("INVALID_TARGET");
    expect(ruleCode(() => applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "indulgence", targetId: target!.id,
    }))).toBe("INVALID_TARGET");
  });

  it("enforces Zhuge Liang's Kongcheng for Slash and Duel", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.hand = [makeCard("slash", "slash"), makeCard("duel", "duel")];
    target!.generalId = "zhu_ge_liang";
    target!.hand = [];

    const prompt = getGameView(session, actor.id).prompt;
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.cards.find((card) => card.cardId === "slash")?.targetIds).not.toContain(target!.id);
    expect(prompt.cards.find((card) => card.cardId === "duel")?.targetIds).not.toContain(target!.id);
    expect(ruleCode(() => applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "slash", targetId: target!.id,
    }))).toBe("INVALID_TARGET");
    expect(ruleCode(() => applyAction(session, {
      type: "play_card", playerId: actor.id, cardId: "duel", targetId: target!.id,
    }))).toBe("INVALID_TARGET");
  });
});

describe("active and conversion standard skills", () => {
  it("uses a red card as Slash through Wusheng and preserves its physical identity", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "guan_yu";
    actor.hand = [makeCard("wusheng-cost", "peach", "heart")];

    let game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "wusheng",
      cardIds: ["wusheng-cost"],
      targetId: target!.id,
    });
    expect(game.pendingResponse).toMatchObject({ type: "slash", targetId: target!.id });
    expect(game.resolvingCards.find((card) => card.id === "wusheng-cost")?.kind).toBe("peach");

    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });
    expect(game.discardPile.find((card) => card.id === "wusheng-cost")?.kind).toBe("peach");
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(3);
  });

  it("uses Wusheng to answer a Duel with a red equipped card", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.hand = [makeCard("duel", "duel")];
    target!.generalId = "guan_yu";
    target!.equipment.offensive_horse = makeCard("red-horse", "chi_tu", "diamond");

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "duel",
      targetId: target!.id,
    });
    game = applyAction(game, {
      type: "use_skill",
      playerId: target!.id,
      skillId: "wusheng",
      cardIds: ["red-horse"],
    });
    expect(game.pendingResponse).toMatchObject({ type: "duel", targetId: actor.id });
    expect(game.resolvingCards.find((card) => card.id === "red-horse")?.kind).toBe("chi_tu");
    expect(game.players.find((player) => player.id === target!.id)?.equipment.offensive_horse).toBeUndefined();
  });

  it("converts Dodge to Slash and Slash to Dodge through Longdan", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "zhao_yun";
    actor.hand = [makeCard("longdan-dodge", "dodge", "club")];

    let game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "longdan",
      cardIds: ["longdan-dodge"],
      targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });
    expect(game.discardPile.find((card) => card.id === "longdan-dodge")?.kind).toBe("dodge");
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(3);

    const defender = game.players.find((player) => player.id === target!.id)!;
    game.currentPlayerId = defender.id;
    game.turn = { ...game.turn, playerId: defender.id, phase: "play", slashUsed: false, slashDamageBonus: 0 };
    defender.hand = [makeCard("incoming-slash", "slash")];
    const zhaoYun = game.players.find((player) => player.id === actor.id)!;
    zhaoYun.hand = [makeCard("longdan-slash", "fire_slash", "heart")];
    game = applyAction(game, {
      type: "play_card",
      playerId: defender.id,
      cardId: "incoming-slash",
      targetId: zhaoYun.id,
    });
    game = applyAction(game, {
      type: "use_skill",
      playerId: zhaoYun.id,
      skillId: "longdan",
      cardIds: ["longdan-slash"],
    });
    expect(game.players.find((player) => player.id === zhaoYun.id)?.hp).toBe(4);
    expect(game.discardPile.find((card) => card.id === "longdan-slash")?.kind).toBe("fire_slash");
  });

  it("uses a black equipped card as Dismantlement through Qixi", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "gan_ning";
    actor.hp = 2;
    actor.equipment.armor = makeCard("qixi-armor", "bai_yin_shi_zi", "club");
    target!.hand = [makeCard("victim-card", "dodge")];

    let game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "qixi",
      cardIds: ["qixi-armor"],
      targetId: target!.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
    expect(game.pendingResponse).toMatchObject({ type: "zone_selection", victimId: target!.id });
    game = applyAction(game, { type: "choose_zone_card", playerId: actor.id, token: "hand:0" });
    expect(game.discardPile.find((card) => card.id === "qixi-armor")?.kind).toBe("bai_yin_shi_zi");
    expect(game.discardPile.some((card) => card.id === "victim-card")).toBe(true);
  });

  it("loses one HP and draws two cards through Kurou, including after rescue", () => {
    const { session, actor } = setup(3);
    actor.generalId = "huang_gai";
    actor.hp = 2;
    session.deck = [makeCard("kurou-draw-2", "dodge"), makeCard("kurou-draw-1", "slash")];

    let game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "kurou",
    });
    expect(game.players.find((player) => player.id === actor.id)).toMatchObject({ hp: 1, hand: [{ id: "kurou-draw-1" }, { id: "kurou-draw-2" }] });
    expect(game.turn.phase).toBe("play");

    const rescued = game.players.find((player) => player.id === actor.id)!;
    rescued.hp = 1;
    rescued.hand = [makeCard("self-peach", "peach", "heart")];
    game.deck = [makeCard("rescued-draw-2", "dodge"), makeCard("rescued-draw-1", "slash")];
    game = applyAction(game, { type: "use_skill", playerId: actor.id, skillId: "kurou" });
    expect(game.pendingResponse).toMatchObject({ type: "dying", victimId: actor.id, damageSourceId: null });
    game = applyAction(game, { type: "respond", playerId: actor.id, cardId: "self-peach" });
    expect(game.players.find((player) => player.id === actor.id)).toMatchObject({ hp: 1 });
    expect(game.players.find((player) => player.id === actor.id)?.hand.map((card) => card.id)).toEqual([
      "rescued-draw-1",
      "rescued-draw-2",
    ]);
    expect(game.turn.phase).toBe("play");
  });

  it("rejects skills the player does not own and invalid conversion costs", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "guan_yu";
    actor.hand = [makeCard("black-card", "dodge", "spade")];
    expect(ruleCode(() => applyAction(session, {
      type: "use_skill", playerId: actor.id, skillId: "qixi", cardIds: ["black-card"], targetId: target!.id,
    }))).toBe("INVALID_SKILL");
    expect(ruleCode(() => applyAction(session, {
      type: "use_skill", playerId: actor.id, skillId: "wusheng", cardIds: ["black-card"], targetId: target!.id,
    }))).toBe("INVALID_CARD");
  });
});

describe("optional phase skills", () => {
  it("offers Luoyi before drawing, draws one when activated, and adds one Slash damage", () => {
    const { session, actor } = setup(3);
    const actorIndex = session.players.findIndex((player) => player.id === actor.id);
    const xuChu = session.players[(actorIndex + 1) % session.players.length]!;
    const victim = session.players[(actorIndex + 2) % session.players.length]!;
    xuChu.generalId = "xu_chu";
    session.deck = [makeCard("luoyi-draw-2", "dodge"), makeCard("luoyi-draw-1", "slash")];

    const choice = applyAction(session, { type: "end_play", playerId: actor.id });
    expect(choice.pendingResponse).toMatchObject({
      type: "skill_choice",
      targetId: xuChu.id,
      skillId: "luoyi",
      resume: { type: "finish_draw", playerId: xuChu.id },
    });
    expect(choice.players.find((player) => player.id === xuChu.id)?.hand).toHaveLength(0);
    expect(getGameView(choice, xuChu.id).prompt).toEqual({
      type: "skill_choice",
      playerId: xuChu.id,
      skillId: "luoyi",
      canPass: true,
    });
    expect(getGameView(choice, victim.id).pendingResponse).toBeNull();

    let game = applyAction(JSON.parse(JSON.stringify(choice)) as GameSession, {
      type: "resolve_skill",
      playerId: xuChu.id,
      skillId: "luoyi",
      activate: true,
    });
    expect(game.turn).toMatchObject({ phase: "play", luoyiActive: true });
    expect(game.players.find((player) => player.id === xuChu.id)?.hand).toHaveLength(1);

    const attacker = game.players.find((player) => player.id === xuChu.id)!;
    attacker.hand = [makeCard("luoyi-slash", "slash")];
    game = applyAction(game, {
      type: "play_card",
      playerId: attacker.id,
      cardId: "luoyi-slash",
      targetId: victim.id,
    });
    game = applyAction(game, { type: "respond", playerId: victim.id, cardId: null });
    expect(game.players.find((player) => player.id === victim.id)?.hp).toBe(2);

    const normalDraw = applyAction(choice, {
      type: "resolve_skill",
      playerId: xuChu.id,
      skillId: "luoyi",
      activate: false,
    });
    expect(normalDraw.turn).toMatchObject({ phase: "play", luoyiActive: false });
    expect(normalDraw.players.find((player) => player.id === xuChu.id)?.hand).toHaveLength(2);
  });

  it("adds Luoyi damage only when Xu Chu is the Duel damage source", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "xu_chu";
    session.turn.luoyiActive = true;
    actor.hand = [makeCard("luoyi-duel", "duel")];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "luoyi-duel",
      targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(2);

    const losing = setup(3);
    losing.actor.generalId = "xu_chu";
    losing.session.turn.luoyiActive = true;
    losing.actor.hand = [makeCard("losing-duel", "duel")];
    losing.targets[0]!.hand = [makeCard("duel-answer", "slash")];
    let reverse = applyAction(losing.session, {
      type: "play_card",
      playerId: losing.actor.id,
      cardId: "losing-duel",
      targetId: losing.targets[0]!.id,
    });
    reverse = applyAction(reverse, {
      type: "respond",
      playerId: losing.targets[0]!.id,
      cardId: "duel-answer",
    });
    reverse = applyAction(reverse, { type: "respond", playerId: losing.actor.id, cardId: null });
    expect(reverse.players.find((player) => player.id === losing.actor.id)?.hp).toBe(3);
  });

  it("lets Keji skip a required discard only when no Slash was used or played", () => {
    const { session, actor } = setup(3);
    actor.generalId = "lv_meng";
    actor.hp = 3;
    actor.hand = Array.from({ length: 5 }, (_, index) => makeCard(`keji-${index}`, "dodge"));

    const choice = applyAction(session, { type: "end_play", playerId: actor.id });
    expect(choice.pendingResponse).toMatchObject({
      type: "skill_choice",
      skillId: "keji",
      resume: { type: "enter_discard", playerId: actor.id, count: 2 },
    });
    const activated = applyAction(choice, {
      type: "resolve_skill",
      playerId: actor.id,
      skillId: "keji",
      activate: true,
    });
    expect(activated.currentPlayerId).not.toBe(actor.id);

    const declined = applyAction(choice, {
      type: "resolve_skill",
      playerId: actor.id,
      skillId: "keji",
      activate: false,
    });
    expect(declined.turn).toMatchObject({ phase: "discard", requiredDiscardCount: 2 });

    actor.hand = [makeCard("keji-slash", "slash"), ...Array.from({ length: 4 }, (_, index) => makeCard(`keji-extra-${index}`, "dodge"))];
    const target = session.players.find((player) => player.id !== actor.id)!;
    let usedSlash = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "keji-slash",
      targetId: target.id,
    });
    usedSlash = applyAction(usedSlash, { type: "respond", playerId: target.id, cardId: null });
    usedSlash = applyAction(usedSlash, { type: "end_play", playerId: actor.id });
    expect(usedSlash.pendingResponse?.type).not.toBe("skill_choice");
    expect(usedSlash.turn.phase).toBe("discard");
  });

  it("records a Slash played in a Duel during Lu Meng's own turn for Keji", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "lv_meng";
    actor.hp = 3;
    actor.hand = [
      makeCard("keji-duel", "duel"),
      makeCard("keji-answer", "slash"),
      makeCard("keji-hold-1", "dodge"),
      makeCard("keji-hold-2", "dodge"),
      makeCard("keji-hold-3", "dodge"),
      makeCard("keji-hold-4", "dodge"),
    ];
    target!.hand = [makeCard("target-answer", "slash")];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "keji-duel",
      targetId: target!.id,
    });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: "target-answer" });
    game = applyAction(game, { type: "respond", playerId: actor.id, cardId: "keji-answer" });
    game = applyAction(game, { type: "respond", playerId: target!.id, cardId: null });
    expect(game.turn.slashRespondedInPlayPhase).toBe(true);
    game = applyAction(JSON.parse(JSON.stringify(game)) as GameSession, {
      type: "end_play",
      playerId: actor.id,
    });
    expect(game.pendingResponse?.type).not.toBe("skill_choice");
    expect(game.turn.phase).toBe("discard");
  });
});

describe("standard utility skills", () => {
  it("uses Zhiheng once to discard owned cards and draw the same count", () => {
    const { session, actor } = setup(3);
    actor.generalId = "sun_quan";
    actor.hp = 2;
    actor.hand = [makeCard("zhiheng-hand", "dodge")];
    actor.equipment.armor = makeCard("zhiheng-lion", "bai_yin_shi_zi", "club");
    session.deck = [makeCard("zhiheng-draw-2", "peach"), makeCard("zhiheng-draw-1", "slash")];

    const prompt = getGameView(session, actor.id).prompt;
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.skills.find((skill) => skill.skillId === "zhiheng")).toMatchObject({
      minCards: 1,
      maxCards: 2,
      targetMode: "none",
    });

    const game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "zhiheng",
      cardIds: ["zhiheng-hand", "zhiheng-lion"],
    });
    const current = game.players.find((player) => player.id === actor.id)!;
    expect(current.hp).toBe(3);
    expect(current.hand.map((card) => card.id)).toEqual(["zhiheng-draw-1", "zhiheng-draw-2"]);
    expect(game.discardPile.map((card) => card.id)).toEqual(expect.arrayContaining(["zhiheng-hand", "zhiheng-lion"]));
    expect(ruleCode(() => applyAction(game, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "zhiheng",
      cardIds: ["zhiheng-draw-1"],
    }))).toBe("INVALID_SKILL");
  });

  it("transfers hand cards atomically through Rende and heals only at the first two-card threshold", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.generalId = "liu_bei";
    actor.hp = 2;
    actor.hand = [
      makeCard("rende-1", "slash"),
      makeCard("rende-2", "dodge"),
      makeCard("rende-3", "peach"),
    ];

    let game = applyAction(session, {
      type: "use_skill", playerId: actor.id, skillId: "rende", cardIds: ["rende-1"], targetId: target!.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(2);
    expect(game.turn).toMatchObject({ rendeGivenCount: 1, rendeRecovered: false });
    game = applyAction(game, {
      type: "use_skill", playerId: actor.id, skillId: "rende", cardIds: ["rende-2"], targetId: target!.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
    expect(game.turn).toMatchObject({ rendeGivenCount: 2, rendeRecovered: true });
    game = applyAction(game, {
      type: "use_skill", playerId: actor.id, skillId: "rende", cardIds: ["rende-3"], targetId: target!.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
    expect(game.players.find((player) => player.id === target!.id)?.hand.map((card) => card.id)).toEqual([
      "rende-1", "rende-2", "rende-3",
    ]);
  });

  it("uses Qingnang once by discarding a hand card to heal any wounded role", () => {
    const { session, actor } = setup(3);
    actor.generalId = "hua_tuo";
    actor.hp = 2;
    actor.hand = [makeCard("qingnang-cost", "slash"), makeCard("qingnang-spare", "dodge")];
    const prompt = getGameView(session, actor.id).prompt;
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.skills.find((skill) => skill.skillId === "qingnang")?.targetIds).toContain(actor.id);

    const game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "qingnang",
      cardIds: ["qingnang-cost"],
      targetId: actor.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
    expect(ruleCode(() => applyAction(game, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "qingnang",
      cardIds: ["qingnang-spare"],
      targetId: actor.id,
    }))).toBe("INVALID_SKILL");
  });

  it("uses Jieyin once to heal Sun Shangxiang and another wounded male", () => {
    const { session, actor, targets: [target, invalidTarget] } = setup(3);
    actor.generalId = "sun_shang_xiang";
    actor.hp = 2;
    actor.hand = [makeCard("jieyin-1", "slash"), makeCard("jieyin-2", "dodge")];
    target!.generalId = "zhao_yun";
    target!.hp = 2;
    invalidTarget!.generalId = "da_qiao";
    invalidTarget!.hp = 2;

    const prompt = getGameView(session, actor.id).prompt;
    if (prompt.type !== "play") throw new Error("Expected play prompt");
    expect(prompt.skills.find((skill) => skill.skillId === "jieyin")?.targetIds).toEqual([target!.id]);
    const game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "jieyin",
      cardIds: ["jieyin-1", "jieyin-2"],
      targetId: target!.id,
    });
    expect(game.players.find((player) => player.id === actor.id)?.hp).toBe(3);
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(3);
  });

  it("keeps a Guose card virtual in judgment and restores its physical kind when it leaves", () => {
    const { session, actor } = setup(3);
    const actorIndex = session.players.findIndex((player) => player.id === actor.id);
    const target = session.players[(actorIndex + 1) % session.players.length]!;
    actor.generalId = "da_qiao";
    actor.equipment.offensive_horse = makeCard("guose-horse", "chi_tu", "diamond");
    target.hp = 1;
    session.deck = [
      makeCard("guose-draw-3", "peach", "heart"),
      makeCard("guose-draw-2", "dodge", "club"),
      makeCard("guose-draw-1", "slash", "spade"),
    ];

    let game = applyAction(session, {
      type: "use_skill",
      playerId: actor.id,
      skillId: "guose",
      cardIds: ["guose-horse"],
      targetId: target.id,
    });
    expect(game.players.find((player) => player.id === target.id)?.judgment).toEqual([
      expect.objectContaining({ id: "guose-horse", kind: "le_bu_si_shu", suit: "diamond" }),
    ]);
    expect(game.virtualCardOrigins).toEqual({ "guose-horse": "chi_tu" });
    game = applyAction(JSON.parse(JSON.stringify(game)) as GameSession, {
      type: "end_play",
      playerId: actor.id,
    });
    expect(game.discardPile).toEqual(expect.arrayContaining([
      expect.objectContaining({ id: "guose-horse", kind: "chi_tu" }),
    ]));
    expect(game.virtualCardOrigins).toEqual({});
  });

  it("uses a black hand card as Dodge through Qingguo", () => {
    const { session, actor, targets: [target] } = setup(3);
    actor.hand = [makeCard("qingguo-attack", "slash")];
    target!.generalId = "zhen_ji";
    target!.hand = [makeCard("qingguo-cost", "peach", "spade")];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "qingguo-attack",
      targetId: target!.id,
    });
    const prompt = getGameView(game, target!.id).prompt;
    if (prompt.type !== "respond") throw new Error("Expected response prompt");
    expect(prompt.skillResponses).toContainEqual({
      skillId: "qingguo",
      cardIds: ["qingguo-cost"],
      responseKind: "dodge",
    });
    game = applyAction(game, {
      type: "use_skill",
      playerId: target!.id,
      skillId: "qingguo",
      cardIds: ["qingguo-cost"],
    });
    expect(game.players.find((player) => player.id === target!.id)?.hp).toBe(4);
    expect(game.discardPile.find((card) => card.id === "qingguo-cost")?.kind).toBe("peach");
  });

  it("uses a red owned card as Peach through Jijiu outside Hua Tuo's turn", () => {
    const { session, actor } = setup(3);
    const actorIndex = session.players.findIndex((player) => player.id === actor.id);
    const victim = session.players[(actorIndex + 1) % session.players.length]!;
    const huaTuo = session.players[(actorIndex + 2) % session.players.length]!;
    actor.hand = [makeCard("jijiu-attack", "slash")];
    victim.hp = 1;
    huaTuo.generalId = "hua_tuo";
    huaTuo.equipment.offensive_horse = makeCard("jijiu-cost", "chi_tu", "diamond");

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "jijiu-attack",
      targetId: victim.id,
    });
    game = applyAction(game, { type: "respond", playerId: victim.id, cardId: null });
    expect(game.pendingResponse).toMatchObject({ type: "dying", targetId: victim.id });
    game = applyAction(game, { type: "respond", playerId: victim.id, cardId: null });
    const prompt = getGameView(game, huaTuo.id).prompt;
    if (prompt.type !== "dying") throw new Error("Expected dying prompt");
    expect(prompt.skillResponses).toEqual([
      { skillId: "jijiu", cardIds: ["jijiu-cost"], responseKind: "peach" },
    ]);
    game = applyAction(game, {
      type: "use_skill",
      playerId: huaTuo.id,
      skillId: "jijiu",
      cardIds: ["jijiu-cost"],
    });
    expect(game.players.find((player) => player.id === victim.id)).toMatchObject({ alive: true, hp: 1 });
    expect(game.players.find((player) => player.id === huaTuo.id)?.equipment.offensive_horse).toBeUndefined();
    expect(game.discardPile.find((card) => card.id === "jijiu-cost")?.kind).toBe("chi_tu");
  });

  it("adds one recovery when another Wu general rescues lord Sun Quan through Jiuyuan", () => {
    const { session, actor } = setup(3);
    const actorIndex = session.players.findIndex((player) => player.id === actor.id);
    const sunQuan = session.players[(actorIndex + 1) % session.players.length]!;
    const rescuer = session.players[(actorIndex + 2) % session.players.length]!;
    const formerRole = sunQuan.role;
    sunQuan.role = "lord";
    actor.role = formerRole;
    sunQuan.generalId = "sun_quan";
    sunQuan.hp = 1;
    rescuer.generalId = "gan_ning";
    rescuer.hand = [makeCard("jiuyuan-peach", "peach", "heart")];
    actor.hand = [makeCard("jiuyuan-attack", "slash")];

    let game = applyAction(session, {
      type: "play_card",
      playerId: actor.id,
      cardId: "jiuyuan-attack",
      targetId: sunQuan.id,
    });
    game = applyAction(game, { type: "respond", playerId: sunQuan.id, cardId: null });
    game = applyAction(game, { type: "respond", playerId: sunQuan.id, cardId: null });
    expect(game.pendingResponse).toMatchObject({ type: "dying", targetId: rescuer.id });
    game = applyAction(game, { type: "respond", playerId: rescuer.id, cardId: "jiuyuan-peach" });
    expect(game.players.find((player) => player.id === sunQuan.id)).toMatchObject({ alive: true, hp: 2 });
  });
});
